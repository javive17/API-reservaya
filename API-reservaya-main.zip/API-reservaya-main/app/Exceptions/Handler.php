<?php

namespace App\Exceptions;

use App\Traits\GeneralResponse;
use Exception;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

class Handler extends ExceptionHandler
{
    use GeneralResponse;

    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @throws \Exception
     */
    public function report(Throwable $exception)
    {
        if ($this->shouldReport($exception) && app()->bound('sentry')) {
            app('sentry')->captureException($exception);
        }
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function render($request, Throwable $exception)
    {
        return $this->handleException($request, $exception);
    }

    public function handleException($request, Throwable $exception)
    {
        if ($exception instanceof ValidationException) {
            return $this->genResponse(0, 400, ['errors' => $exception->errors()]);
        }

        if ($exception instanceof MethodNotAllowedHttpException) {
            return $this->genResponse(0, 405);
        }

        if ($exception instanceof NotFoundHttpException) {
            return $this->genResponse(0, 404);
        }

        if ($exception instanceof HttpException) {
            return $this->genResponse(0, $exception->getStatusCode(), $exception->getMessage());
        }

        if (config('app.debug')) {
            return parent::render($request, $exception);
        }

        return $this->genResponse(0, 500);
    }

    protected function invalidJson($request, ValidationException $exception)
    {
        return $this->genResponse(0, 400, ['errors' => $exception->errors()]);
    }

    protected function unauthenticated($request, AuthenticationException $exception)
    {
        // response()->json(['message' => $exception->getMessage()], 401)
        // return $request->expectsJson()
        //     ? $this->genResponse(0, 401)
        //     : redirect()->guest(route('login'));
        return $this->genResponse(0, 401);
    }
}