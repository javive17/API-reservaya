#!/bin/bash
echo ' **********  putting laravel into maintenance mode  ********** '
php artisan down

echo ' **********  migratings all core tables ********** '
php artisan migrate:reset

echo ' **********  drop migratings catalogs ********** '
php artisan migrate:reset --path=/database/migrations/catalogs
