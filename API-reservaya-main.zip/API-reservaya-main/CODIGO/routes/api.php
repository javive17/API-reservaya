<?php



use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\Reservation;



/*

|--------------------------------------------------------------------------

| API Routes

|--------------------------------------------------------------------------

|

| Here is where you can register API routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| is assigned the "api" middleware group. Enjoy building your API!

|

*/

//route to hande                       HttpApi.postVoid('/reservations/${reservacion.id}/mark-comment-seen').then((value) => print(value)),

Route::get('/greeting', function() {
    return \App\Models\User::all();
});
Route::get('/encrypt/{id}', function($id) {
    $encrypt_id = encrypt($id);
    return $encrypt_id;
});

Route::get('/decrypt/{id}', function($id) {
    $decrypt_id = decrypt($id);
    return $decrypt_id;
});



Route::get('/test', 'API\Restaurant\ReservationController@test');
Route::get('/tabletypes', 'API\Restaurant\RestaurantController@tabletypes');
Route::group(['prefix' => 'v1'], function () {
    Route::get('/estadistica/clientes/{year}', 'API\Restaurant\ReservationController@estadisticaClientes');
    Route::get('/categorie/clientes/{id}', 'API\Restaurant\ReservationController@categorieClientes');

    //Route::get('/commentsurvey2', 'API\Restaurant\ReservationController@coments');
    Route::get('/bloqueados/dias/{year}/{month}', 'API\Restaurant\ReservationController@blockedreservations');
    Route::post('/register', 'API\App\ClientController@register');
    
    Route::get('/estadistica/reservaStatus/{date_start}/{date_end}', 'API\Restaurant\ReservationController@reservationsHowMany');
   // Route::get('/estadistica/reservaStatus', 'API\Restaurant\ReservationController@reservationsHowMany');
   //Route::post('/estadistica/reservaStatus', 'API\Restaurant\ReservationController@reservationsHowMany');
   
    Route::post('/login', 'API\Auth\AuthController@login');
    Route::post('/emailExists', 'API\Auth\AuthController@emailExists');
    Route::post('/deleteTemporalUser', 'API\Auth\AuthController@deleteTemporalUser');

 

    Route::post('/forgot-password', 'API\Auth\AuthController@forgotPassword');

    Route::post('/reset-password', 'API\Auth\AuthController@resetPassword');

    Route::get('/catalogs/{catalogName}', 'API\CatalogController@getList');

    Route::get('/catalogs/zone/{id}', 'API\CatalogController@getSector');

});



Route::group(['middleware' => ['auth:api'], 'prefix' => 'v1'], function () {
  

    Route::get('/logout', 'API\Auth\AuthController@logout')->name('logout');
    Route::post('/checkUser', 'API\Auth\AuthController@checkUser')->name('checkUser');
   //delete-account
   Route::post('/delete-account', 'API\Auth\AuthController@deleteAccount');


    Route::group(['middleware' => ['staff'], 'prefix' => 'restaurant'], function () {

        Route::group(['middleware' => ['manager']], function () {

            //restaurant's offers 
            Route::get('/offers', 'API\Restaurant\OffersController@index');

            Route::get('/offers/{id}', 'API\Restaurant\OffersController@show');

            Route::post('/offers', 'API\Restaurant\OffersController@store');

            Route::put('/offers/{id}', 'API\Restaurant\OffersController@edit');

            Route::delete('/offers/{id}', 'API\Restaurant\OffersController@delete');

            //restaurant's staff

            Route::get('/staff', 'API\Restaurant\StaffController@index');

            Route::get('/staff/{id}', 'API\Restaurant\StaffController@show');

            Route::post('/staff', 'API\Restaurant\StaffController@store');

            Route::put('/staff/{id}', 'API\Restaurant\StaffController@edit');

            Route::delete('/staff/{id}', 'API\Restaurant\StaffController@delete');

            //restaurant details

            Route::get('/', 'API\Restaurant\RestaurantController@show');

            Route::put('/description', 'API\Restaurant\RestaurantUpdateController@description');
            Route::put('/sector', 'API\Restaurant\RestaurantUpdateController@sector');

            Route::delete('/photos', 'API\Restaurant\RestaurantUpdateController@deletePhotos');

            Route::post('/photos', 'API\Restaurant\RestaurantController@storePhotos');
            Route::post('/cover', 'API\Restaurant\RestaurantController@storecover');
            Route::post('/tabletypes', 'API\Restaurant\RestaurantController@tabletypes');
            Route::post('/createzone', 'API\Restaurant\RestaurantController@createzone');
            Route::post('/createrestaurant', 'API\Restaurant\RestaurantController@createrestaurant');
            Route::put('/capacity', 'API\Restaurant\RestaurantUpdateController@capacity');
        
            Route::put('/menu', 'API\Restaurant\RestaurantUpdateController@menu');
            Route::put('/automatic', 'API\Restaurant\RestaurantUpdateController@automatic');
            Route::put('/offer', 'API\Restaurant\RestaurantUpdateController@offer');

            Route::put('/cost', 'API\Restaurant\RestaurantUpdateController@cost');
            Route::put('/sector', 'API\Restaurant\RestaurantUpdateController@sector');
            Route::put('/extra-service', 'API\Restaurant\RestaurantUpdateController@extraService');

            Route::put('/kitchen', 'API\Restaurant\RestaurantUpdateController@kitchen');

            Route::put('/service-day', 'API\Restaurant\RestaurantUpdateController@serviceDays');

        });

        // restaurant's clients

        Route::get('/search/clients/{email}', 'API\Restaurant\ClientController@searchClientsByEmailOrPhone');

        Route::get('/clients/search/{type}/{search?}', 'API\Restaurant\ClientController@searchClients');
        Route::get('/clients/all', 'API\Restaurant\ClientController@searchAllClients');

        Route::get('/clients/export/{type}/{search?}', 'API\Restaurant\ClientController@export');

        Route::get('/clients/{type}', 'API\Restaurant\ClientController@index');

        Route::get('/clients/{type}/{encrypt_id}', 'API\Restaurant\ClientController@show');

        Route::get('/clients/pages/{pagesnumber}/{type}', 'API\Restaurant\ClientController@clientsAll');

        Route::put('/clients/preferences/{id}', 'API\Restaurant\ClientController@editRestaurantPreferences');

        Route::put('/clients/category', 'API\Restaurant\ClientController@editRestaurantCategory');

        // update client profile

        Route::put('/clients/update/NutritionalRequirements', 'API\Restaurant\ClientController@updateNutritionalReq');

        Route::put('/clients/update/Allergies', 'API\Restaurant\ClientController@updateAllergies');

        Route::put('/clients/update/Drinks', 'API\Restaurant\ClientController@updateDrinks');

        Route::put('/clients/update/Tables', 'API\Restaurant\ClientController@updateTables');
        Route::put('/clients/update/Names', 'API\Restaurant\ClientController@updateNames');

        // restaurant's reservations

        Route::get('/reservations-show/{id}', 'API\Restaurant\ReservationController@show');

        Route::get('/reservations/{zone}/{date?}/{hour?}', 'API\Restaurant\ReservationController@index');
        //fast 
        Route::get('/reservationsfast/{zone}/{date?}/{hour?}', 'API\Restaurant\ReservationController@indexfast');

        Route::get('/reservations-permonth/{year}/{month}', 'API\Restaurant\ReservationController@reservationsPerMonth');
        // get the total of reservations per month, coming from pardepan or waitinglist
        Route::get('/reservations-blockedmonth/{year}/{month}', 'API\Restaurant\ReservationController@blockedreservations');

        Route::get('/total-reservations-permonth/{year}/{month}', 'API\Restaurant\ReservationController@reservationsPerMonthTotal');



        //blocked for a day 

        Route::get('/allday-reservations/{zone}/{date?}/{hour?}', 'API\Restaurant\ReservationController@allDay');

        Route::post('/alldayreservations/save', 'API\Restaurant\ReservationController@saveAllDay');

        Route::post('/alldayreservations/remove', 'API\Restaurant\ReservationController@removeAllDay');

        //pardepan blocked for a day
        Route::post('/pardepanBlock/save', 'API\Restaurant\ReservationController@pardepanBlock');

        Route::post('/pardepanBlock/remove', 'API\Restaurant\ReservationController@pardepanUnBlock');


        Route::post('/reservations', 'API\Restaurant\ReservationController@create');
        Route::post('/reservations/create', 'API\Restaurant\ReservationController@createnoclient');
        Route::post('/WalkIn', 'API\Restaurant\ReservationController@WalkIn');

        Route::post('/reservation-availability', 'API\Restaurant\ReservationController@reservationAvailability');
        
        Route::post('/reservations/change-status', 'API\Restaurant\ReservationController@changeStatus');

        Route::post('/reservations/cancel/{id}', 'API\Restaurant\ReservationController@cancel');



        Route::put('/reservations/{id}', 'API\Restaurant\ReservationController@edit');

        Route::delete('/reservations/{id}', 'API\Restaurant\ReservationController@delete');

        Route::get('/commentsurvey',             'API\Restaurant\ClientsSurveyController@index');

        Route::get('/commentsurveylist',             'API\Restaurant\ClientsSurveyController@survey');
       
        Route::post('/updateseen/{id}', 'API\Restaurant\ClientsSurveyController@updateseen');
        //restaurant's comments
      //  Route::post('/comments/reply/updateIsSeen/{id}', 'API\Restaurant\ClientsSurveyController@updateIsSeen');
      Route::post('/mark-comment-seen/{id}', function ($id) {
      
        $reservation = Reservation::where('encrypt_id', $id)->first();
        if (!$reservation) {
            return response()->json(['error' => 'Reservation not found'], 404);
        }
        $reservation->commentSeen= 1;
        $reservation->save();
        return response()->json($reservation);
    });

        Route::get('/comments',             'API\Restaurant\CommentController@index');

        Route::post('/comments/reply/{id}', 'API\Restaurant\CommentController@replyComment');

        Route::delete('/comments/{id}',     'API\Restaurant\CommentController@deleteComment');



        //payments

        Route::get('/charges/{date}', 'API\Restaurant\ChargeController@index');

        Route::get('/charges/{date}/export', 'API\Restaurant\ChargeController@export');



        //profile

        Route::put('/profile/password', 'API\Restaurant\StaffController@updatePassword');

          //statistics
        Route::post('getReservesGraph', 'API\puerta21\StatisticsPuerta21Controller@puerta21reservesgraph'); 
        Route::post('puerta21usersPlatform', 'API\puerta21\StatisticsPuerta21Controller@puerta21usersPlatform');
        
     
  
  
       
    });



    Route::group(['middleware' => ['client'], 'prefix' => 'client'], function () {

        // profile

        Route::get('profile',                           'API\App\ClientController@getProfile');

        Route::get('profile/public',                    'API\App\ClientController@getProfilePublic');

        Route::get('profile/public/followers',         'API\App\ClientController@getProfilePublicFollowers');

        Route::get('profile/public/followings',         'API\App\ClientController@getProfilePublicFollowings');

        Route::get('profile/public/publications',       'API\App\ClientController@getProfilePublicPublications');

        Route::post('profile/photo',                    'API\App\ClientController@saveProfilePicture');

        Route::get('profile/photo',                     'API\App\ClientController@getProfilePicture');

        Route::post('profile/invitation',               'API\App\ClientController@sendInvitation');

        Route::put('/profile/password',                 'API\Restaurant\StaffController@updatePassword'); // TODO: go to general function

        Route::put('/profile/description',              'API\App\ClientController@updateDescription');

        Route::put('/profile/gender',                   'API\App\ClientController@updateGender');

        Route::put('/profile/country',                  'API\App\ClientController@updateCountry');

        Route::post('/profile/privacy',                 'API\App\ClientController@savePrivacy');

        Route::get('/profile/privacy',                  'API\App\ClientController@getPrivacy');

        Route::put('/profile/firebase-token',           'API\App\ClientNotificationController@updateFirebaseToken');



        // survery 

        Route::get('survey/check',                      'API\App\ClientController@surveyCheck');

        Route::post('survey/professions',               'API\App\ClientController@saveProfessions');

        Route::post('survey/industries',                'API\App\ClientController@saveIndustries');

        Route::post('survey/nutritional-requirements',  'API\App\ClientController@saveNutritionalRequirements');

        Route::post('survey/allergies',                 'API\App\ClientController@saveAllergies');

        Route::post('survey/tables',                    'API\App\ClientController@saveTables');

        Route::post('survey/favorite-drink',            'API\App\ClientController@saveFavoriteDrink');

        Route::post('survey/drinks',                    'API\App\ClientController@saveDrinks');

        Route::post('survey/foods',                     'API\App\ClientController@saveFoods');

        Route::post('survey/additional-comments',       'API\App\ClientController@saveAdditionalComments');

        // restaurant

        Route::get('restaurant/favorites/{client_eid}',     'API\App\ClientRestaurantController@listRestaurantsFavorites');

        Route::get('restaurant/my-favorites',               'API\App\ClientRestaurantController@listMyRestaurantsFavorites');

        Route::post('restaurant/favorite',                  'API\App\ClientRestaurantController@favoriteRestaurant');

        Route::get('restaurant/list/{type}',                'API\App\ClientRestaurantController@index');

        Route::get('restaurant/show/{restaurant_eid}',      'API\App\ClientRestaurantController@show');

        Route::get('restaurant/address/{restaurant_eid}',   'API\Restaurant\RestaurantController@getAddress');

        // reservations

        Route::post('restaurant/reservations',                  'API\App\ClientRestaurantController@createReservation');

        Route::put('restaurant/reservations',                   'API\App\ClientRestaurantController@updateReservation');

        Route::put('restaurant/reservations/form',                   'API\pardepan\ReservationController@sendReservationFormUpdate');

        Route::get('restaurant/reservation/{reservation_eid}',  'API\App\ClientRestaurantController@getReservation');

        Route::get('restaurant/reservations/{type}',            'API\App\ClientRestaurantController@listReservation');

        Route::post('restaurant/reservations/cancel/{reservation_eid}',    'API\App\ClientRestaurantController@cancelReservation');

        // comments

        Route::post('/comments',                                    'API\App\ClientCommentController@store');

        // followers

        Route::get('/clients/list/{type}',                          'API\App\ClientFollowersController@listClients');

        Route::get('/clients/profile/{client_eid}',                 'API\App\ClientFollowersController@showClient');

        Route::get('/clients/profile/publications/{client_eid}',    'API\App\ClientFollowersController@showClientPublications');

        Route::post('/clients/follow',                              'API\App\ClientFollowersController@followClient');

        Route::get('/clients/followers/{client_eid}',               'API\App\ClientFollowersController@getProfilePublicFollowers');

        Route::get('/clients/followings/{client_eid}',              'API\App\ClientFollowersController@getProfilePublicFollowings');

        // publications

        Route::post('/clients/publications',                        'API\App\ClientFollowersController@createPublication');

        Route::get('/clients/publications/{publication_eid}',       'API\App\ClientFollowersController@getPublication');

        Route::post('/clients/publications/like/{publication_eid}', 'API\App\ClientFollowersController@addLikesDislikesOnPublication');

        Route::get('/clients/publications/list/like/{publication_eid}', 'API\App\ClientFollowersController@listClientsWhoLikedThePublication');

        // Stories

        Route::get('/clients/stories',                                  'API\App\ClientFollowersController@getMyStories');

        Route::get('/clients/stories/list',                             'API\App\ClientFollowersController@getClientsStories');

        Route::get('/clients/stories/detail/{client_eid}',              'API\App\ClientFollowersController@getStories');

        // messages

        Route::post('/clients/messages/send',                           'API\App\ClientFollowersController@senderMessage');

        Route::get('/clients/messages/list/{type}',                     'API\App\ClientFollowersController@getListMessagingClient');

        // notifications

        Route::post('/notification/chat',                               'API\App\ClientNotificationController@sendNotificationChat');

        //blocked

        Route::post('/clients/blocked',                                 'API\App\ClientFollowersController@blockOrUnblockClient');

        Route::get('/clients/blocked/check/{client_eid}',               'API\App\ClientFollowersController@checkIfTheClientIsBlocked');

        //report publications

        Route::post('/clients/report/publication',                      'API\App\ClientFollowersController@reportPublication');

    });



    Route::group(['middleware' => ['founder'], 'prefix' => 'founder'], function () {

        // profile

        Route::put('/profile/password',                             'API\Restaurant\StaffController@updatePassword'); // TODO: go to general function

        // clients

        Route::post('/invitation',                                  'API\Founder\FounderController@sendInvitation');

        Route::get('/clients/{client_type}/{type}',                 'API\Founder\FounderController@clientsList');

        Route::get('/clients/reservation/list/{client_eid}/{type}', 'API\Founder\FounderController@clientsReservationList');

        Route::post('/clients/accept',                              'API\Founder\FounderController@acceptClient');

        Route::post('/clients/reject',                              'API\Founder\FounderController@rejectClient');

        Route::post('/clients/friend',                              'API\Founder\FounderController@addRemoveClientFriend');

        Route::put('/clients/active',                               'API\Founder\FounderController@activeClient');

        Route::delete('/clients/delete/{client_eid}',               'API\Founder\FounderController@deleteClient');

        // clients - report

        Route::get('/clients/report/{client_type}/{type}',          'API\Founder\FounderController@clientsListReport');

        // clients - restaurants

        Route::post('/restaurants',                                 'API\Founder\FounderController@createRestaurant');

        Route::get('/restaurants/list/{type}',                      'API\Founder\FounderController@listRestaurant');

        Route::get('/restaurants/{restaurant_eid}',                 'API\Founder\FounderController@showRestaurant');

        Route::put('/restaurants/menu',                             'API\Founder\FounderController@updateMenu');

        Route::put('/restaurants/capacity',                         'API\Founder\FounderController@updateCapacity');

        Route::put('/restaurants/service-day',                      'API\Founder\FounderController@updateServiceDays');

        Route::put('/restaurants/extra-service',                    'API\Founder\FounderController@updateExtraService');

        Route::put('/restaurants/cost',                             'API\Founder\FounderController@updateCost');

        Route::put('/restaurants/kitchen',                          'API\Founder\FounderController@updateKitchen');

        Route::put('/restaurants/address',                          'API\Founder\FounderController@updateAddress');

        Route::put('/restaurants/information',                      'API\Founder\FounderController@updateInformation');

        Route::put('/restaurants/active',                           'API\Founder\FounderController@activeRestaurant');

        Route::post('/restaurants/photos',                          'API\Founder\FounderController@storePhotos');

        Route::delete('/restaurants/photos',                        'API\Founder\FounderController@deletePhotos');

        //payments

        Route::get('/payments/list/{date}/{type}',                  'API\Founder\FounderController@listPayments');

        Route::get('/payments/total/{date}',                        'API\Founder\FounderController@paymentsPerMonth');

        Route::get('/payments/report/{date}',                       'API\Founder\FounderController@reportPayments');

        Route::put('/payments/status',                              'API\Founder\FounderController@updatePaymentStatus');

        Route::get('/payments/detail/{restaurant_eid}/{date}/{type}',   'API\Founder\FounderController@detailPayments');

        Route::get('/payments/total/{restaurant_eid}/{date}',           'API\Founder\FounderController@restaurantPaymentsPerMonth');

        Route::get('/payments/report/detail/{restaurant_eid}/{date}',   'API\Founder\FounderController@restaurantReportPayments');



        //Reports - publications

        Route::get('/reported/publications/list/{type}',            'API\Founder\FounderController@listReportedPublications');

        Route::get('/reported/publications/{reported_eid}',         'API\Founder\FounderController@showReportedPublication');

        Route::get('/reported/publications/detail/{publication_eid}',           'API\Founder\FounderController@showReportedPublication');

        Route::get('/reported/publications/detail/client/{publication_eid}',    'API\Founder\FounderController@showReportedPublicationClient');

        Route::get('/reported/publications/detail/image/{publication_eid}',     'API\Founder\FounderController@showReportedPublicationImage');

        Route::delete('/reported/publications/detail/{publication_eid}',        'API\Founder\FounderController@deletePublication');



        //temporary

        Route::get('/temporary/chief_manger',                     'API\Founder\FounderController@temporalityChiefManager');
        Route::get('/Offers',                                  'API\Founder\FounderController@offers');
        //post 
        Route::post('/offers',                                  'API\Founder\FounderController@createOffer');

        //founder/Offers/delete/15
        Route::delete('/Offers/delete/{id}',                                  'API\Founder\FounderController@deleteOffer');
        ///offers/Details/15 edit
        Route::get('/offers/details/{id}',                                  'API\Founder\FounderController@DetailsOffer');
        //offers/edit/15
        Route::put('/offers/edit/{id}',                                  'API\Founder\FounderController@editOffer');

        Route::get('/listImagen', 'API\puerta21\BannersController@listImagen');

        Route::put('/banners/edit/{id}','API\puerta21\BannersController@editBanner');
        Route::put('/banners/status/{id}','API\puerta21\BannersController@statusBanner');

        Route::post('/banners/created', 'API\puerta21\BannersController@createdBanner');

        Route::put('/banners/details/{id}','API\puerta21\BannersController@DetailsBanner');
        Route::post('/banners/cover', 'API\puerta21\BannersController@bannerImage');
     
    });

});


// ROUTES PARDEPAN KTECH
Route::group(['prefix' => 'v1'], function () {
    Route::group(['prefix' => 'pardepan'], function () {
        Route::post('reset-password', 'API\pardepan\ClientController@resetPassword');
        Route::post('/register', 'API\pardepan\ClientController@register');
        Route::post('/forgot-password', 'API\pardepan\ClientController@forgotPassword');
        Route::get('/profile/{id}', 'API\pardepan\ClientController@edit');
        Route::post('/profile', 'API\pardepan\ClientController@update');
        Route::post('/getUserEmail', 'API\pardepan\ClientController@getUserEmail');

        // Route::post('/deleteAccount', 'API\pardepan\ClientController@deleteAccount');

        //home
        Route::get('/getZones', 'API\pardepan\HomeController@getZones');
        Route::get('/getHours/{id}', 'API\pardepan\HomeController@getHours');
        Route::get('/notification', 'API\pardepan\HomeController@notification'); 
         
        //Restaurents
        Route::get('restaurants{limit?}', 'API\pardepan\RestaurantController@index');
        Route::get('restaurant/list/{type}', 'API\pardepan\RestaurantController@search');
        Route::post('restaurant/search', 'API\pardepan\RestaurantController@search');
        Route::get('restaurant/{id}', 'API\pardepan\RestaurantController@show');
        Route::get('restaurants/favoritos', 'API\pardepan\RestaurantController@restaurantFavorites');
        Route::post('restaurant/searchText', 'API\pardepan\RestaurantController@searchText');
        Route::post('restaurant/changeFavoriteRestaurant', 'API\pardepan\RestaurantController@changeFavoriteRestaurant');
        Route::get('restaurants/favoritos/client/{id}', 'API\pardepan\RestaurantController@restaurantFavoritesClient');
        Route::get('restaurants/offers/{id}/{datetime?}', 'API\pardepan\RestaurantController@restaurantOffers');


        //reservation
        Route::get('getReservation/{eid}', 'API\pardepan\ReservationController@getReservation');
        Route::get('getReservationForm/{eid}', 'API\pardepan\ReservationController@getReservationForm');
        Route::post('restaurant/reservation-availability', 'API\pardepan\ReservationController@reservationAvailability');
        Route::post('restaurant/reservation-create', 'API\pardepan\ReservationController@createReservation');
        Route::get('/clients/reservation/list/{client_eid}/{type}', 'API\pardepan\ReservationController@clientsReservationList'); 
        Route::post('/reservation/formulario', 'API\pardepan\ReservationController@formSend');
        Route::post('/reservation/formulario-sastifacion', 'API\pardepan\ReservationController@pollStore');

        
    });
});


// ROUTES PUERTA 21 KTECH
Route::group(['prefix' => 'v1'], function () {
    Route::group(['prefix' => 'puerta21Dashboard'], function () {
        Route::get('dashboard', 'API\puerta21\DashboardController@index');
        Route::get('dashboard/homeTop', 'API\puerta21\DashboardController@homeTop');
        Route::get('dashboard/topZone', 'API\puerta21\DashboardController@topZone');

        #Users
        Route::post('userTypeMonths', 'API\puerta21\UserController@userTypeMonths');
        Route::get('getYear', 'API\puerta21\UserController@getYear');
        Route::post('getUsersAgeGender', 'API\puerta21\UserController@getUsersAgeGender');
        Route::post('usersPlatform', 'API\puerta21\UserController@usersPlatform');
        Route::post('usersVisitPlatform', 'API\puerta21\UserController@usersVisitPlatform');

        #restaurants
        Route::post('restaurants', 'API\puerta21\RestaurantController@restaurants');
        Route::post('restaurantsRequest', 'API\puerta21\RestaurantController@show'); 
        Route::get('zones', 'API\puerta21\RestaurantController@zones');
        Route::post('zonesRequest', 'API\puerta21\RestaurantController@zoneShow'); 

        Route::post('restaurantGraph', 'API\puerta21\RestaurantController@reservesgraph'); 

        Route::get('getClients', 'API\puerta21\UserController@getClients'); 
       
    });
});

Route::group(['prefix' => 'v1'], function () {
    Route::group(['prefix' => 'google'], function () {
       //loginorregister
       Route::post('loginOrRegister', 'API\Google\GoogleController@loginOrRegister');
       //checkauthStatus
         Route::post('checkauthStatus', 'API\Google\GoogleController@checkauthStatus');
    });
});

