<?php



use Illuminate\Support\Facades\Route;
use App\Mail\CancelledReservation;
use App\Mail\AcceptReservation;
use App\Models\{Restaurant, Client, Reservation, Table};
use Illuminate\Support\Str;
use Illuminate\Support\Facades\{Mail, DB};
use Carbon\Carbon;
//response
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Crypt;
use App\Models\Device;
//job SendNotificationToRestaurant
use App\Jobs\SendNotificationToRestaurant;




/*

|--------------------------------------------------------------------------

| Web Routes

|--------------------------------------------------------------------------

|

| Here is where you can register web routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| contains the "web" middleware group. Now create something great!

|

*/
//route to hande                       HttpApi.postVoid('/reservations/${reservacion.id}/mark-comment-seen').then((value) => print(value)),

//route test-reservation-notification
Route::get('/test-reservation-notification', function () {
    $reservation = Reservation::find(99881);
    $table = Table::find($reservation->table_id);
    $restaurant = Restaurant::find($table->restaurant_id);
    $devices = Device::where('restaurant_id', $restaurant->id)->orderBy('id', 'desc')->take(5)->get();
    foreach ($devices as $device) {
        $data = (object) [
            'notification_id' => $device->id, // Assuming device ID is used as notification ID
            "token"           => $device->token,
            "platform"        => $device->platform,
            'title'           => 'Nueva Reserva', // Customize your title
            'body'            => '¡BUENAS NOTICIAS! Ha recibido una nueva reserva!', // Customize your body
            'date'            => date('Y-m-d'),
        ];

        sendGCM($data);
    }
    return $devices;
 
});

//route test-notifications
Route::get('/test-notifications', function () {
    //get all devices
  //$devices = Device::where('restaurant_id', 1)->get();
  //get the 6 last devices by id
    $devices = Device::where('restaurant_id', 1)->orderBy('id', 'desc')->take(5)->get();
    foreach ($devices as $device) {

        $data = (object) [
            'notification_id' => 1,
            "token"           => $device->token,
            "platform"        => $device->platform,
            'title'           => 'title',
            'body'            => 'body',
            'date'            => date('Y-m-d'),
        ];
        //send notification
        sendGCM($data);
        echo "Notification sent to: " . $device->token . "<br>";
        

    }

  return $devices;
});

function sendGCM($datos){

    $notification = array(
        'title' => $datos->title,
        'body'  => $datos->body,
        'data'  => $datos,
        'sound' => 'default',
        'badge' => '1',
        'style' => 'inbox'
    );
    $arrayToSend = array(
        'to' => $datos->token,
        'notification' => $notification,
        'priority' => 'high'
    );

    $json = json_encode($arrayToSend);
    $headers = array();
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Authorization: key=' . env("FIREBASE_API_ACCESS_KEY");
    $ch = curl_init();
    if (env("APP_ENV") == 'local') {
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    }
    curl_setopt($ch, CURLOPT_URL, env("FIREBASE_API_URL"));
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    //Send the request
    curl_exec($ch);
    //Close request

    curl_close($ch);
}
Route::get('/reminder-test2', function () {
    
    $reservation = Reservation::find(64591);
    
       $phone = $reservation->client->cell_phone;
       $reservation_hour = Carbon::parse($reservation->reservation_date)->format('H:i');
       //check if reservation hour is 1 hour after current hour
       
       if ($phone != null && $phone !== '') {
        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
        $body =
        "*ESTIMAD@* " . $name . ":

Nos alegra recordarle su reserva de HOY en:
";
    $body = $body . "
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
• *Número de personas*: " . $reservation->people . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

    /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
    $body = $body . "
    
Le informamos que la vigencia de esta reserva son 10 minutos luego de la hora estipulada de la misma.";


$body = $body . "

Si lo desea, siempre puede

CANCELAR o MODIFICAR su reserva en el siguiente link: 🔗 

https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

    
if ($reservation->table->restaurant->group_type !== 'donapula'){
            $body = $body . "
    
Le recordamos que dicho establecimiento requiere un código de vestimenta CASUAL ELEGANTE.";
}
    
            $body = $body . "
    
            En el caso de que querer realizar una consulta, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.";
    
            $body = $body . "
    
Un cordial saludo,
    
Equipo Reserva Ya!
";

$body = $body . "
    
↓ ENGLISH ↓

*ESTIMAD@* " . $name .  " 

We are pleased to remind you of your reservation TODAY at:

";

$body = $body . "
• *Reservation name*: " . $name . "
• *Restaurant*: " . $reservation->table->restaurant->name . "
• *Time*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
• *Number of people*: " . $reservation->people . "
• *Date*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

$body = $body . "

 If you wish, 
     
     you can always CANCEL OR MODIFY your reservation at 🔗
     
     https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id . " 

Please note that this reservation is valid for 10 minutes after the scheduled time.

If you have any inquiries, please contact the restaurant directly. This phone number does not answer calls or messages.

Best regards,

@ReservaYaRD

";

$params = array(
    'token' => 'ckrwcewisan28bw1',
    'to' => $phone,
    'body' => $body,
);
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",

        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => http_build_query($params),
        CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }
       }
 
    


    return "done";
});

Route::get('/reminder', function () {
    
    $current_hour = Carbon::now()->format('H:i');
    // get all reservations where reservation_date is today
    $reservations = Reservation::whereDate('reservation_date', Carbon::today())
    ->where('reservations_status_id', 9)
    
    ->get();
 //loop reservations
    foreach ($reservations as $reservation) {

       $phone = $reservation->client->cell_phone;
       $reservation_hour = Carbon::parse($reservation->reservation_date)->format('H:i');
       //check if reservation hour is 1 hour after current hour
       
       if ($phone != null && $phone !== '') {
        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
        $body =
        "*ESTIMAD@* " . $name . ":

Nos alegra recordarle su reserva de HOY en:
";
    $body = $body . "
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Número de personas*: " . $reservation->people . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

    /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
    $body = $body . "

Para modificar o cancelar la reserva por favor, dele clic aqui: www.reservaya.do
    
Le informamos que la vigencia de esta reserva son 10 minutos luego de la hora estipulada de la misma.";
    
if ($reservation->table->restaurant->group_type !== 'donapula'){
            $body = $body . "
    
Le recordamos que dicho establecimiento requiere un código de vestimenta CASUAL ELEGANTE.";
}
    
            $body = $body . "
    
            En el caso de que querer realizar una consulta, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.";
    
            $body = $body . "
    
Un cordial saludo,
    
Equipo Reserva Ya!
";

$body = $body . "
    
*↓ ENGLISH ↓*

*ESTIMAD@* " . $name . ":

We are pleased to remind you of your reservation TODAY at:

";

$body = $body . "
• *Reservation name*: " . $name . "
• *Restaurant*: " . $reservation->table->restaurant->name . "
• *Time*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
• *Number of people*: " . $reservation->people . "
• *Date*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

$body = $body . "

To modify or cancel the reservation, please click here: www.reservaya.do

Please note that this reservation is valid for 10 minutes after the scheduled time.

If you have any inquiries, please contact the restaurant directly. This phone number does not answer calls or messages.

Best regards,

@ReservaYaRD

";
$params = array(
    'token' => 'ckrwcewisan28bw1',
    'to' => $phone,
    'body' => $body,
);
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",

        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => http_build_query($params),
        CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }   
}
}

    return "done";
});


Route::get('/send-review-form/{id}', function($id){


    
    $reservation = Reservation::find($id);

    $data = (object) [
        'name' => $reservation->client->name,
        'full_name' => $reservation->client->name,
        'email' => $reservation->client->email,
        'phone' => $reservation->client->cell_phone,
    ];

    $phone = $reservation->client->cell_phone;
    // $phone ="+584129707636";
    //if phone is not null or ''
    if ($phone != null && $phone !== '') {

        $fecha_reservacion = Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
        $encript_id = $reservation->encrypt_id;   

        $body="¡Ayúdanos mejorar la experiencia gastronómica en la República Dominicana! 🇩🇴
                    
Por favor, haz clic en el siguiente enlace y comparte con nosotros cómo fue tu experiencia en el restaurante de ayer. ✨ Tu opinión es muy valiosa para nosotros. ☺️

";

        
                    $body = $body . "https://reservaya.com.do/usuario/reservation/formulario-sastifacion/".$encript_id; 

$body = $body . "

*↓ ENGLISH ↓*

Help us improve the culinary experience in the Dominican Republic! 🇩🇴

Please click on the following link and share with us how your experience was at the restaurant yesterday. ✨ Your opinion is very valuable to us. ☺️

";      
        
$body = $body . "https://reservaya.com.do/usuario/reservation/formulario-sastifacion/".$encript_id; 

                    
        $params = array(
            'token' => 'ckrwcewisan28bw1',
            'to' => $phone,
            'body' => $body,
        );

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
        
        // Para el envio de la imagen 
        $params_img =array(
            'token' => 'ckrwcewisan28bw1',
            'to' => $phone,
            'image' => 'https://api.puerta21.club/public/images/logor2.png',
            'caption' => 'https://reservaya.com.do'
        );
        
        $curl_img = curl_init();
        curl_setopt_array($curl_img, array(
            CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($params_img ),
            CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
            ),
        ));
        
        $response_img = curl_exec($curl_img);
        $err_img = curl_error($curl_img);
        
        curl_close($curl_img);

        if ($err_img) {
            echo "cURL Error img #:" . $err_img;
        } else {
            echo $response_img;
        }

    }else{
        echo "no phone";
    }

    return response()->json($data);

});

Route::get('/send_rating_link', function(){

    $currentDate = Carbon::now();

    $previousDate = $currentDate->subDay()->format('Y-m-d');

    $reservations = Reservation::where('reservations_status_id', 9)
    ->whereDate('reservation_date', '=',$previousDate )->get();

    // return $reservations;

    $data =[];
    // Realizo el recorrido de los clientes encontrado que tenga numero de télefono
    foreach($reservations as $reservation){

        
        $phone = $reservation->client->cell_phone;

        if($phone != null && $phone !== ''){

            // $data[] = $reservation;

            // $fecha_reservacion = Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

            // $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;

            $encript_id = $reservation->encrypt_id;   

$body="¡Ayúdanos mejorar la experiencia gastronómica en la República Dominicana! 🇩🇴
                        
Por favor, haz clic en el siguiente enlace y comparte con nosotros cómo fue tu experiencia en el restaurante de ayer. ✨ Tu opinión es muy valiosa para nosotros. ☺️
    
";
            
$body = $body . "https://reservaya.com.do/usuario/reservation/formulario-sastifacion/".$encript_id; 


$body = $body . "

*↓ ENGLISH ↓*

Help us improve the culinary experience in the Dominican Republic! 🇩🇴

Please click on the following link and share with us how your experience was at the restaurant yesterday. ✨ Your opinion is very valuable to us. ☺️

";      
        
$body = $body . "https://reservaya.com.do/usuario/reservation/formulario-sastifacion/".$encript_id; 


            $params = array(
                'token' => 'ckrwcewisan28bw1',
                'to' => $phone,
                'body' => $body,
            );

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => http_build_query($params),
                CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
            } else {
                echo $response;
            }            
            // Para el envio de la imagen 
            $params_img =array(
                'token' => 'ckrwcewisan28bw1',
                'to' => $phone,
                'image' => 'https://api.puerta21.club/public/images/logor2.png',
                'caption' => 'https://reservaya.com.do'
            );
            
            $curl_img = curl_init();
            curl_setopt_array($curl_img, array(
                CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => http_build_query($params_img ),
                CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
                ),
            ));
            
            $response_img = curl_exec($curl_img);
            $err_img = curl_error($curl_img);
            
            curl_close($curl_img);

            if ($err_img) {
                echo "cURL Error img #:" . $err_img;
            } else {
                echo $response_img;
            }
        }
    } // End Foreach

    $data=[
        'status'    => 201,
        'resultado' => 'OK',
        'mensaje'   => 'Todo los mensajes se enviaron exitosamente'
    ];

    return $data;

});


Route::get('/send-ws-notif-confirm', function () {

    $reservation = Reservation::find(41009);


    $data_reservation = (object) [
        'reservation_eid' => $reservation->encrypt_id,
        'restaurant' => $reservation->table->restaurant->name,
        'restaurant_group_type' => $reservation->table->restaurant->group_type,
        'image' => '',
        'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
        'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
        'people' => $reservation->people,
    ];
    //return $data_reservation;
    $data_user = (object) [
        'name' => $reservation->client->name,
        'full_name' => $reservation->client->name,
        'email' => $reservation->client->email,
        'phone' => $reservation->client->cell_phone,
    ];
    //return $data_user;
    $phone = $reservation->client->cell_phone;
    //if phone is not null or ''
    if ($phone != null && $phone !== '') {

        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;


        $body =
            "*ESTIMAD@* " . $name . ":

Nos alegra recordarle su reserva de HOY en:
";
        $body = $body . "
    • *Nombre de la reserva*: " . $name . "
    • *Restaurante*: " . $reservation->table->restaurant->name . "
    • *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
    • *Número de personas*: " . $reservation->people . "
    • *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

        /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
        $body = $body . "

Le informamos que la vigencia de esta reserva son 10 minutos luego de la hora estipulada de la misma.";


$body = $body . "

Si lo desea, siempre puede

CANCELAR o MODIFICAR su reserva en el siguiente link: 🔗 

https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;


if ($reservation->restaurant_group_type !== 'donapula'){
        $body = $body . "

Le recordamos que dicho establecimiento requiere un código de vestimenta CASUAL ELEGANTE.";
}

        $body = $body . "

En el caso de que querer realizar una consulta, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.";

        $body = $body . "

Un cordial saludo,

Equipo Reserva Ya!
";


$body = $body . "
    
↓ ENGLISH ↓

*ESTIMAD@* " . $name . ":

We are pleased to remind you of your reservation TODAY at:

";

$body = $body . "
• *Reservation name*: " . $name . "
• *Restaurant*: " . $reservation->table->restaurant->name . "
• *Time*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
• *Number of people*: " . $reservation->people . "
• *Date*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

$body = $body . "

If you wish, 
     
you can always CANCEL OR MODIFY your reservation at 🔗
     
https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id . " 

Please note that this reservation is valid for 10 minutes after the scheduled time.

If you have any inquiries, please contact the restaurant directly. This phone number does not answer calls or messages.

Best regards,

@ReservaYaRD

";

$params = array(
    'token' => 'ckrwcewisan28bw1',
    'to' => $phone,
    'body' => $body,
);
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    } else {
        echo "no phone";
    }
    //return $data as response;
    return response()->json($data);
});

Route::get('/send-ws-notif-wait', function () {

    $reservation = Reservation::find(41009);


    $data_reservation = (object) [
        'reservation_eid' => $reservation->encrypt_id,
        'restaurant' => $reservation->table->restaurant->name,
        'restaurant_group_type' => $reservation->table->restaurant->group_type,
        'image' => '',
        'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
        'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
        'people' => $reservation->people,
    ];
    //return $data_reservation;
    $data_user = (object) [
        'name' => $reservation->client->name,
        'full_name' => $reservation->client->name,
        'email' => $reservation->client->email,
        'phone' => $reservation->client->cell_phone,
    ];
    //return $data_user;
    $phone = $reservation->client->cell_phone;
    //if phone is not null or ''
    if ($phone != null && $phone !== '') {
        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;



        $body =
            "*ESTIMAD@* " . $name . ":

Muchas gracias por realizar su reserva vía Reserva Ya! 😊

*Esta reserva no está confirmada*. En breves minutos le confirmaremos si hay disponibilidad para los siguientes datos:
";
        $body = $body . "
    • *Nombre de la reserva*: " . $name . "
    • *Restaurante*: " . $reservation->table->restaurant->name . "
    • *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . ".
    • *Número de personas*: " . $reservation->people . "
    • *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

        /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
        $body = $body . "
        
Si lo desea, siempre puede

CANCELAR o MODIFICAR su reserva en el siguiente link: 🔗 

https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;


        $body = $body . "

Un cordial saludo,

Equipo Reserva Ya!
";

        $params = array(
            'token' => 'ckrwcewisan28bw1',
            'to' => '+584244074025',
            'body' => $body,
        );
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    } else {
        echo "no phone";
    }
    //return $data as response;
    return response()->json($data);
});
Route::get('/send-ws-notif-cancelled', function () {
    
        $reservation = Reservation::find(41009);
    
        $data_reservation = (object) [
            'reservation_eid' => $reservation->encrypt_id,
            'restaurant' => $reservation->table->restaurant->name,
            'restaurant_group_type' => $reservation->table->restaurant->group_type,
            'image' => '',
            'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
            'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
            'people' => $reservation->people,
        ];
        //return $data_reservation;
        $data_user = (object) [
            'name' => $reservation->client->name,
            'full_name' => $reservation->client->name,
            'email' => $reservation->client->email,
            'phone' => $reservation->client->cell_phone,
        ];
        //return $data_user;
        $phone = $reservation->client->cell_phone;
        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
        return $name;
        //if phone is not null or ''
        return $reservation->client;
        if ($phone != null && $phone !== '') {


            $data = (object) [
                'data_reservation' => $data_reservation,
                'data_user' => $data_user,
            ];


$body =
"*ESTIMAD@* ".$reservation->client->name.":
Sentimos comunicarle que no hay disponibilidad para los siguientes datos:
";
$body = $body. "
*Nombre de la reserva*:" . $reservation->client->name . "
*Restaurante*: " . $reservation->table->restaurant->name . "
*Hora*: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A').".
*Número de personas*: " . $reservation->people . "
*Fecha*: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

/*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
$body = $body. "

Le invitamos a realizar una *nueva reserva a traves del siguiente enlace* https://reservaya.com.do/restaurantes";

$body = $body. "

Si desea realizar una consulta o modificar los detalles de su reserva, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.

Un cordial saludo,
Equipo reserva ya!
";

$params=array(
    'token' => 'ckrwcewisan28bw1',
    'to' => '+584244074025',
    'body' => $body,   );
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_SSL_VERIFYPEER => 0,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => http_build_query($params),
      CURLOPT_HTTPHEADER => array(
        "content-type: application/x-www-form-urlencoded"
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      echo $response;
    }


        }else{
            echo "no phone";
        }
        //return $data as response;
        return response()->json($data);
});

Route::get('/send-ws-notif', function () {

    $reservation = Reservation::find(41009);

    $data_reservation = (object) [
        'reservation_eid' => $reservation->encrypt_id,
        'restaurant' => $reservation->table->restaurant->name,
        'restaurant_group_type' => $reservation->table->restaurant->group_type,
        'image' => '',
        'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
        'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
        'people' => $reservation->people,
    ];
    //return $data_reservation;
    $data_user = (object) [
        'name' => $reservation->client->name,
        'full_name' => $reservation->client->name,
        'email' => $reservation->client->email,
        'phone' => $reservation->client->cell_phone,
    ];
    //return $data_user;
    $phone = $reservation->client->cell_phone;
    //if phone is not null or ''
    if ($phone != null && $phone !== '') {


        $data = (object) [
            'data_reservation' => $data_reservation,
            'data_user' => $data_user,
        ];
$body =
"*¡BUENAS NOTICIAS!* Su reserva ha sido confirmada *exitosamente*! 😊
*Nombre de la reserva*:" . $reservation->client->name . "
*Restaurante*: " . $reservation->table->restaurant->name . "
*Hora*: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A').".
*Número de personas*: " . $reservation->people . "
*Fecha*: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');

if ($reservation->restaurant_group_type == 'casa_de_campo'){


$body = $body. "
*IMPORTANTE:* En caso de necesitar acceso al resort, por favor póngase en contacto con el restaurante vía limoncello888@hotmail.com";
} 
if ($reservation->restaurant_group_type == 'peperoni_casa_de_campo') {

   
$body = $body. "
*IMPORTANTE:* Sólo y exclusivamente aquellos que son propietarios o invitados por un propietario podrán acceder al resort. La reserva sin previo acceso a Casa de Campo no es válida.";

}
if ($reservation->restaurant_group_type == 'cap_cana') 
{
    
$link = "https://reservaya.com.do/usuario/reservation/formulario/".$reservation->encrypt_id;


$body = $body. "
*IMPORTANTE:* Si no tiene acceso a Cap Cana, por favor, use el siguiente enlace ".$link." para completar su información y la de todos sus acompañantes para generar el código QR de acceso a Cap Cana. Su información será sólo compartida con la oficina de control de acceso a Cap Cana.";

}
if ($reservation->restaurant_group_type == 'cap_cana_maralia'){

$body = $body. "
*IMPORTANTE:* Para visitantes no proprietarios / no residentes, existe un consumo mínimo de 50 USD por persona. Por favor, descárguese la siguiente aplicación para realizar el pago:
1- IOS (App Store) https://apps.apple.com/us/app/cap-cana/id1451501100
2- Android (Play Store) https://play.google.com/store/apps/details?id=co.xhinola.capcana.guests
3- ( No es posible descargar el App desde computadora )";

}


$body = $body. "
Si lo desea, siempre puede CANCELAR su reserva en https://reservaya.com.do/usuario/mis-reservaciones";

$body = $body. "
Le informamos que debe llegar su grupo completo para concederles su mesa. 

Luego de 15 minutos pasados la hora de su reserva, la mesa será cedida.

Globos y pastel son permitidos en la mesa al momento de cantar cumpleaños.

Por favor le requerimos un código de vestimenta casual-elegante.

No se permiten:
- Sombreros
- Gorras
- Bermudas
- Chancletas
- T-Shirt sin mangas
- O bandas contratadas particularmente.
- Traer bebidas de ningun tipo.

Por favor compartir esta información con las demás personas de su grupo y reserva. 
";


if($reservation->restaurant_group_type == 'botaniko')
{


$body = $body. "    
Respetuosamente se requiere un código de vestimenta casual elegante.
Botaniko se reserva el derecho de seleccionar en la entrada.

No se permiten:
- T-shirt o camisetas de hombre sin mangas
- Gorras
- Bermudas
- Jeans rotos
- Escotes pronunciados
- Faldas cortas
- Cinturas descubiertas
- Chancletas

Por favor compartir esta información con las demás personas de su grupo y reserva. ¡Le esperamos!";

}
if($reservation->restaurant_group_type == 'peperoni')
{


$body = $body. "
Respetuosamente requerimos un código de vestimenta CASUAL ELEGANTE. Queda bajo nuestra discreción el derecho de admisión.
No se permiten:
- Gorras
- Bermudas
- Jeans rotos
- Escotes pronunciados
- Faldas cortas
- Cinturas descubiertas
- Chancletas
- jeans rotos
- camisa o tshirt de hombres sin manga

Si no cumple con nuestro código de vestimenta, no se le permitirá la entrada ni permanecer en el establecimiento.
Por favor compartir esta información con las demás personas de su reserva. Le esperamos!";

}
$body = $body. "
Si desea realizar una consulta o modificar los detalles de su reserva, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.

Un cordial saludo,
Equipo reserva ya!
";
        
$params=array(
    'token' => 'ckrwcewisan28bw1',
    'to' => '+584244074025',
    'body' => $body,   );
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_SSL_VERIFYPEER => 0,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => http_build_query($params),
      CURLOPT_HTTPHEADER => array(
        "content-type: application/x-www-form-urlencoded"
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    $params=array(
        'token' => 'ckrwcewisan28bw1',
        'to' => '+584244074025',
        'image' => 'https://api.puerta21.club/public/images/ht.jpg',
        'caption' => 'https://instagram.com/beautycornerrd?igshid=MzRlODBiNWFlZA=='
        );
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => http_build_query($params),
          CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      echo $response;
    }
    } else {
        echo "no phone";
    }
    //return $data as response;
    return response()->json($data);
});

Route::get('/', function () {

    return view('welcome');

    // return "200";

    //return redirect('/doc');

});
Route::get('/phpinfo', function () {

    return phpinfo();
});
//fix images
Route::get('/fix-images', function () {

    $restaurants = Restaurant::all();

    //loop restaurants 
    foreach ($restaurants as $restaurant) {

        $source = $restaurant->cover;

        if ($source != null && $source !== '') {
            echo $source;
            echo '<br>';
            $img = Image::make($source);
            //$img->resize(800, 600);
            //use 800 for 600px height
            $img->resize(800, null, function ($constraint) {
                $constraint->aspectRatio();
            });

            //generate random filename
            $filename = Str::random(10) . '800.jpg';
            $img->save('public/thumbnails/' . $filename);
            $restaurant->thumbnail = $filename;
            $restaurant->save();
        }
    }
    echo "done";
});

//fix images
Route::get('/fix-images-webp', function () {

    $restaurants = Restaurant::all();

    //loop restaurants 
    foreach ($restaurants as $restaurant) {

        $source = $restaurant->cover;

        if ($source != null && $source !== '') {
            echo $source;
            echo '<br>';
            $img = Image::make($source);
            $img->resize(1280, 720);
            $img->encode('webp', 75);
            //use 800 for 600px height

            //generate random filename
            $filename = Str::random(10) . '800.webp';
            $img->save('public/webp/' . $filename);
            $restaurant->webp = $filename;
            $restaurant->save();
        }
    }
    echo "done";
});


//test-images
Route::get('/test-images', function () {

    $restaurants = Restaurant::all();

    return $restaurants;
});
Route::get('/storage/{url}', function ($url) {

    return $url;
});

Route::get('/mailable/{mailview}', 'MailableController@renderMailable');



// Route::get('/mailable', function () {

//     return view('mails.reset_password');

// });

Route::get('accept', function () {

    $data_user = (object) [
        'name' => 'Juan',
        'full_name' => 'Juan Perez',
        'email' => 'ghatiko_chemako@hotmail.com',
    ];

    $data_reservation = (object) [
        'reservation_eid' => 'eyJpdiI6IldqQUQrM1FEZGZLMEM2ZWthMksrMVE9PSIsInZhbHVlIjoiUE5kWVwvVlAzK1pFWml3OGI3S1pPd2c9PSIsIm1hYyI6ImZhNjY0ZDA0MzcwODcwMDJiZjA3YTcyYzg3YjAyYWUyZTNkZmZhYTFkMDRjMjE2YzZiOTVhNDA5YTZlNzAxZDkifQ%3D%3D',
        'restaurant' => 'Restaurant 1',
        'restaurant_group_type' => 'cap_cana',
        'image' => 'https://via.placeholder.com/150',
        'date' => '20 julio 2022',
        'hour' => '8pm',
        'people' => 2,
    ];

    return new CancelledReservation($data_reservation, $data_user);
});

Route::get('updateR', function () {
    $reservation = Reservation::find(10522);
    $reservation->encrypt_id = encrypt($reservation->id);
    $reservation->save();

    $reservation->refresh();
    dd($reservation);
});
