<?php



return [

    'landing_page_dev'  => env('LANDING_DEV',       'https://dev.puerta21.club/'),

    'restaurant_dev'    => env('RESTAURANT_DEV',    'https://dev.restaurantes.puerta21.club/'),

    'api_dev'           => env('API_DEV',           'https://api-dev.puerta21.club/api/v1'),



    'landing_page_qa'   => env('LANDING_QA',        'https://qa.puerta21.club/'),

    'restaurant_qa'     => env('RESTAURANT_QA',     'https://qa.restaurantes.puerta21.club/ '),

    'api_qa'            => env('API_QA',            'https://api-qa.puerta21.club/api/v1'),



    // 'landing_page_prod' => env('LANDING_PROD',      'https://puerta21.club/'),

    'landing_page_prod' => env('LANDING_PROD',      'https://api.puerta21.club/'),

    'resturant_prod'    => env('RESTAURANT_PROD',   'https://restaurantes.puerta21.club/'),

    'api_prod'          => env('API_PROD',          'https://api-prod.puerta21.club/api/v1'),

];

