<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Número de reservas</th>
            <th>Restaurantes visitados</th>
            <th>Colaboración</th>
            <th>Invitación</th>
            <th>Estatus</th>
            <th>Amigo</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($clients as $client)
            <tr>
                <td>{{ $client->first_name .' '. $client->middle_name.' '.$client->last_name  }}</td>
                <td>{{ $client->reservations }}</td>
                <td>{{ $client->restaurants }}</td>
                <td>{{ $client->collaborator }}</td>
                <td>{{ $client->invitations }}</td>
                <td>{{ $client->client_status }}</td>
                <td>{{ $client->friend }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
