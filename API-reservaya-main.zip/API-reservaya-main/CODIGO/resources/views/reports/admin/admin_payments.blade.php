<table>
    <thead>
        <tr>
            <th>Restaurante</th>
            <th>Total a pagar</th>
            <th>Estatus de pago</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($payments as $payment)
            <tr>
                <td>{{ $payment->name }}</td>
                <td>{{ $payment->amount }}</td>
                <td>{{ $payment->status }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
