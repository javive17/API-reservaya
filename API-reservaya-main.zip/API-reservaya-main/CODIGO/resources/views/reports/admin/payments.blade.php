<table>
    <thead>
        <tr>
            <th>Restaurante</th>
            <th>Monto</th>
            <th>Restaurantes visitados</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($payments as $payment)
            <tr>
                <td>{{ $payment->name }}</td>
                <td>{{ $payment->amount }}</td>
                <td>{{ $payment->status }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
