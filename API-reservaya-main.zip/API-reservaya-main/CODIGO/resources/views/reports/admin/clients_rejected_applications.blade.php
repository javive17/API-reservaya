<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Colaboración</th>
            <th>Invitación</th>
            <th>Fecha Solicitud</th>
            <th>Facebook</th>
            <th>Instagram</th>
            <th>LinkedIn</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($clients as $client)
            <tr>
                <td>{{ $client->first_name .' '. $client->middle_name.' '.$client->last_name  }}</td>
                <td>{{ $client->collaborator }}</td>
                <td>{{ $client->invitations }}</td>
                <td>{{ $client->date }}</td>
                <td>{{ $client->facebook }}</td>
                <td>{{ $client->instagram }}</td>
                <td>{{ $client->linkedin }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
