<table>
    <thead>

        <tr>
            <th>Nombre</th>
            <th>Fecha reservación</th>
            <th>Número de personas</th>
            <th>Costo de la cuenta</th>
            <th>Comisión a pagar</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($charges as $value)
            <tr>
                <td>{{ $value->client_name }}</td>
                <td>{{ $value->reservation_date }}</td>
                <td>{{ $value->people }}</td>
                <td>{{ $value->bill }}</td>
                <td>{{ $value->commission_to_pay }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
