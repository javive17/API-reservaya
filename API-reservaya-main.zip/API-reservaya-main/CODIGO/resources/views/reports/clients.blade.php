<table>
    <thead>
        <tr>
            <th>{{$type}}</th>
        </tr>
        <tr>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Categoría</th>
            <th>Telefono</th>
            <th>Número de visitas</th>
            <th>Gasto total</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($clients as $client)
            <tr>
                <td>{{ $client->first_name .' '. $client->middle_name.' '.$client->last_name  }}</td>
                <td>{{ $client->email }}</td>
                <td>{{ $client->categories }}</td>
                <td>{{ $client->phone }}</td>
                <td>{{ $client->visits }}</td>
                <td>{{ $client->total_spend }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
