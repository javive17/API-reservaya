<!DOCTYPE html>
<html>
<head>
<title>Invitación al club exclusivo Puerta 21</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<style type="text/css">
    
    /* FONTS */
    @import url("https://use.typekit.net/jkz5ggt.css");
    
    /* CLIENT-SPECIFIC STYLES */
    body{background-color: #fff}
    body, table, td, a{-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%;} /* Prevent WebKit and Windows mobile changing default text sizes */
    table, td{mso-table-lspace: 0pt; mso-table-rspace: 0pt;} /* Remove spacing between tables in Outlook 2007 and up */
    img{-ms-interpolation-mode: bicubic;} /* Allow smoother rendering of resized image in Internet Explorer */

    /* RESET STYLES */
    img{border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none;}
    table{border-collapse: collapse !important;}
    body{height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important;}

    /* iOS BLUE LINKS */
    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    /* MOBILE STYLES */
    @media screen and (max-width: 525px) {

        /* ALLOWS FOR FLUID TABLES */
        .wrapper {
          width: 100% !important;
            max-width: 100% !important;
        }

        /* ADJUSTS LAYOUT OF LOGO IMAGE */
        .logo img {
          margin:  24px 32px !important;
        }

        /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */
        .mobile-hide {
          display: none !important;
        }

        .img-max {
          max-width: 100% !important;
          width: 100% !important;
          height: auto !important;
        }

        /* FULL-WIDTH TABLES */
        .responsive-table {
          width: 100% !important;
        }

        /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */
        .padding {
          padding: 20px 5% 20px 5% !important;
        }

        .padding-meta {
          padding: 30px 5% 0px 5% !important;
          text-align: center;
        }

        .padding-copy {
        padding: 20px 5% 20px 5% !important;
          text-align: center;
        }

        .no-padding {
          padding: 0 !important;
        }

        .section-padding {
          padding: 50px 15px 50px 15px !important;
        }

        /* ADJUST BUTTONS ON MOBILE */
        .mobile-button-container {
            
            width: 100% !important;
        }

        .mobile-button {
            padding: 15px !important;
            border: 0 !important;
            font-size: 20px !important;
            display: block !important;
        }

    }

    /* ANDROID CENTER FIX */
    div[style*="margin: 5px 0;"] { margin: 0 !important; }
</style>
</head>
<body style="margin: 0 !important; padding: 0 !important;">

<!-- HEADER 02-->
<table border="0" cellpadding="0" cellspacing="0" width="400px" align="center">
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="margin-top: 10%;">
    <tr>
        <td bgcolor="#ffffff" align="center" style="margin-top: 20px; border-radius: 20px 20px 0px 0px;">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
            <tr>
            <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 700px;" class="wrapper"> 
                <tr>
                    <td align="center" valign="top" class="logo">
                        <a href="#" target="_blank">
                            <img alt="Logo" src="https://raw.githubusercontent.com/cristianosom/ckoko/master/welcome.png" width="70%px" style="display: block; font-family: 'Roboto', sans-serif; color: #ffffff; font-size: 20px; margin-top: 32px;" border="0">
                        </a>
                    </td>
                </tr>
            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 15px; border-radius: 0px 0px 20px 20px;">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
            <tr>
            <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 500px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- SPANISH -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td align="center" style="padding: 20px 0 10px 0; font-size: 14px; line-height: 25px; font-family: commuters-sans, sans-serif; font-weight: 300; color: #000000; text-transform: uppercase;" class="padding-copy">Tenemos el placer de enviarle esta invitación para acceder al club gastronómico privado PUERTA 21.
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 20px 0 20px 0; font-size: 14px; line-height: 25px; font-family: commuters-sans, sans-serif; font-weight: 300; color: #000000; text-transform: uppercase;" class="padding-copy">Para acceder, utilice su dirección de correo electrónico y la siguiente contraseña provisional:
                            </tr>
                            <tr>
                                <td align="center" style="padding: 20px 0 4px 0; font-size: 12px; line-height: 25px; font-family: commuters-sans, sans-serif; font-weight: 700; color: #000000; text-transform: uppercase;" class="padding-copy">Contraseña
                                </td>
                            </tr>
                            <tr>
                                <td bgcolor="#eee" align="center" style="padding: 20px 0 10px 0; font-size: 18px; line-height: 25px; letter-spacing: 4px; font-family: commuters-sans, sans-serif; font-weight: 700; color: #000000;" class="padding-copy">{{ $password }}
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="padding: 40px 0 10px 0; font-size: 14px; font-weight: 300; line-height: 25px; font-family: commuters-sans, sans-serif; text-transform: uppercase; font-weight: 300; color: #000000;" class="padding-copy">Descárguese nuestra aplicación y descubra nuestro servicio concierge.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 500px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- SPANISH -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td align="center" style="padding-top: 30px;" class="padding-copy"><a href=""><img src="https://user-images.githubusercontent.com/47791033/108297935-aa6d7a80-7161-11eb-8bb7-8a6e832525f3.png" alt=""></a></td>
                            </tr>
                            <tr>
                                <td align="center" style="padding-top: 10px;" class="padding-copy"><a href=""><img src="https://user-images.githubusercontent.com/47791033/108297937-aa6d7a80-7161-11eb-851d-db6b46ce12cd.png" alt=""></a></td>
                            </tr>                          
                        </table>
                    </td>
                </tr>
            </table>
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 500px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- SPANISH -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td align="center" style="padding: 30px 0 40px 0; font-size: 14px; line-height: 25px; font-family: commuters-sans, sans-serif; font-weight: 300; color: #000000; text-transform: uppercase;" class="padding-copy">Atentamente, Equipo Puerta 21
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>  
</table>

</td>
</tr>
</table>

</body>
</html>