@component('mail::message')

<table style="margin:auto; width:100%;margin-bottom:15px;">
    <tr>
        <td align="center" style="text-align: center;">
            <p class="text-center" style="text-align: center;">Publicidad</p>
            <img src="{{ url('storage/images/rensa-new.png') }}" alt="publicidad"
                    style="display: inline-block;" />
        </td>
    </tr>
</table>

<div style="text-align: center;">
    <strong style="font-size:18px;text-align: center;margin-bottom:10px;display:block">ESTIMAD@ {{ Str::upper($user->name) }}:</strong>
    <p style="font-size:16px;">Oops! &#128584 Sentimos comunicarle que no hay disponibilidad para los siguientes datos:</p>
</div>

<div>
    <ul>
        <li>
            <p>
                <strong>
                    Nombre de la reserva:
                </strong>
                <span>{{ $user->full_name }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Restaurante:
                </strong>
                <span>{{ $reservation->restaurant }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Hora:
                </strong>
                <span>{{ $reservation->hour }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Número de personas:
                </strong>
                <span>{{ $reservation->people }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Fecha:
                </strong>
                <span>{{ $reservation->date }}</span>
            </p>
        </li>
    </ul>
</div>

<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p>


<p style="margin-top: 20px">
    Un cordial saludo,<br>
</p>
<p style="margin-top:0">
    Equipo reserva ya!
</p>

@component('mail::button', ['url' => 'https://reservaya.com.do/restaurantes', 'color' => 'primary'])
HACER UNA NUEVA RESERVA
@endcomponent

@endcomponent
