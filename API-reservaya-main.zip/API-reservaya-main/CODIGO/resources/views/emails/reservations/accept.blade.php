@component('mail::message')

<table style="margin:auto; width:100%;margin-bottom:15px;">
    <tr>
        <td align="center" style="text-align: center;">
            <p class="text-center" style="text-align: center;">Publicidad</p>
            <img src="{{ url('storage/images/rensa-new.png') }}" alt="publicidad"
                    style="display: inline-block;" />
        </td>
    </tr>
</table>

<div style="text-align: center;">
    <strong style="font-size:18px;text-align: center;margin-bottom:10px;display:block">ESTIMAD@ {{ Str::upper($user->name) }}:</strong>
    <p style="font-size:16px;text-align: center;"> <strong>¡BUENAS NOTICIAS!</strong> Su reserva ha sido confirmada <strong>exitosamente</strong>!
        😊</p>
</div>

<table style="margin:auto; width:100%;">
    <tr>
        <td align="center" style="text-align: center;">
            <img src="{{ $reservation->image ?? asset('/images/one-picture.png') }}" alt="{{ $reservation->restaurant }}"
                    style="display: inline-block;" />
        </td>
    </tr>
</table>

<div>
    <ul>
        <li>
            <p>
                <strong>
                    Nombre de la reserva:
                </strong>
                <span>{{ $user->full_name }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Restaurante:
                </strong>
                <span>{{ $reservation->restaurant }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Hora:
                </strong>
                <span>{{ $reservation->hour }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Número de personas: 
                </strong>
                <span>{{ $reservation->people }}</span>
            </p>
        </li>
        <li>
            <p>
                <strong>
                    Fecha:
                </strong>
                <span>{{ $reservation->date }}</span> 
            </p>
        </li>
    </ul>
</div> 
@if ($reservation->restaurant_group_type == 'casa_de_campo') 
<span style="display: block;margin-top:30px;font-weight: 500;color: #ffffff;background-color:black;padding:15px;"> 
    <strong style="color:red;">IMPORTANTE:</strong> <p>En caso de necesitar acceso al resort, por favor póngase en contacto con el restaurante vía <a href="mailto:limoncello888@hotmail.com" target="_blank">limoncello888@hotmail.com</a></p>
</span> 
@endif
@if ($reservation->restaurant_group_type == 'peperoni_casa_de_campo') 
<span style="display: block;margin-top:30px;font-weight: 500;color: #ffffff;background-color:black;padding:15px;"> 
    <strong style="color:red;">IMPORTANTE:</strong> <p>Sólo y exclusivamente aquellos que son propietarios o invitados por un propietario podrán acceder al resort. La reserva sin previo acceso a Casa de Campo no es válida.</p>
</span> 
@endif
@if ($reservation->restaurant_group_type == 'cap_cana') 
<span style="display: block;margin-top:30px;font-weight: 500;color: #ffffff;background-color:black;padding:15px;"> 
    <strong style="color:red;">IMPORTANTE:</strong> <p>Si no tiene acceso a Cap Cana, por favor, <a href="https://reservaya.com.do/usuario/reservation/formulario/{{ $reservation->reservation_eid }}" target="_blank" style="color:#00aceb;"><strong>COMPLETE SUS DATOS</strong></a> y la de <strong>todos</strong> sus acompañantes para generar el código QR de acceso a Cap Cana. Su información será sólo compartida con la oficina de control de acceso a <br>Cap Cana.</p>
</span> 
@endif
@if ($reservation->restaurant_group_type == 'cap_cana_maralia')
<span style="display: block;margin-top:30px;font-weight: 500;color: #ffffff;background-color:black;padding:15px;">
    <strong style="color:red;">IMPORTANTE:</strong> Para visitantes no proprietarios / no residentes, existe un consumo mínimo de 50 USD por persona. Por favor, descárguese la siguiente aplicación para realizar el pago:
    <p style="margin-top: 20px;margin-bottom: 0px;">1- <a href="https://apps.apple.com/us/app/cap-cana/id1451501100" target="_blank" style="color:#00aceb;"><strong>IOS (App Store)</strong></a></p>
    <p style="margin-bottom: 0px;">2- <a href="https://play.google.com/store/apps/details?id=co.xhinola.capcana.guests" target="_blank" style="color:#00aceb;"><strong>Android (Play Store)</strong></a></p>
    <p style="margin-bottom: 0px;">3- ( No es posible descargar el App desde computadora )</p>
</span>
@endif
<span style="display: block;margin-top:30px;">
    Si lo desea, siempre puede <a href="https://reservaya.com.do/usuario/mis-reservaciones" target="_blank"  style="color: #008eff">CANCELAR</a> su reserva.
</span>

@if($reservation->restaurant_group_type == 'zuquero')
<div style="margin-top: 20px;"> 
    <p>
    Le informamos que debe llegar su grupo completo para concederles su mesa. Luego de 15 minutos pasados la hora de su reserva, la mesa será cedida. Globos y pastel son permitidos en la mesa al momento de cantar cumpleaños.
    </p>
    <p >
    Por favor le requerimos un código de vestimenta casual. 
    </p>
    <p >
    No se permiten:
    </p>
    <ul>
        <li>Sombreros</li>
        <li>Gorras</li>
        <li>Bermudas</li>
        <li>Chancletas</li>
        <li>T-Shirt sin mangas</li>
        <li>O bandas contratadas particularmente.</li>
        <li>Traer bebidas de ningun tipo.</li>
    </ul>
    <p>
    Por favor compartir esta información con las demás personas de su grupo y reserva. ¡Le esperamos!
    </p>
</div>
@elseif($reservation->restaurant_group_type == 'botaniko')
<div style="margin-top: 20px;"> 
    <p>
    Respetuosamente se requiere un código de vestimenta casual elegante.
    </p>
    <p >
    Botaniko se reserva el derecho de seleccionar en la entrada.
    </p>
    <p >
    No se permiten:
    </p>
    <ul>
        <li>T-shirt o camisetas de hombre sin mangas</li>
        <li>Gorras</li>
        <li>Bermudas</li>
        <li>Jeans rotos</li>
        <li>Escotes pronunciados</li>
        <li>Faldas cortas</li>
        <li>Cinturas descubiertas</li>
        <li>Chancletas</li>
    </ul>
    <p>
    Por favor compartir esta información con las demás personas de su grupo y reserva. ¡Le esperamos!
    </p>
</div>
@elseif($reservation->restaurant_group_type == 'peperoni')
<div style="margin-top: 20px;"> 
    <p >
    Respetuosamente requerimos un código de vestimenta CASUAL ELEGANTE. Queda bajo nuestra discreción el derecho de admisión. 
    </p>
    <p >
    No se permiten:
    </p>
    <ul>
        <li>Gorras</li>
        <li>Bermudas</li>
        <li>Jeans rotos</li>
        <li>Escotes pronunciados</li>
        <li>Faldas cortas</li>
        <li>Cinturas descubiertas</li>
        <li>Chancletas</li>
        <li>jeans rotos</li>
        <li>camisa o tshirt de hombres sin manga</li>
    </ul>
    <p>
    Si no cumple con nuestro código de vestimenta, no se le permitirá la entrada ni permanecer en el establecimiento. 
    </p>
    <p>
    Por favor compartir esta información con las demás personas de su reserva. Le esperamos! 
    </p> 
</div>
@else
<div style="margin-top: 20px;"> 
    <p>
        Le informamos que la vigencia de esta reserva son 10 minutos luego de la hora estipulada de la misma.
    </p>
    <p >
        Le recordamos que dicho establecimiento requiere un código de vestimenta CASUAL ELEGANTE.
    </p>
</div>
@endif

<p style="margin-top: 20px;">
Si desea realizar una consulta, por favor, pongase en contacto directamente con el restaurante. Reserva Ya es una plataforma digital que permite al comensal reservar mesa en un restaurante sin necesidad de llamar o escribir al restaurante.<br>
</p> 

<p style="margin-top: 20px;">
    Un cordial saludo,<br>
</p>

<p style="margin-top:0;"> 
    Equipo reserva ya!
</p>

@component('mail::button', ['url' => 'https://reservaya.com.do/restaurantes', 'color' => 'primary'])
HACER UNA NUEVA RESERVA
@endcomponent

@endcomponent