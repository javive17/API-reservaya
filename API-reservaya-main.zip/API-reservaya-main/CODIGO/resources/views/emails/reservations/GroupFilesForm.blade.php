@component('mail::message')

<table style="margin:auto; width:100%;margin-bottom:15px;">
    <tr>
        <td align="center" style="text-align: center;">
            <p class="text-center" style="text-align: center;">Publicidad</p>
            <img src="{{ asset('/public/images/rensa-new.png') }}" alt="publicidad"
                    style="display: inline-block;" />
        </td>
    </tr>
</table>

<table style="margin:auto; width:100%;">
    <tr>
        <td align="center" style="text-align: center;">
            <img src="{{ $reservation->image ?? asset('/images/one-picture.png') }}" alt="{{ $reservation->restaurant }}"
                    style="display: inline-block;" />
        </td>
    </tr>
</table>

<div style="text-align: start;">
    <strong style="font-size:18px;text-align: start;margin-bottom:10px;display:block;color:#000000;">¡Hola!</strong>
    <p style="font-size:16px;text-align: start;color:#000000;">Tenemos el placer de comunicarle  que se ha realizado una reserva vía <strong>Reserva Ya</strong>!
        😊</p>
</div>

<div style="text-align: start; margin-top:10px;">
    <p style="text-align: start;color:#000000;">Por favor, ver más abajo la información de la reserva:</p>
</div>

<div>
    <ul>
        <li>
            <p style="color: #000000;">
                <strong>
                    Nombre:
                </strong>
                <span>{{ $user->name }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Apellido:
                </strong>
                <span>{{ $user->lastName }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Correo electrónico:
                </strong>
                <span>{{ $user->email }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Fecha:
                </strong>
                <span>{{ $reservation->date }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Hora:
                </strong>
                <span>{{ $reservation->hour }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Número de personas:
                </strong>
                <span>{{ $reservation->people }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Nombre del restaurante:
                </strong>
                <span>{{ $reservation->restaurant }}</span>
            </p>
        </li>
        <li>
            <p style="color: #000000;">
                <strong>
                    Contacto del cliente:
                </strong>
                <span>{{ $user->phone }}</span>
            </p>
        </li>
    </ul>
</div>
<span style="display: block;margin-top:30px;color:black;">
    Le adjuntamos la identificación de los clientes para que pueda generar los pases.
</span>

<p style="margin-top: 20px;color:#000000">
    Muchas gracias y feliz día,<br>
</p>
<p style="margin-top:0;color:#000000">
    Equipo Reserva Ya!
</p>

@endcomponent
