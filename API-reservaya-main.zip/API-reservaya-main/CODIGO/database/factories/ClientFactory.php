<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Client;
use Faker\Generator as Faker;
use Faker\Provider\uk_UA\PhoneNumber;

$factory->define(Client::class, function (Faker $faker) {
    return [
        'encrypt_id' => encrypt(16),
        'first_name'=> $faker->name,
        'middle_name' => $faker->lastName,
        'last_name'  => $faker->lastName,
        'cell_phone' => $faker->phoneNumber,
        'description' =>$faker->text,
        'gender_id' => 1,
        'country_id' => 2,
        'user_id' => 1,
        'client_status_id' => null,
        'collaborator_id' => null,
    ];
});
