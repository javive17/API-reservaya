<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClientStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $table_name = 'c_client_status';
        DB::table($table_name)->insert([
            ['name' => 'Aceptado'],
            ['name' => 'Invitado'],
            ['name' => 'Pendiente'],
            ['name' => 'Rechazado'],
            ['name' => 'Publico general'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where('id', $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
