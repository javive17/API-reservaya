<?php

use Illuminate\Database\Seeder;

class FoodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = 'c_foods';
        DB::table($table_name)->insert([
            ['name' => 'LIGEROS'],
            ['name' => 'CONTUNDENTES'],
            ['name' => 'SALADOS'],
            ['name' => 'DULCES'],
            ['name' => 'TRADICIONALES'],
            ['name' => 'FUSIÓN'],
            ['name' => 'MARISCOS'],
            ['name' => 'CARNE ROJA'],
            ['name' => 'CERDO'],
            ['name' => 'CHORIZO'],
            ['name' => 'PLATOS GRASOS'],
            ['name' => 'PICANTE'],
            ['name' => 'REMOLACHA'],
            ['name' => 'PEPINO'],
            ['name' => 'COCO'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
