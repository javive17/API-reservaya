<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $table_name = 'c_categories';
        DB::table($table_name)->insert([
            ['name' => 'Blacklist'],
            ['name' => 'Internacional'],
            ['name' => 'Vegano'],
            ['name' => 'VIP'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where('id', $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
