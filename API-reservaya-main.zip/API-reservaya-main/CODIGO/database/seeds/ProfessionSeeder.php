<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProfessionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = 'c_professions';
        DB::table($table_name)->insert([
            ['name' => 'EMBAJADOR/A'],
            ['name' => 'ABOGADO/A'],
            ['name' => 'EMPRESARIO/A'],
            ['name' => 'CANTANTE'],
            ['name' => 'POLÍTICO/A'],
            ['name' => 'FINANCIERO/A'],
            ['name' => 'PERIODISTA'],
            ['name' => 'ACTOR / ACTRIZ'],
            ['name' => 'HOTELERO'],
            ['name' => 'INFLUENCER'],
            ['name' => 'PRESENTADOR/A DE TELEVISIÓN'],
            ['name' => 'MARKETING'],
            ['name' => 'MODA'],
            ['name' => 'MODELO'],
            ['name' => 'PINTOR'],
            ['name' => 'ARTISTA'],
            ['name' => 'ESTUDIANTE'],
            ['name' => 'OTROS'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
