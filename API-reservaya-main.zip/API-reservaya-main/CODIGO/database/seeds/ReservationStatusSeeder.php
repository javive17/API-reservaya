<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ReservationStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = "c_reservations_status";
        DB::table($table_name)->insert([
            ['name'=>'EN ESPERA','created_at'=>now()],
            ['name'=>'HA ASISTIDO','created_at'=>now()],
            ['name'=>'SE HA IDO','created_at'=>now()],
            ['name'=>'NO SHOW','created_at'=>now()],
            ['name'=>'CANCELADO','created_at'=>now()],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
