<?php

use Illuminate\Database\Seeder;
use App\Models\Table;
use App\Models\Catalogs\TableType;

class TableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $faker = \Faker\Factory::create();


        $tabletypes = TableType::all();
        foreach ($tabletypes as $value) {
            $table = Table::create(
                [
                  'capacity' =>  $faker->numberBetween(1,30),
                  'table_type_id'=>$value->id,
                  'restaurant_id'=>1
                ]
            );

            $table->encrypt_id =  encrypt($table->id);
            $table->save();

        }
    }
}
