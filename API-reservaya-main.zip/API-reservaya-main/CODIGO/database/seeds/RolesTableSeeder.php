<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        DB::table('c_roles')->insert([
            ['name' => 'Administrador', 'key' => 'admin', 'description' => "Administrador"],
            ['name' => 'Usuario', 'key' => 'general_user', 'description' => "Usuario que podrá acceder a las aplicaciones con usuario y contraseña y se podrá registrar únicamente con invitación."],
            ['name' => 'Gerente', 'key' => 'manager_user', 'description' => "Usuario que podrá acceder al sitio web de restaurantes"],
            ['name' => 'Hostess', 'key' => 'hostess_user', 'description' => "Usuario que podrá acceder al sitio web de restaurantes"],


        ]);

        $all = DB::table('c_roles')->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table('c_roles')->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
