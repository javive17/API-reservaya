<?php

use Illuminate\Database\Seeder;
use App\Models\RestaurantPhoto;

class RestaurantPhotoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create();

        for($i=1;$i<=10;$i++){
            $restaurantPhoto = RestaurantPhoto::create(
                [
                    'url'=> $faker->url,
                    'order_photos'=>$i,
                    'restaurant_id' =>1,
                ]

            );
            $restaurantPhoto->encrypt_id =  encrypt($restaurantPhoto->id);
            $restaurantPhoto->save();

        }

    }
}
