<?php

use App\Models\Rating;
use Illuminate\Database\Seeder;

class RatingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $faker = \Faker\Factory::create();

        $rating = new Rating([
            'comment' => $faker->text(200),
            'reply' => $faker->text(200),
            'client_id' => 1,
            'reservation_id' => 1,
        ]);

        $rating->save();
        $rating->encrypt_id = encrypt($rating->id);
        $rating->save();
    }
}
