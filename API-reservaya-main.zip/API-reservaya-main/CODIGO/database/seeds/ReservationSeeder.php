<?php

use App\Models\Reservation;
use Illuminate\Database\Seeder;

class ReservationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $now = date('Y-m-d H:i:s');
        $reservationDate = date('Y-m-d H:i', strtotime($now.'+2 day'));
        $reservation = Reservation::create([
            'reservation_date' => $reservationDate,
            'people' => 10,
            'check_in' => date('Y-m-d H:i', strtotime($reservationDate.'+1 hour')),
            'check_out' => date('Y-m-d H:i', strtotime($reservationDate.'+3 hour')),
            'bill' => 200.5,
            'comments' => 'sfdsfdsfdsf',
            'ticket_photo' => 'sdfsdfsdfds',
            'reservations_status_id' => 3,
            'client_id' => 1,
            'table_id' => 1,
        ]);

        $reservation->encrypt_id = encrypt($reservation->id);
        $reservation->save();
    }
}
