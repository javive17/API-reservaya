<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run()
    {
        $this->call([
            PublicationTypeSeeder::class,
            RolesTableSeeder::class,
            DaysSeeder::class,
            AddressSeeder::class,
            CostSeeder::class,
            KitchensSeeder::class,
            ExtraServiceSeeder::class,
            TableTypeSeeder::class,
            CountrySeeder::class,
            ZoneSeeder::class,
            SuburbSeeder::class,
            RestaurantSeeder::class,
            PaymentStatusSeeder::class,
            // RestaurantPhotoSeeder::class,
            TableSeeder::class,
            RestaurantServiceDaySeeder::class,
            UsersTableSeeder::class,
            ClientStatusSeeder::class,
            SocialMediaSeeder::class,
            GenderSeeder::class,
            ProfessionSeeder::class,
            IndustrySeeder::class,
            NutritionalRequirementSeeder::class,
            AllergySeeder::class,
            TableCatalogSeeder::class,
            DrinkSeeder::class,
            FoodSeeder::class,
            ClientSeeder::class,
            ReservationStatusSeeder::class,
            // ReservationSeeder::class,
            CategorySeeder::class,
            // RatingSeeder::class,
        ]);
    }
}
