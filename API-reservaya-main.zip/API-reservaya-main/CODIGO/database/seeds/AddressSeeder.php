<?php

use Illuminate\Database\Seeder;
use App\Models\Address;

class AddressSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $faker = \Faker\Factory::create();

        $address = Address::create([
            'latitude' => $faker->latitude,
            'longitude'=> $faker->longitude,
            'address' => $faker->address,
        ]);

        $address->encrypt_id = encrypt($address->id);
        $address->save();
    }
}
