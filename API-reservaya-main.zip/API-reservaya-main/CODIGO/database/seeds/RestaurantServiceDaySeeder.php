<?php

use Illuminate\Database\Seeder;
use App\Models\Catalogs\Day;
use App\Models\RestaurantServiceDay;

class RestaurantServiceDaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create();

        $tabletypes = Day::all();
        foreach ($tabletypes as $value) {
            $table = RestaurantServiceDay::create([
                    'opening'       => '9:00',
                    'closing'       => '23:00',
                    'day_id'        => $value->id,
                    'restaurant_id' => 1,
                    'status'        => 1
            ]);
            $table->encrypt_id = encrypt($table->id);
            $table->save();
        }
    }
}
