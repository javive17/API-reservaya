<?php

use Illuminate\Database\Seeder;

class KitchensSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = 'c_kitchens';
        DB::table($table_name)->insert([
            ['name' => 'Americana'],
            ['name' => 'Italiana'],
            ['name' => 'Cortes de carne'],
            ['name' => 'Pescados y Mariscos'],
            ['name' => 'Francesa'],
            ['name' => 'Dominicana'],
            ['name' => 'Mexicana'],
            ['name' => 'Japonesa'],
            ['name' => 'Española'],
            ['name' => 'Pizzeria'],
            ['name' => 'Fusión'],
            ['name' => 'BBQ'],
            ['name' => 'Tapas / Botanas'],
            ['name' => 'Argentina'],
            ['name' => 'Hamburguesas'],
            ['name' => 'Brasileña'],
            ['name' => 'Cortes finos'],
            ['name' => 'Asiática'],
            ['name' => 'Latinoamericana'],
            ['name' => 'Mediterránea'],
            ['name' => 'Peruana'],
            ['name' => 'Pollo asado'],
            ['name' => 'Bar de vinos'],
            ['name' => 'Ramen'],
            ['name' => 'Internacional'],
            ['name' => 'Hindú'],
            ['name' => 'Vegetariana / Vegana'],
            ['name' => 'Gastrobar'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
