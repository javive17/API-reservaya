<?php

use Illuminate\Database\Seeder;
use App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = \date('Y-m-d H:i:s');

        $users = [
            ['name' => 'admin',     'role' => 1],
            ['name' => 'manager',   'role' => 3],
            ['name' => 'host',      'role' => 4],
            ['name' => 'client',    'role' => 2],
            ['name' => 'maria',     'role' => 1],
        ];

        foreach ($users as $u) {
            if($u['name'] === "maria"){
                $email = 'maria.abellan.adt@gmail.com';
            } else {
                $email = $u['name'].'@kokonutstudio.com';
            }
            $user = User::create(
                [
                    'name'              => $u['name'],
                    'email'             => $email,
                    'email_hash'        => md5($email),
                    'password'          => bcrypt("123Qwe123"),
                    'role_id'           => $u['role'],
                    'active'            => 1,
                    'email_verified_at' => $now,
                    'created_at'        => $now,
                    'restaurant_id' => ($u['role'] === 3 || $u['role'] === 4)? 1 : null,
                ],
            );

            $user->encrypt_id = encrypt($user->id);
            $user->save();
        }
    }
}
