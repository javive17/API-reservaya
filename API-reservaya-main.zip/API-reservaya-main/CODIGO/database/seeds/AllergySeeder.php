<?php

use Illuminate\Database\Seeder;

class AllergySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = 'c_allergies';
        DB::table($table_name)->insert([
            ['name' => 'LECHE'],
            ['name' => 'MAIZ'],
            ['name' => 'TRIGO'],
            ['name' => 'HUEVOS'],
            ['name' => 'PESCADOS'],
            ['name' => 'MARISCOS'],
            ['name' => 'SOJA'],
            ['name' => 'FRUTOS SECOS'],
            ['name' => 'MELOCOTON'],
            ['name' => 'KIWI'],
            ['name' => 'OTROS'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
