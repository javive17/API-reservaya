<?php

use App\Models\Restaurant;
use Illuminate\Database\Seeder;

class RestaurantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $faker = \Faker\Factory::create();

        $restaurant = Restaurant::create(
            [
                'name'          => 'kokonutRestaurant Test',
                'owner_name'    => $faker->name(),
                'cheff_name'    => $faker->name(),
                'email'         => 'kokonut@kokonutstudio.com',
                'phone'         => $faker->phoneNumber,
                'description'   => $faker->text,
                'menu_url'      => $faker->url,
                'status'        => true,
                'cost_id'       => 1,
                'address_id'    => 1,
                'country_id'    => 1,
                'zone_id'       => 1,
                'suburb_id'     => 1,
            ]
        );
        $restaurant->encrypt_id = encrypt($restaurant->id);
        $restaurant->save();

        /***** RESTAURANT KITCHENS *****/
        DB::table('t_restaurants_kitchens')->insert([
            ['restaurant_id' => $restaurant->id, 'kitchen_id' => 1]
        ]);
    }
}
