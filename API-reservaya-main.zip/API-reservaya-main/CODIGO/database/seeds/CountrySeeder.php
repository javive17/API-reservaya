<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $table_name = "c_countries";
        DB::table($table_name)->insert([
            ['name' => 'República Dominicana'],
        ]);

        $all = DB::table($table_name)->get();

        foreach ($all as $a) {
            $encrypt_id = encrypt($a->id);
            DB::table($table_name)->where("id", $a->id)->update(['encrypt_id' => $encrypt_id]);
        }
    }
}
