<?php

use Illuminate\Database\Seeder;
use App\Models\Client;

class ClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $now = \date('Y-m-d H:i:s');

        $faker = \Faker\Factory::create();

        $client = Client::create(
            [
                'first_name'        => 'Client Test',
                'middle_name'       => 'Test',
                'last_name'         => 'Test',
                'cell_phone'        => $faker->phoneNumber,
                'description'       => $faker->text,
                'gender_id'         => 2,
                'country_id'        => 1,
                'user_id'           => 4,
                'client_status_id'  => 1,
                'collaborator'   => null,
                'created_at'        => $now,
            ],
        );

        $client->encrypt_id = encrypt($client->id);
        $client->save();

        /***** CLIENT SURVEY *****/
        DB::table('t_client_professions')->insert([
            ['client_id' => $client->id, 'profession_id' => 1]
        ]);

        DB::table('t_client_foods')->insert([
            ['client_id' => $client->id, 'food_id' => 1]
        ]);

        DB::table('t_client_drinks')->insert([
            ['client_id' => $client->id, 'drink_id' => 1]
        ]);

        DB::table('t_client_tables')->insert([
            ['client_id' => $client->id, 'table_id' => 1]
        ]);

        DB::table('t_client_allergies')->insert([
            ['client_id' => $client->id, 'allergy_id' => 1]
        ]);

        DB::table('t_client_nutritional_requirements')->insert([
            ['client_id' => $client->id, 'nutritional_requirement_id' => 1]
        ]);
    }
}
