<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->text('photo')->nullable();
            $table->string('name')->nullable();
            $table->string('email')->unique();
            $table->text('email_hash');
            $table->timestamp('email_verified_at')->nullable();
            $table->timestamp('last_login')->nullable();
            $table->string('password')->nullable();
            $table->boolean('chief_manager')->default(false);
            $table->boolean('active')->default(false);
            $table->unsignedBigInteger('role_id')->nullable();
            $table->unsignedBigInteger('restaurant_id')->nullable();
            $table->text('firebase_token')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('role_id')
                ->references('id')
                ->on('c_roles')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

            $table->foreign('restaurant_id')
                ->references('id')
                ->on('t_restaurants')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
