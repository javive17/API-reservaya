<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTRestaurantsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('t_restaurants', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->string('name')->nullable();
            $table->string('owner_name')->nullable();
            $table->string('cheff_name')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('description')->nullable();
            $table->string('menu_url')->nullable();
            $table->boolean('status');
            $table->boolean('active')->default(1);
            $table->boolean('notification')->default(0);
            $table->unsignedBigInteger('cost_id');
            $table->unsignedBigInteger('country_id');
            $table->unsignedBigInteger('zone_id')->nullable();
            $table->unsignedBigInteger('suburb_id')->nullable();
            $table->unsignedBigInteger('address_id');

            $table->foreign('cost_id')
                ->references('id')
                ->on('c_costs')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('country_id')
                ->references('id')
                ->on('c_countries')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('zone_id')
                ->references('id')
                ->on('c_zones')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('suburb_id')
                ->references('id')
                ->on('c_suburbs')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('address_id')
                ->references('id')
                ->on('t_addresses')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('t_restaurants');
    }
}
