<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTPaymentsRestaurantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_payments_restaurants', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->dateTime('payment_date');
            $table->double('amount');
            $table->unsignedBigInteger('restaurant_id')->nullable();
            $table->unsignedBigInteger('payment_status_id')->nullable();
            $table->timestamps();
            $table->softDeletes();


            $table->foreign('restaurant_id')
            ->references('id')
            ->on('t_restaurants')
            ->onDelete('NO ACTION')
            ->onUpdate('NO ACTION');

            $table->foreign('payment_status_id')
                ->references('id')
                ->on('c_payments_status')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_payments_restaurants');
    }
}
