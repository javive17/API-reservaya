<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class TWholedayReservations extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_wholeday_reservations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->text('reason')->nullable();
            $table->integer('people');
            $table->dateTime('reservation_date');
            $table->dateTime('check_in')->nullable();
            $table->dateTime('check_out')->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->string('status',32);
            $table->foreign('client_id')
            ->references('id')
            ->on('t_clients')
            ->onDelete('NO ACTION')
            ->onUpdate('NO ACTION')
        ;
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_wholeday_reservations');
    }
}
