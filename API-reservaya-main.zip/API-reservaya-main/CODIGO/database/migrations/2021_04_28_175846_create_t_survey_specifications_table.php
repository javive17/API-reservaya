<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTSurveySpecificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_survey_specifications', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('profession')->nullable();
            $table->string('industry')->nullable();
            $table->string('nutritional_requirement')->nullable();
            $table->string('allergy')->nullable();
            $table->string('table')->nullable();
            $table->string('drink')->nullable();
            $table->string('food')->nullable();
            $table->string('trademark')->nullable();
            $table->string('favorite_drink')->nullable();
            $table->text('additional')->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_survey_specifications');
    }
}
