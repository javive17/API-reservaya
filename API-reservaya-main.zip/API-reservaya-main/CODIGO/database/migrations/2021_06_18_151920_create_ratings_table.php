<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRatingsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('t_ratings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->integer('food')->default(5);
            $table->integer('service')->default(5);
            $table->integer('atmosphere')->default(5);
            $table->double('global')->default(5);
            $table->string('comment', 250)->nullable();
            $table->string('reply', 250)->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('reservation_id')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('reservation_id')
                ->references('id')
                ->on('t_reservations')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('t_ratings');
    }
}
