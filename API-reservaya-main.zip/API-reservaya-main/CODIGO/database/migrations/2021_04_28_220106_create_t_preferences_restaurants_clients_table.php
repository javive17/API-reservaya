<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTPreferencesRestaurantsClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_preferences_restaurants_clients', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->double('rating')->default(5);
            $table->string('friend',250)->nullable();
            $table->string('drink',250)->nullable();
            $table->string('food',250)->nullable();
            $table->string('table',250)->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('restaurant_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

            $table->foreign('restaurant_id')
                ->references('id')
                ->on('t_restaurants')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_preferences_restaurants_clients');
    }
}
