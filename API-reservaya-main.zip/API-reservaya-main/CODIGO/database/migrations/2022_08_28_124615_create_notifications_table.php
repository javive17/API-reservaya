<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('restaurant_id')->nullable();
            $table->unsignedBigInteger('reservation_id')->nullable();
            $table->string('title');
            $table->longText('body')->nullable();
            $table->date('date');
            $table->enum('status', ['read', 'unread'])->default('unread')->comment('read : Leida | unread : Pendiente');
            $table->timestamp('read_at')->nullable();
            $table->timestamps();

            $table->foreign('reservation_id')
                ->references('id')
                ->on('t_reservations')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('restaurant_id')
                ->references('id')
                ->on('t_restaurants')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications');
    }
}
