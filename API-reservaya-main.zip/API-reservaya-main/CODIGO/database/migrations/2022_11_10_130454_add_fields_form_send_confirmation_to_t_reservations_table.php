<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsFormSendConfirmationToTReservationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('t_reservations', function (Blueprint $table) {
            #fields type boolean
            $table->boolean('form_send')->default(0)->after('notification')->nullable();
            $table->boolean('form_confirmation')->default(0)->after('form_send')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('t_reservations', function (Blueprint $table) {
            $table->dropColumn('form_send');
            $table->dropColumn('form_confirmation');
        });
    }
}
