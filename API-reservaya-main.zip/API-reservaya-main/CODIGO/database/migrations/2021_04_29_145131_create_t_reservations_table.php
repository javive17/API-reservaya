<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTReservationsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('t_reservations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->integer('people');
            $table->dateTime('reservation_date');
            $table->dateTime('check_in')->nullable();
            $table->dateTime('check_out')->nullable();
            $table->double('bill')->nullable()->default(0.0);
            $table->string('comments')->default('No comments');
            $table->string('table_number')->nullable();
            $table->string('ticket_photo')->nullable();
            $table->unsignedBigInteger('reservations_status_id')->nullable()->default(1);
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('table_id')->nullable();
            $table->boolean('notification')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('reservations_status_id')
                ->references('id')
                ->on('c_reservations_status')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;

            $table->foreign('table_id')
                ->references('id')
                ->on('t_tables')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION')
            ;
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('t_reservations');
    }
}
