<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTFavoriteRestaurantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_favorite_restaurants', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('encrypt_id')->nullable();
            $table->boolean('status');
            $table->unsignedBigInteger('restaurant_id')->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

            $table->foreign('restaurant_id')
                ->references('id')
                ->on('t_restaurants')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_favorite_restaurants');
    }
}
