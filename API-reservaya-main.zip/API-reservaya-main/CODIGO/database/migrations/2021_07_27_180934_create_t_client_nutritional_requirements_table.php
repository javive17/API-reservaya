<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTClientNutritionalRequirementsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_client_nutritional_requirements', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('nutritional_requirement_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id', 't_cnr_client_id_foreign')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

            $table->foreign('nutritional_requirement_id', 't_cnr_nutritional_requirement_id_foreign')
                ->references('id')
                ->on('c_nutritional_requirements')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_client_nutritional_requirements');
    }
}
