<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTSocialMediasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_social_medias', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('url');
            $table->string('nickname')->nullable();
            $table->unsignedBigInteger('client_id')->nullable();
            $table->unsignedBigInteger('social_media_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('client_id')
                ->references('id')
                ->on('t_clients')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

            $table->foreign('social_media_id')
                ->references('id')
                ->on('c_social_medias')
                ->onDelete('NO ACTION')
                ->onUpdate('NO ACTION');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_social_medias');
    }
}
