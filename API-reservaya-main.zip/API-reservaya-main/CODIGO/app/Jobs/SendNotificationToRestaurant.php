<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Reservation;
use App\Models\Table;
use App\Models\Restaurant;
use App\Models\Device;

class SendNotificationToRestaurant implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $reservationId;

    public function __construct(int $reservationId)
    {
        $this->reservationId = $reservationId;
    }

    public function handle()
    {
        $reservation = Reservation::find($this->reservationId);
        $table_id = $reservation->table_id;
        $table = Table::find($table_id);

        $restaurant_id = $table->restaurant_id;
        $restaurant = Restaurant::find($restaurant_id);
        $devices = Device::where('restaurant_id', $restaurant_id)->orderBy('id', 'desc')->take(5)->get();
/*
             	'title' => '¡Reserva confirmada!',
                    	'body' => '¡BUENAS NOTICIAS! Su reserva ha sido confirmada exitosamente!',

*/
        foreach ($devices as $device) {
            $data = (object) [
                'notification_id' => $device->id, // Assuming device ID is used as notification ID
                "token"           => $device->token,
                "platform"        => $device->platform,
                'title'           => 'Nueva Reserva', // Customize your title
                'body'            => '¡BUENAS NOTICIAS! Ha recibido una nueva reserva!', // Customize your body
                'date'            => date('Y-m-d'),
            ];

            $this->sendGCM($data);
        }
    }

    //Send notification diveces
    function sendGCM($datos)
    {

        $notification = array(
            'title' => $datos->title,
            'body'  => $datos->body,
            'data'  => $datos,
            'sound' => 'default',
            'badge' => '1',
            'style' => 'inbox'
        );
        $arrayToSend = array(
            'to' => $datos->token,
            'notification' => $notification,
            'priority' => 'high'
        );

        $json = json_encode($arrayToSend);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: key=' . env("FIREBASE_API_ACCESS_KEY");
        $ch = curl_init();
        if (env("APP_ENV") == 'local') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        curl_setopt($ch, CURLOPT_URL, env("FIREBASE_API_URL"));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //Send the request
        curl_exec($ch);
        //Close request

        curl_close($ch);
    }
}