<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\{Device, Notification};

class SendNotifications implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    //Variable
    protected $obj;
    protected $type;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($obj, $type = 'user')
    {
        $this->obj = $obj;
        $this->type = $type;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $obj = $this->obj;
        $dispositivos = [];

        if($this->type == 'user'){
            $dispositivos = Device::where('client_id', $obj->to)->get();

            //Crear notificacion
            $notification_data =  [
                'user_id'           => $obj->to,
                'reservation_id'    => $obj->reservation_id,
                'title'             => $obj->title,
                'body'              => $obj->body,
                'date'              => date('Y-m-d'),
            ];
        } else {
            //$dispositivos = Device::where('restaurant_id', $obj->to)->get();
            //get the last 10 devices, with the most recent id
            $dispositivos = Device::where('restaurant_id', $obj->to)->orderBy('id', 'desc')->take(10)->get();
            //debug to specific file, device_test.txt
            file_put_contents('device_test.txt', print_r($dispositivos, true));



            //Crear notificacion
            $notification_data =  [
                'restaurante_id'    => $obj->to,
                'reservation_id'    => $obj->reservation_id,
                'title'             => $obj->title,
                'body'              => $obj->body,
                'date'              => date('Y-m-d'),
            ];
        }


        $notification = Notification::create(
            $notification_data
        );

        if (count($dispositivos) > 0) {
            /**
             * envio de notificacion por dispositivo
             */
            foreach ($dispositivos as $key) {

                $data = (object) [
                    'notification_id' => $notification->id,
                    "token"           => $key->token,
                    "platform"        => $key->platform,
                    'title'           => $obj->title,
                    'body'            => $obj->body,
                    'date'            => date('Y-m-d'),
                ];
                
               $this->sendGCM($data);
            }
        }
    }

    //Send notification diveces
    function sendGCM($datos)
    {

        $notification = array(
            'title' => $datos->title,
            'body'  => $datos->body,
            'data'  => $datos,
            'sound' => 'default',
            'badge' => '1',
            'style' => 'inbox'
        );
        $arrayToSend = array(
            'to' => $datos->token,
            'notification' => $notification,
            'priority' => 'high'
        );

        $json = json_encode($arrayToSend);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: key=' . env("FIREBASE_API_ACCESS_KEY");
        $ch = curl_init();
        if (env("APP_ENV") == 'local') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        curl_setopt($ch, CURLOPT_URL, env("FIREBASE_API_URL"));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //Send the request
        curl_exec($ch);
        //Close request

        curl_close($ch);
    }
}
