<?php
namespace App\Services;
interface CommissionServiceInterface
{
    /**
     * Funcion que calcula la comision que se le debe pagar segun
     * el numero de personas que reservaron en el restaurante
     *
     * @param mixed $comision La comision que cobra el restaurante
     * @param int $numberPeople
     *
     * @return mixed $commissionToPay La comision a pagar por parte del restaurante
     */
    public function getCommissionToPay($comision,int $numberPeople);

    /**
     * Funcion que calcula la comision que se le debe pagar segun
     * el numero de personas y la cuenta de la reservacion en el restaurante
     *
     * Esta funcion solo es complementaria
     *
     * @param mixed $comision La comision que cobra el restaurante
     * @param int $numberPeople
     * @throws NotImplementedException
     * @return mixed $commissionToPay La comision a pagar por parte del restaurante
     */
    public function getCommissionToPayFromBill($comision,int $numberPeople,$bill);


}
