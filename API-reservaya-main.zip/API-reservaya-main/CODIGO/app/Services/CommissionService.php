<?php
namespace App\Services;

use App\Exceptions\NotImplementedException;

class CommissionService implements CommissionServiceInterface
{

    public function getCommissionToPay($commission,int $numberPeople)
    {
        return $commission * $numberPeople;
    }

    public function getCommissionToPayFromBill($comision,int $numberPeople,$bill)
    {
        throw new NotImplementedException();
    }


}
