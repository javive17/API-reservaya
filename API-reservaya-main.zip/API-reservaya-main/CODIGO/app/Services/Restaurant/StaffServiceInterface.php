<?php
namespace App\Services\Restaurant;

interface StaffServiceInterface{


    public function getByRestaurantId($restaurantId);

    public function getByRestaurantIdPaginated($restaurantId,$pageSize,$search);

    public function delete($managerId,$id);

    public function update($managerId,$id,$data);

    public function store($restaurantId,$roleId,$email,$password=null);

    public function show($id);

    public function updatePassword($data);
}
