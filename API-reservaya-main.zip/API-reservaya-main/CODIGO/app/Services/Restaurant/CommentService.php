<?php

namespace App\Services\Restaurant;

use App\Models\Rating;
use App\Traits\GeneralResponse;
use App\Traits\AuxiliarFunctions;
use App\Repositories\ClientRepositoryInterface;
use App\Repositories\RatingRepositoryInterface;

class CommentService implements CommentServiceInterface
{
    use AuxiliarFunctions;
    use GeneralResponse;

    /** @var RatingRepositoryInterface */
    private $ratingRepository;

    /** @var ClientRepositoryInterface */
    private $clientRepository;

    public function __construct(RatingRepositoryInterface $ratingRepository, ClientRepositoryInterface $clientRepository)
    {
        $this->ratingRepository = $ratingRepository;
        $this->clientRepository = $clientRepository;
    }

    public function getByRestaurantId($restaurantId)
    {
        $ratings = $this->ratingRepository->getByRestaurantId($restaurantId);

        // $salida = [];
        return $ratings;
    }

    public function getByRestaurantIdPaginatedOrderedBy($restaurantId, $pageSize, $orderBy)
    {
        $ratings = $this->ratingRepository
            ->getByRestaurantIdPaginatedOrderedBy($restaurantId, $pageSize, [])
            ->appends(['pagesize' => $pageSize])
            ->toArray();

        $data = $ratings['data'];

        $ratings['data'] = $this->fillCommentInfo($data);

        return $ratings;
    }

    public function replyClientComments($Id, $replay)
    {
        $rating = $this->ratingRepository->findByencryptId($Id);
        if(!$rating){
            return $this->genResponse(0,404);
        }
        if($rating->reply && !empty($rating->reply) ){
            return $this->genResponse(0,400,['error'=>'solo se puede responder una vez']);
        }

        $ok = $this->ratingRepository->update(['reply'=>$replay],$rating->id);
        //Send notification push?

        return $this->genResponse($ok, 200);
    }

    private function fillCommentInfo($data)
    {
        $comments = [];
        foreach ($data as $value) {

            $client = $this->clientRepository->findByIdWithUser($value['client_id']);

            $comments[] = [
                'id' => $value['encrypt_id'],
                'comment' => $value['comment'],
                'reply' => $value['reply'],
                'reservation_date' => $value['reservation_date'],
                'number_people' => $value['people'],
                'client' => [
                    'id' => $client->encrypt_id,
                    "first_name" => $client->first_name,
                    "middle_name" => $client->middle_name,
                    "last_name" => $client->last_name,
                    "photo" => $this->getImage($client->user->photo),
                    "email" => $client->user->email,
                ]

            ];
        }
        return $comments;
    }

    public function deleteComments($id)
    {
        $rating = $this->ratingRepository->findByencryptId($id);
        if(!$rating){
            return $this->genResponse(0,404);
        }

        $ok = $this->ratingRepository->delete($rating->id);

        return $this->genResponse($ok, 200);
    }

    public function storeComments($data, $user)
    {
        if (!$reservation_id = $this->getDecrypted($data['reservation_eid'])) {
            return $this->genResponse(0, 400, null, 'reservation_eid incorrecto');
        }

        if(Rating::where('reservation_id', $reservation_id)->first()) {
            return $this->genResponse(0, 400, null, "La reservación ya fue calificada");
        }
        
        $rating = Rating::create([
            "client_id"         => $user->client->id,
            "reservation_id"    => $reservation_id,
            "food"              => $data['food'],
            "service"           => $data['service'],
            "atmosphere"        => $data['atmosphere'],
            "global"            => $data['global'],
            "comment"           => isset($data['comment']) ? $data['comment'] : null,
        ]);
        $rating->encrypt_id = encrypt($rating->id);
        $rating->save();

        return $this->genResponse(1, 200, null, "Comentarios guardados");
    }
}
