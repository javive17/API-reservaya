<?php

namespace App\Services\Restaurant;

interface CommentServiceInterface
{
    public function getByRestaurantId($restaurantId);
    public function getByRestaurantIdPaginatedOrderedBy($restaurantId,$pageSize,$orderBy);

    public function replyClientComments($reservationId,$reply);
    public function deleteComments($id);
    public function storeComments($data, $user);
}
