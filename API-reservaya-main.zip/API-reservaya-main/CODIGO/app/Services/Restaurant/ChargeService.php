<?php
namespace App\Services\Restaurant;
use App\Repositories\ReservationRepositoryInterface;
use App\Services\CommissionServiceInterface;
use App\Traits\GeneralResponse;
use Illuminate\Support\Facades\Log;

class ChargeService implements ChargeServiceInterface
{

    use GeneralResponse;


    /** @var ReservationRepositoryInterface */
    private $reservationRepository;

    /** @var CommissionServiceInterface */
    private $commissionService;

    public function __construct(ReservationRepositoryInterface $reservationRepository,CommissionServiceInterface $commissionService )
    {
        $this->reservationRepository =$reservationRepository;
        $this->commissionService =$commissionService;
    }

    public function getRestaurantChargePerMonthPaginated($restaurantId,$date,$pageSize)
    {

        $arrayDate = explode('-',$date);

        $reservations = $this->reservationRepository
            ->findByRestaurantIdWithClientByMonthOrderedPaginated($restaurantId,$arrayDate[0],$arrayDate[1],$pageSize,[])
            ->appends(['pagesize' => $pageSize])
            ->toArray();


        $commission = $this->getConfigCommission();

        $total = $this->reservationRepository->getIncomeByMonthWithTotal($restaurantId,$arrayDate[0],$arrayDate[1]);
        $total['month_commission'] = $this->commissionService->getCommissionToPay($commission,$total['total_people_month']);
        $total['total_commission'] = $this->commissionService->getCommissionToPay($commission,$total['total_people']);

        Log::debug("Total ".json_encode($total));

        $total['month_commission']  = number_format($total['month_commission'], 2, '.', ',');
        $total['total_commission']  = number_format($total['month_commission'], 2, '.', ',');
        $reservations['data']       = $this->fillChargeData($reservations['data'],$commission);
        $reservations['income']     = $total;

        return $this->genResponse(1,200,$reservations);
    }

    public function getRestaurantChargePerMonth($restaurantId,$date){

        $arrayDate = explode('-',$date);

        $commission = $this->getConfigCommission();

        $reservations = $this->reservationRepository
            ->findByRestaurantIdWithClientByMonth($restaurantId,$arrayDate[0],$arrayDate[1])
            ->toArray();

        return $this->fillChargeData($reservations,$commission);
    }


    private function fillChargeData($data,$commission){
        $out = [];

        foreach ($data as $value) {
            $out[] = (object)[
                'id'                => $value['encrypt_id'],
                'people'            => $value['people'],
                'reservation_date'  => $value['reservation_date'],
                'check_in'          => $value['check_in'],
                'check_out'         => $value['check_out'],
                'table_name'        => $value['table_name'],
                'status'            => $value['status'],
                'client_name'       => $value['first_name'].' '.$value['middle_name'].' '.$value['last_name'],
                'bill'              => number_format($value['bill'], 2, '.', ','),
                'commission_to_pay' => number_format($this->commissionService->getCommissionToPay($commission,$value['people']), 2, '.', ','),

            ];
        }

        return $out;
    }

    /**
     * Se debe obtener la comicion que se le cobra al restaurante
     * por el momento se regrasara 2
     */
    protected function getConfigCommission(){
        return 2; // TODO
    }
}
