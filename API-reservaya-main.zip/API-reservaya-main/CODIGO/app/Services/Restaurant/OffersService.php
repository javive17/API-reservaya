<?php

namespace App\Services\Restaurant;

use App\Traits\GeneralResponse;
use Illuminate\Support\Facades\Log;
use Auth;
use Illuminate\Support\Facades\Hash;
use App\Repositories\UserRepositoryInterface;

class OffersService implements OffersServiceInterface
{


    use GeneralResponse;


    /** @var UserRepositoryInterface */
    private $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function getByRestaurantId($restaurantId)
    {
        return $this->genResponse();
    }

    public function show($id){
        $user = $this->userRepository->findByencryptId($id);

        if (!$user) {
            return $this->genResponse(0, 400, "No se encontro a ningun usuario con ese id");
        }

        $salida = (object)[
            'id' => $user['encrypt_id'],
            'email' => $user['email'],
            'role' => $user['role']['name'],
            'created_at' => $user['created_at'],
            'active' => $user['active'],
            'last_login' => $user['last_login'],
        ];

        return $this->genResponse(1,200,$salida);

    }

    public function getByRestaurantIdPaginated($restaurantId, $pageSize, $search)
    {
        $staff = $this->userRepository
            ->allRestaurantOffersFilterByEmailOrderByPaginated($restaurantId, $search, [], $pageSize)
            ->appends(['pagesize' => $pageSize])
            ->toArray();

        $salida = [];
        foreach ($staff['data'] as $employe) {
            $salida[] = [
                'id' => $employe['encrypt_id'],
                'email' => $employe['email'],
                'role' => $employe['role']['name'],
                'created_at' => $employe['created_at'],
                'active' => $employe['active'],
                'last_login' => $employe['last_login'],
            ];
        }
        $staff['data'] = $salida;

        return $this->genResponse(1, 200, $staff);
    }


    public function store($restaurantId, $roleId, $email, $password = null)
    {

        $pass = $this->password($password);

        $user = $this->userRepository->createRestaurantOffers($email, $pass, $roleId, $restaurantId);
        // /* TODO send mail info*/

        return $this->genResponse(1, 201, $user);
    }

    public function delete($managerId, $id)
    {
        $user = $this->userRepository->findByencryptId($id);

        if (!$user) {
            return $this->genResponse(0, 400, "No se encontro a ningun usuario con ese id");
        }

        if ($managerId === $user->id) {
            return $this->genResponse(0, 400, "No te puedes eliminar a ti mismo");
        }
        if($user->chief_manager) {
            return $this->genResponse(0, 400, "No puedes eliminar al usuario principal");
        }
        $user->forceDelete();
        // $isDeleted = $this->userRepository->delete($user->id);

        return $this->genResponse(1, 200, null, "Usuario eliminado correctamente");
    }

    public function update($managerId, $id, $data)
    {

        if (empty($data)) {
            return $this->genResponse(1, 200, "Nada que actualizar");
        }


        $user = $this->userRepository->findByencryptId($id);

        if (!$user) {
            return $this->genResponse(0, 400, "No se encontro a ningun usuario con ese id");
        }

        if(isset($data['email'])){

            $existEmail = $this->userRepository->existUserWithEmail($user->id, $data['email']);
            Log::debug("user " . json_encode($existEmail));
            if ($existEmail) {
                return $this->genResponse(0, 400, "Ya existe un usuario con ese correo");
            }
            $data['email_hash'] = md5(strtolower($data['email']));
            $data['email']      = strtolower($data['email']);

            if($user->chief_manager) {
                $restaurant = $user->restaurant;
                $restaurant->email = $data['email'];
                $restaurant->save();
            }
        }


        if(isset($data['role_eid'])){
            $data['role_id'] = $data['role_eid'];
            unset($data['role_eid']);
        }

        if(isset($data['password'])){
            $data['password'] = bcrypt($data['password']);
        }

        $updated = $this->userRepository->update($data,$user->id);

        return $this->genResponse($updated);
    }

    private function password($password)
    {
        if (isset($password) && !empty($password)) {
            return $password;
        }

        return 'randompassword';
    }

    public function updatePassword($data)
    {
        $user = Auth::user();

        if(!Hash::check($data['password'], $user->password)) {
            return $this->genResponse(0, 400, null, "La contraseña actual es incorrecta" );
        }
        if($data['new_password'] != $data['new_password_confirmation']) {
            return $this->genResponse(0, 400, null, "Las contraseñas no coinciden" );
        }

        $user->password = bcrypt($data['new_password']);
        $user->save();

        return $this->genResponse(1, 200, null, "Actualización correcta");
    }
}
