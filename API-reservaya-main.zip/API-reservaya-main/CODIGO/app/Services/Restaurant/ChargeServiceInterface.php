<?php
namespace App\Services\Restaurant;

interface ChargeServiceInterface
{
    public function getRestaurantChargePerMonthPaginated($restaurantId,$date,$pageSize);
    public function getRestaurantChargePerMonth($restaurantId,$date);
}
