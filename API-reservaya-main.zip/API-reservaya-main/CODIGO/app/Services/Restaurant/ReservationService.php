<?php



namespace App\Services\Restaurant;



use App\Repositories\CatalogRepositoryInterface;

use App\Repositories\ClientRepositoryInterface;

use App\Repositories\ReservationRepositoryInterface;

use App\Repositories\RestaurantRepositoryInterface;

use App\Traits\{AuxiliarFunctions, Notification};

use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

use App\Models\PaymentRestaurant;
use App\Models\Reservation;
use App\Models\User;
use App\Models\PardepanBlocked;


use Illuminate\Support\Facades\DB;


class ReservationService implements ReservationServiceInterface

{

    use AuxiliarFunctions, Notification;



    /** @var ReservationRepositoryInterface */

    private $reservationRepository;



    /** @var RestaurantRepositoryInterface */

    private $restaurantRepository;



    /** @var ClientRepositoryInterface */

    private $clientRepository;



    /** @var CatalogRepositoryInterface */

    private $catalogRepository;



    public function __construct(

        ReservationRepositoryInterface $reservationRespository,

        RestaurantRepositoryInterface $restaurantRepository,

        ClientRepositoryInterface $clientRepository,

        CatalogRepositoryInterface $catalogRepository

    ) {

        $this->reservationRepository = $reservationRespository;

        $this->restaurantRepository = $restaurantRepository;

        $this->clientRepository = $clientRepository;

        $this->catalogRepository = $catalogRepository;
    }



    public function create($restaurantId, $clientId, $tableId, $people, $reservationDate, $comments, $tableNumber, $type = '', $startDate = null, $endDate = null, $userId = null)

    {

        $table = $this->restaurantRepository->capacity($restaurantId)->where('table_type_id', $tableId)->first();



        if (!$table) {

            return ['status' => 404, 'message' => 'No existe la mesa con ese id', 'data' => null];
        }

        // Log::info('Table' . json_encode($table));



        if (!$table->capacity) {

            return ['status' => 400, 'message' => "La zona de mesa que seleccionó no esta habilitada en este restaurante", 'data' => null];
        }

        $check_hour = $this->checkOperatingHours($restaurantId, $reservationDate);

        if (!$check_hour->status) {

            return ['status' => 400, 'message' => $check_hour->message, 'data' => null];
        }



        if (!$this->hasRestaurantAvalability($restaurantId, $reservationDate, $table->id, $people, $table->capacity, null)) {

            return ['status' => 412, 'message' => 'No hay cupo en el horario que seleccionó', 'data' => null];
        }



        $reservation = $this->reservationRepository->store($clientId, $table->id, $comments, $people, $reservationDate, $tableNumber, $type, $startDate, $endDate, $userId);

        if (!$reservation) {

            return ['status' => 500, 'message' => 'Error a la hora de crear la reservacion', 'data' => null];
        }

        $this->paymentRestaurant($restaurantId, $people, $reservationDate);



        return ['status' => 201, 'message' => 'ok', 'data' => $reservation];
    }



    public function update($restaurantId, $reservationId, $clientId, $tableId, $people, $reservationDate, $comments, $tableNumber)

    {

        $table = $this->restaurantRepository->capacity($restaurantId)->where('table_type_id', $tableId)->first();

        if (!$table) {

            return ['status' => 404, 'message' => 'No existe la mesa con ese id', 'data' => null];
        }

        // Log::info('Table' . json_encode($table));



        if (!$table->capacity) {

            return ['status' => 400, 'message' => "La zona de mesa que seleccionó no esta habilitada en este restaurante", 'data' => null];
        }



        $check_hour = $this->checkOperatingHours($restaurantId, $reservationDate);

        if (!$check_hour->status) {

            return ['status' => 400, 'message' => $check_hour->message, 'data' => null];
        }



        if (!$this->hasRestaurantAvalability($restaurantId, $reservationDate, $table->id, $people, $table->capacity, $reservationId)) {

            return ['status' => 412, 'message' => 'No hay cupo en el horario que seleccionó', 'data' => null];
        }



        $this->paymentRestaurant($restaurantId, $people, $reservationDate, $reservationId);

        $reservation = $this->reservationRepository->updateReservation($reservationId, $clientId, $table->id, $comments, $people, $reservationDate, $tableNumber);

        if (!$reservation) {

            return ['status' => 500, 'message' => 'Error a la hora de crear la reservacion', 'data' => null];
        }



        return ['status' => 200, 'message' => 'ok', 'data' => $reservation];
    }



    public function restauranCapacityBySchedule($restaurantId, $date, $hour, $people)

    {

        //TODO Check O(n)

        $normaliceHour = $this->normaliceHour($hour);

        //TODO Check O(n)
        $schedule = $this->getSchedulefromHour($date, $normaliceHour, $restaurantId);
        //TODO Check O(n) //update check if can also return the special area 
        $tables = $this->restaurantRepository->capacity($restaurantId);

        // Log::info($schedule);
        $salida = [];
        //por cada mesa en el restaurante chequea todos los horarios
        $targetDate= date('Y-m-d', strtotime($date));
        
        //create startdate and enddate at 00:00:00 and 23:59:59
        $startDate = $targetDate.' 00:00:00';
        $endDate = $targetDate.' 23:59:59';
 
        foreach ($tables as $table) {
            
            //gets all the events for the table, that day
            $eventReservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
            ->join('c_tables_type', 't_tables.table_type_id', '=', 'c_tables_type.id')
            ->select('t_reservations.*')
            ->where(['t_tables.restaurant_id' => $restaurantId])
            ->where('t_tables.id', $table->id)
            ->where('t_reservations.start_date', '<=', $endDate)
            ->where('t_reservations.end_date', '>=', $startDate)
            //where status is not "eliminado"
            ->where('t_reservations.reservations_status_id', '!=', 10)
            ->where(['t_reservations.type' => 'event'])->get();
            $salida[] = [

                'table' => $table->type->name,

                'table_type_id' => $table->type->encrypt_id,

                'total_capacity' => $table->capacity,
                //CHECK O(n)
                'schedule' => $this->capacityPerSchedule($schedule, $table->capacity, $people, $restaurantId, $table->id, $table->type->exclusive,$eventReservations),
                'exclusive' => $table->type->exclusive,
                'targetdate' => $targetDate,
                'events' => $eventReservations,
                'targetdatecarbon' => $startDate,
                'targetdatecarbonend' => $endDate,
            ];
        }

        return $salida;
    }



    private function normaliceHour($hour)

    {

        // Log::info('Hora ' . $hour);



        $arrayhour = explode(':', $hour);



        if (strtotime($hour) == strtotime($arrayhour[0] . ":00")) {

            return $hour;
        }



        $salida = (strtotime($hour) <= strtotime($arrayhour[0] . ":30"))

            ? $arrayhour[0] . ":30"

            : date('H:i', strtotime($arrayhour[0] . ":00" . '+1 hour'));



        // Log::info('Hora normalizada ' . $salida);



        return $salida;
    }



    public function getReservationsByRestaurantId($restaurantId, $zone, $date, $hour, $pageSize, $orderBy, $search)

    {


        $hour = $this->normaliceHour($hour); //00:00

        $data = [];

        $columns = ['nombre', 'asistentes', 'estatus', 'fecha'];

        $order = $this->parseOrderByQuery($orderBy, $columns);

        // return $order;

        // Log::debug("order" . json_encode($order));

        // $reservations = $this->reservationRepository->findByRestaurantIdWithClientAndStatusAndTable($restaurantId)->toArray();

        //$reservations = $this->reservationRepository->findByRestaurantIdAndDateIdWithClientAndStatusAndTable($restaurantId, $date)->toArray();

        $reservations = $this->reservationRepository

            ->findByRestaurantIdAndDateIdWithClientAndStatusAndTableFilterByTableTypes(

                $restaurantId,

                $date,

                $this->getfilterTableReservations($zone),

                $pageSize,

                $order,

                $search

            )

            ->appends(['pagesize' => $pageSize, 'orderBy' => $orderBy])

            ->toArray();
        foreach ($reservations['data'] as $reservation) {
            $decrypted = $this->getDecrypted($reservation['encrypt_id']);
        //if the reservation seen is 0 
        if($reservation['seen'] == 0){
            //update the reservation seen to 1
            //$this->reservationRepository->update(['seen' => 1], $reservation['id']);
            $this->reservationRepository->update(['seen' => 1], $decrypted);
       

        }
          $visits = $this->reservationRepository->getVisitsByReservationClientId($reservation['client_id'], $restaurantId);
            $data[] = [

                'id' => $reservation['encrypt_id'],
                'table' => $reservation['table_name'],
                'categories' => $this->clientRepository->getCategoryNameByIdAndRestaurantId($reservation['client_id'], $restaurantId),
                'name' => strtolower($reservation['first_name'] . " " . $reservation['middle_name'] . " " . $reservation['last_name']),
                'client_status' => $reservation['client_status'],
                'reservation_date' => $reservation['reservation_date'],
                'people' => $reservation['people'],
                'status' => $reservation['status'],
                'status_id' => $reservation['status_id'],
                'comments' => $reservation['comments'],
                'table_number' => $reservation['table_number'],
                'client_id' => $reservation['client_id'],
                'email' => $reservation['email'],
                'phone' => $reservation['cell_phone'],
                'linkid' => $reservation['linkid'],
                'tablename' => $reservation['table_name'],
                'type' => $reservation['type'],
                'birthdate' => $reservation['birthday_date'],
                'start_date' => $reservation['start_date'],
                'end_date' => $reservation['end_date'],
                'photo' => ($reservation['photo']) ? 'https://api.puerta21.club/storage/app/prod/users/' . '/' . $reservation['photo'] : null,
                'created_by' => $reservation['created_by'],
                'modified_by' => $reservation['modified_by'],
                'status_modified_by' => $reservation['status_modified_by'],
                'deleted_by' => $reservation['deleted_by'],
                'visits' => $visits,
                'test' => $decrypted,
                'commentSeen' => $reservation['commentSeen'],

            ];
        }

        $reservations['data'] = $data;

        $reservations['hour'] = $hour;

        $reservations['capacity'] = $this->getCountReservationByRestaurantIdAndDateGroupedByZones($restaurantId, $date, $hour);



        return $reservations;
    }



    public function updateReservationStatus($reservationId, $status, $userId)

    {

        $reservation = $this->reservationRepository->find($reservationId);
        
        if (!$reservation) {

            return ['status' => 404, 'message' => 'No existe la reservación con ese id'];
        }
        //TODO esto se debe mejorar luego
        //update who edited the reservation status
        $reservation->status_modified_by = $userId;
        //if the reservation gets deleted 
        if($status == 10){
            $reservation->deleted_by = $userId;
        }
        $reservation->save();


        $canChanceStatus = $this->reservationCanChangeStatus($status, $reservation->reservations_status_id);

        /* if (!$canChanceStatus) {

            return ['status' => 400, 'message' => 'No se puede cambiar el estatus de la reservación por el estatus enviado'];

        }*/





        $toUpdate = [

            'reservations_status_id' => $status,

            'check_in' => ($status === 2) ? \date('Y-m-d H:i:s') : $reservation->check_in,

            'check_out' => ($status === 3) ? \date('Y-m-d H:i:s') : $reservation->check_out,

        ];



        $user       = $reservation->client->user;

        $restaurant = $reservation->table->restaurant;

        if ($status === 2) {

            if ($user->firebase_token) {

                $title          = "¡Bienvenido!";

                $description    = "¡Bienvenido a " . $restaurant->name . "! Esperemos disfrute su experiencia.";

                $information    = ['restaurant_eid' => $restaurant->encrypt_id];

                $this->sendNotification($user->firebase_token, $title, $description, $information);
            }
        }

        if ($status === 3) {

            if ($user->firebase_token) {

                $title          = "¡Adios!";

                $description    = '¡Gracias por visitarnos! Por favor califique su experiencia en la sección "Mis reservas".';

                $information    = ['reservation_eid' => $reservation->encrypt_id];

                $this->sendNotification($user->firebase_token, $title, $description, $information);
            }
        }



        $this->reservationRepository->update($toUpdate, $reservationId, $userId);



        return ['status' => 200, 'message' => 'ok'];
    }



    private function reservationCanChangeStatus($status, $actual)

    {

        // Log::debug("status to change : " . $status);

        // Log::debug("actual status : " . $actual);

        $rules = [

            [2, 5],

            [2, 5],

        ];

        $rule = isset($rules[$actual - 1]) ? $rules[$actual - 1] : [];

        // Log::debug("rule : " . json_encode($rule));

        return in_array($status, $rule);
    }



    public function edit($reservationId, $data)

    {

        $reservation = $this->reservationRepository->find($reservationId);

        if (!$reservation) {

            return ['status' => 404, 'message' => 'No existe la reservacion con ese id '];
        }



        if ($reservation->reservations_status_id !== 1) {

            return ['status' => 400, 'message' => 'Solo se puede editar la reservacion con el status "en espera" '];
        }

        $toUpdate = [];



        if (isset($data['number_people'])) {

            $toUpdate['people'] = $data['number_people'];
        }



        if (isset($data['date'])) {

            $toUpdate['reservation_date'] = $data['date'];
        }



        if (isset($data['table_id'])) {

            $tableId = $this->getDecrypted($data['table_id']);

            if ($tableId < 0) {

                return ['status' => 400, 'message' => 'Error en el id de la mesa'];
            }

            //suponemos que si exites la tabla con ese id y que es el correcto

            $toUpdate['table_id'] = $tableId;
        }



        $toUpdate['comments'] = (isset($data['comments'])) ? $data['comments'] : $reservation->comments;





        $this->reservationRepository->update($toUpdate, $reservationId);



        return ['status' => 200, 'message' => 'ok'];
    }



    public function getCountReservationByRestaurantIdAndDateGroupedByZones(int $restaurantId, string $date, string $hour)

    {

        $finishDate = $this->getDayPlusOne($date); //working

        //$new_date = $date . ' ' . $hour;
        $new_date = $date;
        $salida = $this->reservationRepository->countByRestaurantIdbetweenDatesGroupByTableId($restaurantId, $date, $finishDate);

        $total_capacity = $salida->sum('capacity');

        $total_people = 0;



        $salida = $salida->map(function ($item) use ($new_date, $restaurantId, $total_people) {

            $reservations = $this->reservationRepository

                ->findByRestaurantIdAndReservationDateAndTableId($restaurantId, $new_date, $item->table_id, null);

            $capacity = $this->capacityByHour($reservations, $item->capacity, 0);

            return [

                "capacity"      => $item->capacity,

                "table_name"    => $item->table_name,

                "filter_name"   => $this->getUrlFormatName($item->table_name),

                "people"        => $capacity['total']

            ];
        });

        foreach ($salida as $value) {

            $total_people += $value['people'];
        }

        $salida[] = [

            "capacity"      => $total_capacity,

            "table_name"    => "Total",

            "filter_name"   => "all",

            "people"        => $total_people

        ];

        return $salida;
    }



    public function delete($reservationId)

    {

        $reservation = $this->reservationRepository->find($reservationId);

        if (!$reservation) {

            return ['status' => 404, 'message' => 'No existe la reservacion con ese id'];
        }

        $this->reservationRepository->delete($reservation->id);



        return ['status' => 204, 'message' => 'ok'];
    }

    public function cancel($reservationId)

    {

        $reservation = $this->reservationRepository->find($reservationId);

        if (!$reservation) {

            return ['status' => 404, 'message' => 'No existe la reservacion con ese id'];
        }

        if ($reservation->reservations_status_id !== 1) {

            return ['status' => 400, 'message' => 'No se puede cancelar la reserva si: se presento, se fue, no asistio o ya estaba cancelada'];
        }

        $this->reservationRepository->update(['reservations_status_id' => 5], $reservationId);

        return ['status' => 204, 'message' => 'ok'];
    }



    public function getCapacityByMonth(int $restaurantId, $year, $month)

    {
        //array with all the days of the month
        $dayOfMonth = $this->auxDaysOfYearMonth($year, $month);
        //gets the query result with all the reservations of the month
        $reservationCapacityPerdayBymonth = $this->reservationRepository->getCapacityPerDayByMonth($restaurantId, $year, $month);

        $totalCapacity = $this->restaurantRepository->totalCapacity($restaurantId);
        //set cancelled to 0 
        $startDate = Carbon::createFromFormat('Y-m-d', "{$year}-{$month}-01");
        $endDate = $startDate->copy()->endOfMonth();
        
        $reservationDates = PardepanBlocked::where('restaurant_id', $restaurantId)
            ->whereDate('reservation_date', '>=', $startDate)
            ->whereDate('reservation_date', '<=', $endDate)
            ->get(['reservation_date']) // Get only the reservation_date column
            ->groupBy(function ($item) {
                return intval(date('d', strtotime($item->reservation_date))); // Group by day of the month
            })
            ->map(function ($group) {
                return count($group); // Count the number of blocked dates for each day
            })
            ->toArray(); // Convert the collection to an array
        
       

        // Log::debug("total " . $totalCapacity);

        foreach ($reservationCapacityPerdayBymonth as $value) {

            $day = date('d', strtotime($value->reservation_day));
            $dayOfMonth[$day]['num_reservation'] += $value->num_reservations;
            $dayOfMonth[$day]['num_people'] += $value->num_people;
            $dayOfMonth[$day]['day'] = $day;


            if ($value->type == 'pardepan' && $value->reservations_status_id == 6) {
                $dayOfMonth[$day]['waitinglist'] += 1;
            }
            
            if ($value->type == 'pardepan' && $value->is_automatic == 1 && $value->seen == 0) {
                $dayOfMonth[$day]['automatic'] += 1;
            }
            //count cancelled reservations, status is 5
            if ($value->reservations_status_id == 5) {
                $dayOfMonth[$day]['cancelled'] += 1;
            }
          

        }



        foreach ($dayOfMonth as &$value) {

            $numPeople =  $value['num_people'];


            $blockedCount =0;// Use 0 if the day is not in the query results
         

            $reserved = round(($numPeople * 100) / $totalCapacity, 3);

            $value['reserved'] = $reserved;

            $value['capacity'] = 100 - $reserved;

            $value['pending'] = '0';

            $value['color'] = $this->getRangeColor($reserved);
            //add blocked
            $value['blocked'] = $blockedCount;
            //$value['dia'] is the number of the day like '01', '02', '03', etc
            //check if the day is in the array of blocked dates
            if (array_key_exists($value['dia'], $reservationDates)) {
                $value['blocked'] = $reservationDates[$value['dia']];
            }
            
            
        }
        

        $dayOfMonth['debug'] = $reservationCapacityPerdayBymonth;

        return $dayOfMonth;
    }



    public function detail($id)

    {

        $reservation = $this->reservationRepository->find($id);

        if (!$reservation) {

            return null;
        }



        // $client = $this->clientRepository->find($reservation->client_id);

        $client = $reservation->client;

        $table_type = $reservation->table->type;







        $salida = [];



        $salida = [

            'id' => $reservation->encrypt_id,

            'number_people' => $reservation->people,

            'date' => $reservation->reservation_date,

            'comments' => $reservation->comments,

            'table_number' => $reservation->table_number,

            'client_id' => $client->encrypt_id,

            'table_id' => $table_type->encrypt_id,
            'type' => $reservation->type,

        ];



        return $salida;
    }



    private function getRangeColor($reserved)

    {



        if (0 <= $reserved && $reserved < 50)

            return 'green';

        if (50 <= $reserved && $reserved < 80)

            return 'yellow';

        return 'red';
    }





    private function auxDaysOfYearMonth($year, $month)

    {



        $numberOfDay = cal_days_in_month(0, $month, $year);



        $list = [];



        for ($d = 1; $d <= $numberOfDay; $d++) {

            $time = mktime(12, 0, 0, $month, $d, $year);

            if (date('m', $time) == $month)

                $list[date('d', $time)] = [

                    'num_reservation' => 0,

                    'num_people' => 0,
                    'waitinglist' => 0,
                    'automatic' => 0,
                    //cancelled
                    'cancelled' => 0,
                    //blocked
                    'blocked' => 0,
                    'dia' => date('d', $time),

                ];
        }



        // Log::debug("number day of month " . $numberOfDay);



        return $list;
    }



    private function getfilterTableReservations($zone)

    {

        $zones = $this->createArrayZones();

        return array_key_exists($zone, $zones) ? $zones[$zone] : $zones['all'];
    }

    private function createArrayZones()

    {

        $tabletypes = $this->catalogRepository

            ->getList('table-type');

        $zones = [];

        foreach ($tabletypes as $value) {

            $zones[$this->getUrlFormatName($value->name)][] = $value->id;
        }
        //TODO colocar aqui que se genere automaticamente en vez de tener que espeficarlo como en la siguiente linea
       // $zones['all'] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,15 , 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120];
        //make zones an array with numbers from 1 to 200
        $zones['all'] = range(1, 450);
        return $zones;
    }

    /**

     * se regresa un arreglo de cada media hora apartir de la hora y la hora de cierre del

     * restaurante menos dos horas

     */

    private function getSchedulefromHour($date, $hour, $restaurantId)

    {

        $arreglo = [];
        $numericDayWeek = date('w', strtotime($date)) + 1; // numero del uno al 7

        $hours_service  = $this->restaurantRepository->getRestaurantServiceDay($restaurantId, $numericDayWeek);



        if (!$hours_service) {

            return [];
        }

        $openingHour = $hours_service->opening;

        $closingHour = $hours_service->closing;

        $breakStartHour = $hours_service->break_start;
        $breakEndHour = $hours_service->break_end;




        $time = date('Y-m-d H:i', strtotime($date)); // 16 de setptiembre a las 12 am



        $stopDate = ($closingHour) ? date('Y-m-d H:i', strtotime($date . ' ' . $closingHour)) : date('Y-m-d H:i', strtotime($time . '+1 day')); // 16 de septiembre a las 10 de la noche, o a las 12 am del dia siguiente
        

        //si la reserva es para hoy
        if( date('Y-m-d', strtotime($date)) == date('Y-m-d', strtotime('today'))){

            //if the opening hour is less than the current hour
            $opening = date('H:i', strtotime($openingHour));
            $current = date('H:i', strtotime('now'));
            //si el restaurante abre a las 5pm y son las 2pm
            if($opening > $current){
               
                $datetime = date('Y-m-d H:i', strtotime($date . ' ' . $openingHour));

            }else{ //si el restaurante abre a las 5pm y son las 6pm

                $lastHour = strtotime('now');
                $roundedTime = floor(date('i', $lastHour) / 30) * 30;
                $result = date('H:i', mktime(date('H', $lastHour), $roundedTime, 0));
                $datetime = date('Y-m-d H:i', strtotime($date . ' ' . $result));
            }
     
        }else{ //   si la reserva es para otro dia
            $datetime = date('Y-m-d H:i', strtotime($date . ' ' . $openingHour));
        }

  
        


        //si la hora dada por el usuario es mayor a la hora de apertura, entonces itera desde la hora del usuario -15

 
        // $datetime = date('Y-m-d H:i', strtotime($datetime . '-15 minutes'));


        //check if the restaurant has a break time
        $hasbreak = false;
        if ($breakStartHour !='00:00:00' && $breakEndHour !='00:00:00') { // si existe hora de receso
            //$hasbreak = true;
            $breakStartHour = date('Y-m-d H:i', strtotime($date . ' ' . $breakStartHour));
            $breakEndHour = date('Y-m-d H:i', strtotime($date . ' ' . $breakEndHour));
            //loop all the hours from the opening hour to the break start hour
        
            while ($datetime < $stopDate) { // colocar menor iuual en caso de que se necesita que salga la ultima hora

                if ($datetime < $breakStartHour || $datetime > $breakEndHour) {
                    $arreglo[] = $datetime;
                }


                $datetime = date('Y-m-d H:i', strtotime($datetime . '+30 minutes'));
              
                
                //$arreglo[] = $datetime;
                //if the time is not in the break time, then add it to the array
                //$arreglo[] =     $breakStartHour;
                //$arreglo[] =     $breakEndHour;
              
            }

        }else{
            //$hasbreak = false;
            while ($datetime < $stopDate) {

                $arreglo[] = $datetime;

                $datetime = date('Y-m-d H:i', strtotime($datetime . '+30 minutes'));
                
                
            }

        }

    

        return $arreglo;
    }

    private function capacityPerSchedule($schedule, $totalPeoble, $reservationPeople, $restaurantId, $tableId, $exclusive,$eventReservations)

    {

        $salida = [];
        $events = 0;
        $exclusive = 0;
        // schedule es un arreglo de horas 6:00, 7:00, 8:00, 9:00, 10:00, 11:00, 12:00, 13:00, 14:00, 15:00, 16:00, 17:00, 18:00, 19:00, 20:00, 21:00, etc 
        
        foreach ($schedule as $hour) {

            //trae todas las reservas de esa mesa en esa hora
            $reservations = $this->reservationRepository->findByRestaurantIdAndReservationDateAndTableId($restaurantId, $hour, $tableId, null);
            $total = 0;
            $events = 0;
            $contador = 0;
            $contador = $reservations->sum('people');
            //make total = the number of reservations
            $total = $reservations->count();
            $stringDateTime = explode(' ', $hour);
            //set targetdate in format Y-m-d H:i using strtotime
            $targetDate = date('Y-m-d H:i', strtotime($stringDateTime[0] . ' ' . $stringDateTime[1]));
            //get pardepanblocked where targetdate is between start and end time
            $pardepanBlocked = ParDePanBlocked::where('restaurant_id', $restaurantId)->where('start_time', '<=', $targetDate)->where('end_time', '>=', $targetDate)->get();
            $countpardepanblocked= $pardepanBlocked->count();


            foreach($eventReservations as $event){
                //if $hour is between the start and end time of the event
                $startDate = date('Y-m-d H:i', strtotime($event->start_date));
                $endDate = date('Y-m-d H:i', strtotime($event->end_date));
                if($targetDate >= $startDate && $targetDate <= $endDate){
                    $events++;
                }           
            }

            //get PardepanBlocked where targetdate is between start and end time
            $exclusive =  $events > 0;
            $salida[] = [

                'date' => $stringDateTime[0],
                'hour' => $stringDateTime[1],
                'avalable' => ($totalPeoble - $contador >= $reservationPeople) && $events <= 0 && $countpardepanblocked == 0,
                'capacity' => $totalPeoble - $contador,
                'events' => $events,
                'exclusive' => $exclusive,
                'count' => $total,
                'pardepanBlocked' => $pardepanBlocked,
                'targetDate' => $targetDate,
                'istodaydate' => date('Y-m-d', strtotime($targetDate)) == date('Y-m-d', strtotime('today')),
                'timetarget' =>date('Y-m-d', strtotime($targetDate)),
                'timetoday' => date('Y-m-d', strtotime('today')),


    
            ];

        }



        return $salida;
    }



    private function capacityByHour($reservations, $totalPeoble, $reservationPeople)

    {

        $contador = 0;



        foreach ($reservations as $reservation) {

            $contador += $reservation->people;
        }



        return [

            'avalable'  => $totalPeoble - $contador >= $reservationPeople,

            'capacity'  => $totalPeoble - $contador,

            'total'     => $contador

        ];
    }



    private function hasRestaurantAvalability($restaurantId, $date, $tableId, $reservationPeople, $totalPeoble, $reservationId)

    {

        $reservations = $this->reservationRepository

            ->findByRestaurantIdAndReservationDateAndTableId($restaurantId, $date, $tableId, $reservationId);

        $capacity = $this->capacityByHour($reservations, $totalPeoble, $reservationPeople);



        return $capacity['avalable'];
    }



    private function checkOperatingHours($restaurantId, $reservationDate)

    {

        $numericDayWeek     = date('w', strtotime($reservationDate)) + 1;

        $hours              = $this->restaurantRepository->getRestaurantServiceDay($restaurantId, $numericDayWeek);



        $status     = true;

        $message    = "El día que seleccionó, no es laboral para el restaurante";



        if ($hours) {

            $hour_reservation   = explode(' ', $reservationDate)[1];

            $date_reservation   = explode(' ', $reservationDate)[0];

            $hour_reservation   = date('H:i:s', strtotime($hour_reservation));



            $status  = ($hour_reservation >= $hours->opening && $hour_reservation  <= $hours->closing) ? true : false;

            $message    = "El horario que seleccionó, no está dentro de las horas laborales del restaurante";



            if ($status) {

                $date1 = new \DateTime($date_reservation . ' ' . $hours->closing);

                $date2 = new \DateTime($reservationDate);

                // $interval   = $date2->diff($date1);

                // $status     = ($interval->format('%H:%i') <= "01:59") ? false : true;

                $status     = ($date2 <= $date1) ? true : false;

                $message    = "El horario que seleccionó, es muy cercano a la hora de cierre del restaurante";
            }
        } else {

            $status = false;
        }

        // 'El horario no esta dentro de las horas laborales, o  ' . $reservationDate

        $data = (object)[

            'status'    => $status,

            'message'   => $message,

        ];

        return $data;
    }



    private function paymentRestaurant($restaurant_id, $people, $date_reservation, $reservation_id = null)

    {

        $year   = date('Y', strtotime($date_reservation));

        $month  = date('m', strtotime($date_reservation));

        $dollar = $this->dollar;



        $payment_restaurant = PaymentRestaurant::where('restaurant_id', $restaurant_id)

            ->whereMonth('payment_date', $month)

            ->whereYear('payment_date', $year)

            ->first();

        if ($payment_restaurant) {

            if ($reservation_id) {

                $reservation    = $this->reservationRepository->find($reservation_id);

                $amount_old     = $reservation->people * $dollar;



                $payment_restaurant->amount = ($payment_restaurant->amount - $amount_old) + ($people * $dollar);

                $payment_restaurant->save();
            } else {

                $payment_restaurant->amount += ($people * $dollar);

                $payment_restaurant->save();
            }
        } else {

            if ($reservation_id) {

                $reservation = $this->reservationRepository->find($reservation_id);

                $amount_old = $reservation->people * $dollar;



                $year   = date('Y', strtotime($reservation->reservation_date));

                $month  = date('m', strtotime($reservation->reservation_date));



                $payment_restaurant = PaymentRestaurant::where('restaurant_id', $reservation->table->restaurant_id)

                    ->whereMonth('payment_date', $month)

                    ->whereYear('payment_date', $year)

                    ->first();

                $payment_restaurant->amount = $payment_restaurant->amount - $amount_old;

                $payment_restaurant->save();
            }



            $payment_restaurant = PaymentRestaurant::create([

                'payment_date'      => $date_reservation,

                'amount'            => $people * $dollar,

                'restaurant_id'     => $restaurant_id,

                'payment_status_id' => 1,

            ]);



            $payment_restaurant->encrypt_id = encrypt($payment_restaurant->id);

            $payment_restaurant->save();
        }
    }
}
