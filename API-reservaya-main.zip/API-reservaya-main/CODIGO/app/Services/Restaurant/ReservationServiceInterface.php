<?php



namespace App\Services\Restaurant;



interface ReservationServiceInterface

{

    public function create(int $restaurantId, int $clientId, int $tableId, int $people, string $reservationDate, string $comments, $tableNumber, string $type,string $startDate,string $endDate, int $userId);



    public function update(int $restaurantId, int $reservationId, int $clientId, int $tableId, int $people, string $reservationDate, string $comments, $tableNumber);



    public function restauranCapacityBySchedule($restaurantId, $date, $hour, $people);



    public function getReservationsByRestaurantId($restaurantId, $zone, $date, $hour, $pageSize, $orderBy, $search);



    public function updateReservationStatus($reservationId, $status, $userId);



    public function getCountReservationByRestaurantIdAndDateGroupedByZones(int $restaurantId, string $date, string $hour );



    public function edit($reservationId,$data);



    public function delete($reservationId);

    public function cancel($reservationId);



    public function getCapacityByMonth(int $restaurantId,$year,$month);

    public function detail($id);

}

