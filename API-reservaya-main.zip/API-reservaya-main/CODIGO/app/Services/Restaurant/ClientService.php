<?php



namespace App\Services\Restaurant;



use App\Repositories\CategoryClientRestaurantRepositoryInterface;

use App\Repositories\ClientRepositoryInterface;

use App\Repositories\ReservationRepositoryInterface;

use App\Repositories\ClientRestaurantPreferenceRepositoryInterface;

use App\Repositories\UserRepositoryInterface;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Collection;

use App\Traits\AuxiliarFunctions;

use App\Models\Catalogs\Category;

use App\Models\Client;



class ClientService implements ClientServiceInterface

{

    use AuxiliarFunctions;



    /** @var CategoryClientRestaurantRepositoryInterface */

    private $categoryClientRestaurantRepository;



    /** @var ClientRepositoryInterface */

    private $clientRepository;



    /** @var ReservationRepositoryInterface */

    private $reservationRepository;



    /** @var ClientRestaurantPreferenceRepositoryInterface */

    private $preferenceRCRepository;



    /** @var UserRepositoryInterface */

    private $userRepository;



    public function __construct(

        CategoryClientRestaurantRepositoryInterface $categoryClientRestaurantRepository,

        ClientRepositoryInterface $clientRepository,

        ReservationRepositoryInterface $reservationRepository,

        ClientRestaurantPreferenceRepositoryInterface $preferenceRCRepository,

        UserRepositoryInterface $userRepository

    ) {

        $this->categoryClientRestaurantRepository = $categoryClientRestaurantRepository;

        $this->clientRepository         = $clientRepository;

        $this->reservationRepository    = $reservationRepository;

        $this->preferenceRCRepository   = $preferenceRCRepository;

        $this->userRepository           = $userRepository;

    }



    public function createRestaurantClient(

        string $email,

        string $firstName,

        string $middleName,

        $lastName,

        string $phone,

        $categories,

        int $restaurantId

    ) {

        if($email == "") {

            $client = $this->clientRepository->findByUserPhone($phone);

        }else{
                
            $client = $this->clientRepository->findByUserEmail($email);
        }

        Log::info('encontrado ' . $client);

        if (!$client) {

            $client = $this->clientRepository->createRestaurantClient($email, $firstName, $middleName, $lastName, $phone);

        }

        foreach ($categories as $categoryId) {

            Log::info('categoryId ' . $categoryId);



            $pivotId = $this->categoryClientRestaurantRepository->store($categoryId, $client->id, $restaurantId , 1);

            Log::info('pivotId ' . $pivotId);

        }



        return $client->id;

    }



    public function getClientsByEmailAndRestaurantId($email, $restaurantId)

    {

        $clients = $this->clientRepository->getRestaurantClientsByEmailClient($restaurantId, $email)->toArray();

        $data = [];



        foreach ($clients['data'] as $client) {

            $data[] = [

                'id' => $client['encrypt_id'],

                'email' => $client['email'],

                'first_name' => $client['first_name'],

                'middle_name' => $client['middle_name'],

                'last_name' => $client['last_name'],

                'phone' => $client['cell_phone'],

            ];

        }



        $clients['data'] = $data;



        return $clients;

    }



    public function findByRestaurantAndEmail($restaurantId, $email)

    {

        $client = $this->clientRepository->findByUserEmail($email);

        if (!$client) {

            $user = $this->userRepository->findByMail($email);

            if($user){

                $data = ['status' => false, 'role' => $user->role->name];

                return $data;

            }

            return null;

        }



        $categories = $this->clientRepository->getCategoryNameByIdAndRestaurantId($client->id, $restaurantId);

        $client = $client->toArray();



        unset($client['description']);

        $client['id'] = $client['encrypt_id'];

        unset($client['encrypt_id']);

        $client['categories'] = $categories;

        Log::debug("Client :" . json_encode($client));



        return $client;

    }



    public function getClientsByRestaurantIdAndType($restaurantId, $type, $pageSize, $orderBy)

    {

        $clientStatusId = ('puerta21' === $type) ? [1, 2] : [3,4,5,6,7,8,9,10];



        $columns = ['nombre', 'asistentes', 'estatus'];

        $order = $this->parseOrderByQuery($orderBy, $columns);



        $clients = $this->clientRepository

            ->getRestaurantClientsByClientStatusPaginated($restaurantId, $clientStatusId, $pageSize, $order)

            ->appends(['pagesize' => $pageSize, 'orderBy' => $orderBy])

            ->toArray();



        $data = [];

        foreach ($clients['data'] as $value) {

            $client = Client::find($value['client_id']);

            $data[] = [

                'id'            => $value['encrypt_id'],

                'categories'    => $this->clientRepository->getCategoryNameByIdAndRestaurantId($value['client_id'], $restaurantId),

                'first_name'    => $value['first_name'],

                'middle_name'   => $value['middle_name'],

                'last_name'     => $value['last_name'],

                'cell_phone'    => $value['cell_phone'],

                'visits'        => $value['visits'],

                'total_spend'   => !$value['total_spend'] ? 0 : $value['total_spend'],

                'photo'         => $this->getImage($client->user->photo),

                'email' => $client->user->email,

            ];

        }

        $clients['data'] = $data;



        return $clients;

    }



    public function findByIdAndTypeWithRestaurantInfo(int $id, $restaurantId, $type)

    {

        if ($id < 0) {

            return null;

        }

        Log::debug("id :" . $id);

        Log::debug("type :" . $type);



        $client = $this->clientRepository->findByIdWithUser($id);



        if (!$client) {

            return null;

        }

        $clientStatusId = ('puerta21' === $type) ? [1, 2] : [5];



        if (!in_array($client->client_status_id, $clientStatusId)) {

            return null;

        }



        $preference = $this->preferenceRCRepository->findByRestaurantIdAndClientId($restaurantId, $client->id);



        $visit = $this->reservationRepository->countClientReservationsStatusByRestaurant($restaurantId, $client->id);

        Log::debug("Count visits" . json_encode($visit));

        

        $spent = $this->reservationRepository->getSpentByClientInRestaurant($restaurantId, $client->id);

        Log::debug("Spent " . json_encode($spent));



        $category = $this->clientRepository->getCategoryNameByIdAndRestaurantId($client->id, $restaurantId);



        $photo = $this->getImage($client->user->photo);



        return $this->fillClientDetailInfo($client, $category, $preference, $visit, $spent, $photo);

    }



    private function fillClientDetailInfo($client, $category, $preference, $visit, $spent, $photo)

    {



        if (!$preference) {

            $preference = (object)[

                'rating' => 5,

                'friend' => 'none',

                'drink' => 'none',

                'food' => 'none',

                'table' => 'none',

                'extra_comments' => 'none',

            ];

        }



        $salida = [

            'id'            => $client->encrypt_id,

            'first_name'    => $client->first_name,

            'middle_name'   => $client->middle_name,

            'last_name'     => $client->last_name,

            'cell_phone'    => $client->cell_phone,

            'email'         => $client->user->email,

            'category'      => $category,

            'photo'         => $photo,

            'average_spend' => ($spent->avg) ? $spent->avg : 0.0,

            'total_spend'   => ($spent->total) ? $spent->total : 0.0,

            'visits'        => ($visit->ha_asistido + $visit->se_ha_ido),

            'no_shows'      => $visit->no_show,

            'birthdayDate' =>  $client->birthday_date,

            'cancellations' => $visit->cancelado,

            'friend_of'     => $preference->friend,

            'drink'         => $preference->drink,

            'food'          => $preference->food,

            'table'         => $preference->table,

            'extra_comments'         => $preference->extra_comments,

            'rating'        => $preference->rating,

            'survey'        => (object)[

                'professions'               => $client->professions,

                'industries'                => $client->industries,

                'nutritional_requirements'  => $client->nutritional_requirements,

                'tables'                    => $client->tables,

                'allergies'                 => $client->allergies,

                'drinks'                    => $client->drinks,

                'foods'                     => $client->foods,

                'specifications'            => $client->specifications,

            ]

        ];



        if ($client->client_status_id === 1) {

            $salida['client_preferences'] = [];

        }

        return $salida;

    }



    public function serchClientsByRestaurantIdAndType($type, $search, $restaurantId, $pageSize)

    {

        $clientStatusId = ('puerta21' === $type) ? [1, 2] : [5];



        $clients = $this->clientRepository

            ->searchRestaurantClientsByClientStatusPaginated($restaurantId, $clientStatusId, $search, $pageSize)

            ->appends(['pagesize' => $pageSize])

            ->toArray();

        $data = [];

        foreach ($clients['data'] as $value) {

            $data[] = [

                'id' => $value['encrypt_id'],

                // 'category' => $this->clientRepository->getCategoryNameByIdAndRestaurantId($value['client_id'], $restaurantId),

                'first_name' => $value['first_name'],

                'middle_name' => $value['middle_name'],

                'last_name' => $value['last_name'],

                'cell_phone' => $value['cell_phone'],

                'visits' => $value['visits'],

                'total_spend' => !$value['total_spend'] ? 0 : $value['total_spend'],

            ];

        }

        $clients['data'] = $data;



        return $clients;

    }



    public function getDataToExportByRestaurantIdAndType($restaurantId, $type, $search, $orderBy)

    {



        $clientStatusId = ('puerta21' === $type) ? [1, 2] : [5];



        $clients =  $this->clientRepository

            ->getRestaurantClientsByClientStatus($restaurantId, $clientStatusId, $search)->toArray();





        $data = [];

        foreach ($clients as $value) {

            $categories = $this->clientRepository->getCategoryNameByIdAndRestaurantId($value['client_id'], $restaurantId)->toArray();

            $categories = $this->updateCategoryName($categories);

            

            $data[] = (object)[

                'id' => $value['encrypt_id'],

                'categories' =>  implode(", ", $categories),

                'first_name' => $value['first_name'],

                'middle_name' => $value['middle_name'],

                'last_name' => $value['last_name'],

                'phone' => $value['cell_phone'],

                'email' => $value['email'],

                'visits' => $value['visits'],

                'total_spend' => !$value['total_spend'] ? 0 : $value['total_spend'],

            ];

        }



        return $data;

    }



    public function updateRestaurantClientPreferences($restaurantId,$id,$data)

    {

        $client = $this->clientRepository->find($id);

        if(!$client){

            return ['status' => 404, 'message' => 'No existe el cliente'];

        }



        if(empty($data)){

            return ['status' => 200, 'message' => 'Nada que editar'];

        }



        $updated = $this->preferenceRCRepository->updatePreference($restaurantId,$client->id,$data);



        return ($updated)? ['status' => 200, 'message' => 'Información actualizada correctamente']:['status' => 500, 'message' => null];





    }



    public function updateRestaurantClientCategory($restaurantId, $id, $categoryId, $status)

    {

        $client = $this->clientRepository->find($id);

        if(!$client){

            return ['status' => 404, 'message' => 'No existe el cliente'];

        }



        $category = Category::find($categoryId);

        

        if(!$category){

            return ['status' => 404, 'message' => 'No existe la categoria'];

        }



        $updated = $this->categoryClientRestaurantRepository->store($categoryId, $id, $restaurantId , $status);



        return ($updated)? ['status' => 200, 'message' => 'Información actualizada correctamente']:['status' => 500, 'message' => null];





    }



    public function updateCategoryName($categories)

    {

        $data =  [];



        foreach ($categories as $category) {

            array_push($data, $category['name']);

        }



        return $data;

    }

}

