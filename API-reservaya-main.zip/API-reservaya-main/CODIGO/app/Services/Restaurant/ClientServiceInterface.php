<?php

namespace App\Services\Restaurant;

interface ClientServiceInterface
{
    public function createRestaurantClient(
        string $email,
        string $firstName,
        string $middleName,
        $lastName,
        string $phone,
        mixed $categories,
        int $restaurantId
    );

    public function getClientsByEmailAndRestaurantId($email, $restaurantId);

    public function getClientsByRestaurantIdAndType($restaurantId, $type, $pageSize, $orderBy);

    public function getDataToExportByRestaurantIdAndType($restaurantId, $type,$search,$orderBy);

    public function findByIdAndTypeWithRestaurantInfo(int $id, $restaurantId, $type);

    public function serchClientsByRestaurantIdAndType($type, $search, $restaurantId, $pageSize);

    public function findByRestaurantAndEmail($restaurantId,$email);

    public function updateRestaurantClientPreferences($restaurantId,$id,$data);

    public function updateRestaurantClientCategory($restaurantId, $id, $categoryId, $status);

}
