<?php

namespace App\Services\Auth;

interface AuthServiceInterface
{
    /**
     * Metodo que maneja el olvido de contraseña.
     */
    public function handleForgotPassword(string $email);

    public function handleResetPassword($resetToken, $password);
}
