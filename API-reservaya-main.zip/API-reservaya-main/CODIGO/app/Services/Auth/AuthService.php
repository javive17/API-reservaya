<?php

namespace App\Services\Auth;

use App\Notifications\ResetPassword;
use App\Repositories\PasswordResetRepositoryInterface;
use App\Repositories\UserRepositoryInterface;
use App\Traits\AuxiliarFunctions;
use Illuminate\Support\Facades\Mail;

class AuthService implements AuthServiceInterface
{
    use AuxiliarFunctions;

    /** @var UserRepositoryInterface */
    private $userRepository;

    /** @var PasswordResetRepositoryInterface */
    private $passwordResetRepository;

    public function __construct(
        UserRepositoryInterface $userRepository,
        PasswordResetRepositoryInterface $passwordResetRepository
    ) {
        $this->userRepository = $userRepository;
        $this->passwordResetRepository = $passwordResetRepository;
    }

    public function handleForgotPassword(string $email)
    {
        $user = $this->userRepository->findByMail($email);

        $userstate = $this->checkUsersEmailIsVerifiedAndIsActiveByEmail($user);

        if (!empty($userstate)) {
            return $userstate;
        }

        $resetToken = $this->generateToken();

        $this->passwordResetRepository->createOrUpdateUserResetToken($user->email, $resetToken);

        $resetLink = $this->getLandingPageEnvironmentUrl(). 'recoverPassword?token=' . $resetToken;

        if (config('app.debug')) {
            $scapeSendMailTo = [
                'admin@kokonutstudio.com',
                'client@kokonutstudio.com',
                'manager@kokonutstudio.com',
                'host@kokonutstudio.com',
            ];
            if (!in_array($user->email, $scapeSendMailTo)) {
                $user->notify(new ResetPassword($resetLink, 'reset_password'));
            }
        }else{
            $user->notify(new ResetPassword($resetLink, 'reset_password'));
        }

        // $userToNotify =  ? $this->userRepository->findByMail('jonathan@kokonutstudio.com') : $user;

        $data = ['email' => $user->email];


        // for debuging only
        if (config('app.debug')) {
            $data['reset_token'] = $resetToken;
            $data['reset_link'] = $resetLink;
        }

        return ['message' => 'Enlace para restablecer contraseña enviado al usuario', 'status' => 200, 'data' => $data];
    }

    public function handleResetPassword($resetToken, $password)
    {
        $email = $this->passwordResetRepository->checkUserResetTokenIsValid($resetToken);

        if (!$email) {
            return ['message' => 'Token inválido', 'status' => 401];
        }

        $user = $this->userRepository->findByMail($email);

        $userstate = $this->checkUsersEmailIsVerifiedAndIsActiveByEmail($user);

        if (!empty($userstate)) {
            return $userstate;
        }

        $this->userRepository->update(['password' => bcrypt($password)], $user->id);

        $this->passwordResetRepository->deleteResetToken($resetToken);

        return ['message' => 'Contraseña de usuario restablecida', 'status' => 200];
    }

    /**
     * Metodo auxiliar que comprueba si el usuario esta verificado y activado.
     *
     * @param mixed $user
     */
    private function checkUsersEmailIsVerifiedAndIsActiveByEmail($user)
    {
        if (!$user) {
            return ['message' => 'El correo ingresado no es correcto', 'status' => 404];
        }

        if (!$user->email_verified_at) {
            return ['message' => 'Correo no verificado', 'status' => 401];
        }
        if (!$user->active) {
            return ['message' => 'Usuario no activado', 'status' => 401];
        }

        return [];
    }

    /**
     * Metodo auxiliar que envia el correo segun el nombre de el correo.
     *
     * @param mixed $data
     * @param mixed $response
     */
    private function sendMailByClassName(string $className, string $mailtoSend, $data, $response)
    {
        $mail = 'App\\Mail\\' . $className;
        if (!$response) {
            $response = [];
        }

        try {
            Mail::to($mailtoSend)->send(new $mail($data));
        } catch (\Throwable $th) {
            if (config('app.debug')) {
                throw $th;
            }
            $response['error'] = ['message' => $th->getMessage(), 'traceAsString' => $th->getTraceAsString()];
        }
    }
}
