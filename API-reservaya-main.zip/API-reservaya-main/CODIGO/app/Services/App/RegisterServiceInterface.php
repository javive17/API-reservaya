<?php

namespace App\Services\App;

interface RegisterServiceInterface
{
}
