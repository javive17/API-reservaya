<?php

namespace App\Repositories;
interface UserRepositoryInterface extends RepositoryInterface
{
    public function createWithEncryptId(array $userRequest, string $password = null, int  $roleId =2, $chief_manager=false);
    public function findByHashedMail(string $hashedEmail);
    public function findByMail(string $email);
    public function verifyUserEmail(int $id);
    public function createRestaurantStaff($email,$password,$roleId,$restaurantId);
    public function allRestaurantStaff($restaurantId,$email);
    public function allRestaurantStaffFilterByEmailOrderByPaginated($restaurantId,$email,$orderBy=[],$pageSize=10);

    public function existUserWithEmail($id,$email);
    public function storePhoto($file, $user);

}
