<?php



namespace App\Repositories;



interface ClientRepositoryInterface extends RepositoryInterface

{

    public function createWithEncryptId(array $request, int $userId, int $statusClient = 3);



    public function findByUserId(int $idUser);



    public function getRestaurantClientsByEmailClient(int $restaurantId, string $email);



    public function getRestaurantClients(int $restaurantId);



    public function getRestaurantClientsByClientStatus(int $restaurantId, array $clientStatusId,string $search);



    public function getRestaurantClientsByClientStatusPaginated(int $restaurantId, array $clientStatusId, string $pageSize, array $order);



    public function searchRestaurantClientsByClientStatusPaginated(int $restaurantId, array $clientStatusId, string $search, int $pageSize);



    public function createRestaurantClient(string $email, string $firstName, string $middleName, string $lastName, string $phone);



    public function findByUserEmail(string $email);
    public function findByUserPhone(string $phone);
    public function findByUserEmailOrPhone(string $email, string $phone);


    public function getCategoryNameByIdAndRestaurantId(int $id, int $restaurantId);



    public function findByIdWithUser($id);



    public function createSocialMedia(array $data, int $client_id);



    public function getClientList($request, $type, $client);



    public function getName($client);



    public function getProfilePublic($client, $status);



    public function getProfilePublicFollowings($request, $client);



    public function getProfilePublicFollowers($request, $client);



    public function getProfilePublicPublications($request, $client);



    public function storePublication($request, $user, $publication_type_id);



    public function listClientsFounders($request, $type, $client_status_id, $page_size, $order_by);



    public function clientsListReport($request, $type, $client_status_id);



    public function getListMessagingClient($request, $type, $client);



    public function getClientStories($client_id);



    public function getStories($client_id, $client);



    public function getListReportedPublications($request, $type, $page_size);

}

