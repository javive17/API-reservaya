<?php



namespace App\Repositories\Eloquent;



use App\Repositories\CatalogRepositoryInterface;

use Illuminate\Support\Facades\Log;



class CatalogRepository implements CatalogRepositoryInterface

{

    public function getList(string $modelName)

    {

        $model_class_name = $this->getModelName($modelName);

        Log::info($model_class_name);

        $model = 'App\\Models\\Catalogs\\'.$model_class_name;



        if (!class_exists($model)) {

            return null;

        }
  
        if($model_class_name=='TableType')
        {
         
            return $model::where("restaurant_id",null)->get();
        }

        if($model_class_name == 'Kitchen') {
            return $model::orderBy('name')->get();
        }else {
            return $model::all();
        }
    }



    /**

     * get model name.

     *

     * @param mixed $model_name

     */

    private function getModelName($model_name)

    {

        $model_words = explode('-', $model_name);

        $model_class_name = '';



        foreach ($model_words as $word) {

            $model_class_name .= ucfirst($word);

        }



        return $model_class_name;

    }

}

