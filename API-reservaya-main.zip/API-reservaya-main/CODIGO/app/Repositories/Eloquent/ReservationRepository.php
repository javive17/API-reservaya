<?php



namespace App\Repositories\Eloquent;



use App\Models\Reservation;

use App\Models\Restaurant;

use App\Repositories\ReservationRepositoryInterface;

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Log;

use App\Traits\AuxiliarFunctions;

use Carbon\Carbon;

use Illuminate\Support\Facades\Mail;

use App\Jobs\SendNotifications;

use App\Mail\AcceptReservation;

use App\Models\Device;

class ReservationRepository extends BaseRepository implements ReservationRepositoryInterface

{

    use AuxiliarFunctions;



    /**

     * Reservationrepositori constructor.

     */

    public function __construct(Reservation $reservation)

    {

        parent::__construct($reservation);
    }



    public function findByRestaurantId($restaurantId)

    {

        return $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->select('t_reservations.*')

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->get();
    }

    public function SendPushNotificationToRestaurant($restaurantID, $reservationID)
    {
        $devices = Device::where('restaurant_id', $restaurantID)->orderBy('id', 'desc')->take(5)->get();
        foreach ($devices as $device) {
            $data = (object) [
                'notification_id' => $device->id, // Assuming device ID is used as notification ID
                "token"           => $device->token,
                "platform"        => $device->platform,
                'reservation_id'    => $reservationID,
                'title'           => 'Nueva Reserva', // Customize your title
                'body'            => '¡BUENAS NOTICIAS! Ha recibido una nueva reserva!', // Customize your body
                'date'            => date('Y-m-d'),
            ];
    
            $this->sendGCM($data); // Now it works because sendGCM is a method of the same class

        }



    }

    public function sendGCM($datos)
    {
        // Your existing sendGCM function implementation
        $notification = array(
            'title' => $datos->title,
            'body'  => $datos->body,
            'data'  => $datos,
            'sound' => 'default',
            'badge' => '1',
            'style' => 'inbox'
        );
        $arrayToSend = array(
            'to' => $datos->token,
            'notification' => $notification,
            'priority' => 'high'
        );
    
        $json = json_encode($arrayToSend);
        $headers = array();
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Authorization: key='. env("FIREBASE_API_ACCESS_KEY");
        $ch = curl_init();
    
        if (env("APP_ENV") == 'local') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
    
        curl_setopt($ch, CURLOPT_URL, env("FIREBASE_API_URL"));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
        // Set cURL to return the result instead of printing it
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
        // Execute the cURL request
        $response = curl_exec($ch);
    
        // Check for errors
        if ($response === false) {
            // Log the error or handle it as needed
            error_log('cURL Error: '. curl_error($ch));
        } else {
            // Optionally, process the response if needed
            // For example, you might want to log the response or return it
            error_log('cURL Response: '.$response);
        }
    
        // Close the cURL session
        curl_close($ch);
    }


    public function findByRestaurantIdWithClientByMonthOrderedPaginated($restaurantId, $year, $month, $pageSize, $orderBy) // TODO: $orderBy = []

    {



        $query =  $this->queryfindByRestaurantIdWithClientByMonth($restaurantId, $year, $month);



        if (!empty($orderBy)) {

            foreach ($orderBy as $value) {

                $query->orderBy($value[0], $value[1]);
            }
        } else {

            $query->orderBy('t_reservations.reservation_date', 'desc');
        }



        // Log::debug($query->toSql());

        return $query->paginate($pageSize);
    }





    public function findByRestaurantIdWithClientByMonth($restaurantId, $year, $month)

    {

        return $this->queryfindByRestaurantIdWithClientByMonth($restaurantId, $year, $month)->get();
    }



    private function queryfindByRestaurantIdWithClientByMonth($restaurantId, $year, $month)

    {

        return $this->queryAllWithClientAndStatusAndTable()

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->whereMonth('t_reservations.reservation_date', $month)

            ->whereYear('t_reservations.reservation_date', $year);

        // ->whereIn('t_reservations.reservations_status_id', [2, 3]);

    }



    public function findByRestaurantIdWithClientAndStatusAndTable($restaurantId)

    {

        return $this->queryAllWithClientAndStatusAndTable()

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->paginate(10);
    }



    public function findByRestaurantIdAndDateIdWithClientAndStatusAndTable($restaurantId, $date)

    {

        return $this->queryAllWithClientAndStatusAndTable()

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->whereBetween('t_reservations.reservation_date', [$date, date('Y-m-d', strtotime($date . '+1 day'))])

            ->paginate(10);
    }



    public function findByRestaurantIdAndDateIdWithClientAndStatusAndTableFilterByTableTypes($restaurantId, $date, $tableTypes, $pageSize, $orderBy, $search)

    {

        if ($search) {

            $query = $this->queryAllWithClientAndStatusAndTableByName($search)

                ->where(['t_tables.restaurant_id' => $restaurantId])

                ->whereBetween('t_reservations.reservation_date', [$date, date('Y-m-d', strtotime($date . '+1 day'))])
                ->whereIn('c_tables_type.id', $tableTypes);
        } else {



            $query = $this->queryAllWithClientAndStatusAndTable()

                ->where(['t_tables.restaurant_id' => $restaurantId])

                ->whereBetween('t_reservations.reservation_date', [$date, date('Y-m-d', strtotime($date . '+1 day'))])
                ->whereIn('c_tables_type.id', $tableTypes);
        }

        if (!empty($orderBy)) {

            foreach ($orderBy as $value) {

                $query->orderBy($this->getColumnTable($value[0]), $value[1]);
            }
        }


        return $query->paginate(500); 
    }


    public function getVisitsByReservationClientId($client_id, $restaurant_id){

        // get t_tables as an array
        $tables =[];
        $tables = Restaurant::find($restaurant_id)->tables()->pluck('id')->toArray();
        //status = 1 en espere, 2 ha asistido, 3 se ha ido, 4 no show, 5 cancelado, 6 lista de espera, 7 cancelado por el cliente, 8 rechazado, 9aceptado, , 10 eliminado
        $reservations = Reservation::where('client_id', $client_id)->whereIn('reservations_status_id', [2,3,9])->whereIn('table_id',$tables)->get()->count();
        return $reservations;
    }
    private function getColumnTable($generalColumn)

    {

        $TableColumns = [

            'nombre'        => 'client_name',

            'asistentes'    => 'people',

            'estatus'       => 'status',

            'fecha'         => 'reservation_date',

        ];

        return $TableColumns[$generalColumn];
    }



    public function findByRestaurantIdAndReservationDate($restaurantId, $date)

    {

        return Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->select('t_reservations.*')

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->whereBetween('t_reservations.reservation_date', [$date, date('Y-m-d H:i', strtotime($date . '+1 day'))])

            ->get();
    }



    public function findByRestaurantIdAndReservationDateAndTableId($restaurantId, $date, $tableId, $reservationId = null)

    {

        $init_date      = date('Y-m-d H:i', strtotime($date));

        $finish_date    = date('Y-m-d H:i', strtotime($date . '+1 hour'));



        if ($reservationId) {

            $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                ->select('t_reservations.*', 't_tables.capacity')

                ->where(['t_tables.restaurant_id' => $restaurantId, 't_tables.id' => $tableId, 't_reservations.reservations_status_id' => 1])

                ->where('t_reservations.id', '!=', $reservationId)

                ->whereBetween('t_reservations.reservation_date', [$init_date, $finish_date])

                ->get();
        } else {

            $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                ->select('t_reservations.*', 't_tables.capacity')

                ->where(['t_tables.restaurant_id' => $restaurantId, 't_tables.id' => $tableId, 't_reservations.reservations_status_id' => 1])

                ->whereBetween('t_reservations.reservation_date', [$init_date, $finish_date])

                ->get();
        }



        return $reservations;
    }

     
       

    public function store($client_id, $table_id, $comments, $people, $reservation_date, $tableNumber, $type, $startDate, $endDate,$userId)

    {
        //get auth user
        $reservation_status = 1;
        if ($type == 'pardepan') {
            $reservation_status = 6;
        }

        // Log::info($tableNumber);

        $date_start = date('Y-m-d H:i');

        $date_final = date('Y-m-d H:i', strtotime($date_start . '+1 days'));
        $sdate= date('Y-m-d H:i', strtotime($startDate));
        $edate= date('Y-m-d H:i', strtotime($endDate));
        $validator = ($reservation_date < $date_final) ? 1 : 0;

        $reservation = Reservation::create([

            'reservation_date'      => date_create($reservation_date),

            'people'                => $people,

            'comments'              => $comments,

            'reservations_status_id' => $reservation_status,

            'client_id'             => $client_id,

            'table_id'              => $table_id,

            'table_number'          => $tableNumber,

            'notification'          => $validator,

            'type'                  => $type,
            'start_date'            => $sdate,
            'end_date'              => $edate,
            'created_by'            => $userId,
        ]);

        $reservation->encrypt_id = encrypt($reservation->id);

        $reservation->save();
        #refresh reservation
        $reservation->refresh();

        // Log::info("Reservation \n" . json_encode($reservation));
        $restaurant = Restaurant::find($reservation->table->restaurant_id);
        $restaurantID = $reservation->table->restaurant_id;
       $this->SendPushNotificationToRestaurant($restaurantID, $reservation->id);

	#Verificar si el restaurante acepta reservaciones automaticas
        if($reservation && $type == 'pardepan'){
   
            //send notification to restaurant
   
            if($restaurant->accept_automatic_reservation == 1 && $people <= $restaurant->automatic_reservations ){
                $reservation->reservations_status_id = 9;
                $reservation->is_automatic = 1;
                $reservation->save();
                $reservation->refresh();
       		    $convert_restaurant_name = str_replace(' ', '-', $reservation->table->restaurant->name);
	            $name_image = $convert_restaurant_name . '.png';
	            $url = 'https://pardepan.puerta21.club/images/rounded/' . $name_image;
	            #verificar si existe la imagen
	            $headers = get_headers($url);
	            if (preg_match("/404/", $headers[0])) {
	                $url = 'https://pardepan.puerta21.club/images/rounded/one-picture.png';
	            }
	
	            $data_user = (object) [
	                'name' => $reservation->client->first_name,
	                'full_name' => $reservation->client->full_name,
	                'email' => $reservation->client->user->email,
	            ];
	
	            $data_reservation = (object) [
	                'reservation_eid' => $reservation->encrypt_id,
	                'restaurant' => $reservation->table->restaurant->name,
	                'restaurant_group_type' => $reservation->table->restaurant->group_type,
	                'image' => $url,
	                'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
	                'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
	                'people' => $reservation->people,
	            ];
                $phone = $reservation->client->cell_phone;
                if ($phone != null && $phone !== '') {
                    $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
$body ="¡Buenas noticias,  " . $name . "!    

Nos complace anunciarte que tu reserva en ".$reservation->table->restaurant->name." ha sido confirmada exitosamente. 😊
  
• 📅  Fecha: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
• 🕒  Hora ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')."
• 👥  Número de personas " . $reservation->people;

                                
if ($reservation->restaurant_group_type == 'casa_de_campo'){
    $body = $body. "
*IMPORTANTE:* En caso de necesitar acceso al resort, por favor póngase en contacto con el restaurante vía limoncello888@hotmail.com";
} 
                    
if ($reservation->restaurant_group_type == 'peperoni_casa_de_campo') {      
    $body = $body. "
*IMPORTANTE:* Sólo y exclusivamente aquellos que son propietarios o invitados por un propietario podrán acceder al resort. La reserva sin previo acceso a Casa de Campo no es válida.";
}
                    
if ($reservation->restaurant_group_type == 'cap_cana') 
{
    $link = "https://reservaya.com.do/usuario/reservation/formulario/".$reservation->encrypt_id;
    $body = $body. "
*IMPORTANTE:* Si no tiene acceso a Cap Cana, por favor, use el siguiente enlace ".$link." para completar su información y la de todos sus acompañantes para generar el código QR de acceso a Cap Cana. Su información será sólo compartida con la oficina de control de acceso a Cap Cana.";
}
                    
if ($reservation->restaurant_group_type == 'cap_cana_maralia'){
                                
    $body = $body. "
*IMPORTANTE:* Para visitantes no proprietarios / no residentes, existe un consumo mínimo de 50 USD por persona. Por favor, descárguese la siguiente aplicación para realizar el pago:

1- IOS (App Store) https://apps.apple.com/us/app/cap-cana/id1451501100
2- Android (Play Store) https://play.google.com/store/apps/details?id=co.xhinola.capcana.guests
3- ( No es posible descargar el App desde computadora )";
}
                                
                      
if($reservation->restaurant_group_type == 'zuquero'){
$body = $body. "
Le informamos que debe llegar su grupo completo para concederles su mesa. 
                                
Luego de 15 minutos pasados la hora de su reserva, la mesa será cedida.
                                
Globos y pastel son permitidos en la mesa al momento de cantar cumpleaños.
                                
Por favor le requerimos un código de vestimenta casual-elegante.
                                
No se permiten:
- Sombreros
- Gorras
- Bermudas
- Chancletas
- T-Shirt sin mangas
- O bandas contratadas particularmente.
- Traer bebidas de ningun tipo.
                    
Por favor compartir esta información con las demás personas de su grupo y reserva. 
";

}
                                
if($reservation->restaurant_group_type == 'botaniko'){
                                
$body = $body. "    
Respetuosamente se requiere un código de vestimenta casual elegante.
Botaniko se reserva el derecho de seleccionar en la entrada.
                                
No se permiten:
                   
- T-shirt o camisetas de hombre sin mangas                 
- Gorras    
- Bermudas               
- Jeans rotos                
- Escotes pronunciados                
- Faldas cortas                 
- Cinturas descubiertas                
- Chancletas  

Por favor compartir esta información con las demás personas de su grupo y reserva. ¡Le esperamos!";
                                
}
if($reservation->restaurant_group_type == 'peperoni')
{
$body = $body. "
Respetuosamente requerimos un código de vestimenta CASUAL ELEGANTE. Queda bajo nuestra discreción el derecho de admisión.
                    
No se permiten:
              
- Gorras             
- Bermudas            
- Jeans rotos              
- Escotes pronunciados           
- Faldas cortas         
- Cinturas descubiertas            
- Chancletas                         
- Camisa o tshirt de hombres sin manga
                                
Si no cumple con nuestro código de vestimenta, no se le permitirá la entrada ni permanecer en el establecimiento.

Por favor compartir esta información con las demás personas de su reserva. Le esperamos!";

}
if($restaurant->group_type == 'lalocanda')
{
$body = $body. "

•  La reserva se mantendrá por 15 minutos posteriores a la hora establecida. Pasado este tiempo quedará automáticamente cancelada, y se dará ingreso de acuerdo a la disponibilidad que maneje el restaurante en ese momento, por éste motivo le solicitamos ser puntual. 

•  Procure asistir con el número exacto de invitados que ha reservado para que no excedan la capacidad de los asientos asignados. Si resultan menos favor informar con antelación.

•  Favor respetar nuestro código de vestimenta que es casual o semiformal,no pantalones cortos o rotos, gorras y/o sandalias

•  La ubicación de las mesas se realiza de manera automática, de acuerdo con el orden de entrada de su reserva y la cantidad de personas de la misma.";

}
if ( $restaurant->group_type == 'farah')
{

$body = $body. "

Es de su conocimiento  que debe de llegar el grupo completo para poder ocupar la mesa. Su tiempo de espera es 15 minutos  después de la hora pautada para su reservación. Pasado el tiempo la mesa se le cederá a otro cliente.
 
Respetuosamente requerimos un código de vestimenta CASUAL. Queda bajo nuestra discreción el derecho de admisión.
 
No se permiten:
 
• BERMUDAS
• CHANCLETAS
• JEANS ROTOS
• CAMISA o TSHIRT de hombres SIN mangas
 
Por favor compartir esta información con las demás personas de su reserva.";
}

$link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;
                   
$body = $body. "

🕐 Te recordamos que la validez de esta reserva es de 10 minutos después de la hora programada. Si no llegas con el 50% de tus invitados, la mesa estará sujeta a disponibilidad.                                


Si lo desea, siempre puede CANCELAR su reserva en 
" . $link . " 

Si deseas modificar la reserva es decir: cambiar la hora, el día o número de personas y la reserva ya ha sido aceptada por el restaurante tendrás cancelar la reserva y volver a realizarla.


📞 Para consultas o modificaciones de la reserva, no dudes en contactar directamente al restaurante

¡Gracias por elegirnos!

@ReservaYaRD
";  

if ( $restaurant->group_type == 'farah')
{
$link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

$body = $body . "
*↓ ENGLISH ↓*";
    
$body = $body . "
    
*GOOD NEWS!* Your reservation has been successfully confirmed! 😊
            
Estimado cliente por acá le compartimos nuestro menú. ".$reservation->table->restaurant->name." has been successfully confirmed
            
* Reservation name:  " . $name . "
* Restaurant: " . $reservation->table->restaurant->name . "
* Date: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
* Time: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
* Number of people:" . $reservation->people;   
    
$body = $body. "
    
Please note that the entire group must arrive together in order to be seated. Your waiting time is 15 minutes after the scheduled reservation time. After this time, the table will be given to another customer.
     
We kindly request a CASUAL dress code. Admission is at our discretion.
     
The following are not allowed:
    
* SHORTS
* FLIP-FLOPS
* RIPPED JEANS
* MEN'S SHIRT or T-SHIRT without sleeves
     
Please share this information with the other members of your reservation.
    
If you wish, you can always CANCEL your reservation at 


" . $link . " 
    
If you have any inquiries or need to modify the details of your reservation, please contact the restaurant directly. This phone number does not answer calls or messages.
    
Best regards,
    
Reserva Ya! Team
    ";
}

if ( $restaurant->group_type == 'cap_cana') 
{
$link2 = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

$body = $body . "

*GOOD NEWS!* Your reservation has been successfully confirmed! 😊        
            
* Reservation name:  " . $name . "
* Restaurant: " . $reservation->table->restaurant->name . "
* Date: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
* Time: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
* Number of people:" . $reservation->people;   
        
$link = "https://reservaya.com.do/usuario/reservation/formulario/".$reservation->encrypt_id;

$body = $body. "

*IMPORTANT:* If you don't have access to Cap Cana, please use the following link  ".$link."  to complete your information and that of all your companions to generate the QR code for access to Cap Cana. Your information will only be shared with the Cap Cana access control office.

Please note that this reservation is valid for 10 minutes after the scheduled time.

If you wish, you can always CANCEL your reservation at 
" . $link2 . " 

📞 For inquiries, we suggest contacting the restaurant directly.

Thank you for choosing us!

@ReservaYaRD

";

    
}



if ( $restaurant->group_type != 'farah' &&  $restaurant->group_type != 'cap_cana')
{
    $link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;


$body = $body . "
*↓ ENGLISH ↓*";
    
$body = $body . "
    
*GOOD NEWS!* Your reservation has been successfully confirmed! 😊
            
We are pleased to inform you that your reservation at ".$reservation->table->restaurant->name." has been successfully confirmed
            
* Reservation name:  " . $name . "
* Restaurant: " . $reservation->table->restaurant->name . "
* Date: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
* Time: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
* Number of people:" . $reservation->people;   

$body = $body. "
🕒We remind you that the validity of this reservation is 10 minutes after the scheduled time. If you don't arrive with 50% of your guests, the table will be subject to availability.


If you wish, you can always CANCEL your reservation at 
" . $link . " 

📞 For inquiries or modifications to the reservation, feel free to contact the restaurant directly.
   
Thank you for choosing us!
 
@ReservaYaRD
";


}

$params=array(
    'token' => 'ckrwcewisan28bw1',
    'to' => $phone,
    'body' => $body,
    );

                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => http_build_query($params),
                        CURLOPT_HTTPHEADER => array(
                            "content-type: application/x-www-form-urlencoded"
                        ),
                    ));
                    
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    
                    curl_close($curl);
                    
                    if ($err) {
                       //Log::debug("cURL Error #:" . $err);
                    
                    } else {
                     
                        $params=array(
                            'token' => 'ckrwcewisan28bw1',
                            'to' => $phone,
                            'image' => 'https://api.puerta21.club/public/images/logor2.png',
        'caption' => 'https://reservaya.com.do'
                            );
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                              CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                              CURLOPT_RETURNTRANSFER => true,
                              CURLOPT_ENCODING => "",
                              CURLOPT_MAXREDIRS => 10,
                              CURLOPT_TIMEOUT => 30,
                              CURLOPT_SSL_VERIFYHOST => 0,
                              CURLOPT_SSL_VERIFYPEER => 0,
                              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                              CURLOPT_CUSTOMREQUEST => "POST",
                              CURLOPT_POSTFIELDS => http_build_query($params),
                              CURLOPT_HTTPHEADER => array(
                                "content-type: application/x-www-form-urlencoded"
                              ),
                            ));
                            
                            $response = curl_exec($curl);
                            $err = curl_error($curl);
                            
                            curl_close($curl);
                    }  
                }
	                $obj_send_notification = (object) [
                    	'to' => $reservation->client_id,
                    	'reservation_id' => $reservation->id,
                    	'title' => '¡Reserva confirmada!',
                    	'body' => '¡BUENAS NOTICIAS! Su reserva ha sido confirmada exitosamente!',
                    ];
        
                    //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
                    SendNotifications::dispatch($obj_send_notification)->delay(now()->addSeconds(3));

                    Mail::to($data_user->email)->send(new AcceptReservation($data_reservation, $data_user));

             
                
            }
        }
  
        //send ws notification
        if( $reservation->reservations_status_id  == 6){
        $phone = $reservation->client->cell_phone;
        //if phone is not null or ''
        if ($phone != null && $phone !== '') {
            $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
    
    
    
            $body =
"¡Hola,  " . $name . "! 

📌 Esta reserva no está confirmada. En breve, te enviaremos un mensaje para confirmar la disponibilidad de tu reserva:
    ";
            $body = $body . "
     • 🍽️ Restaurante: " . $reservation->table->restaurant->name . "
     • 📅 Fecha: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
     • 🕒 Hora: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
     • 👥 Número de personas: " . $reservation->people;


if($restaurant->group_type == 'ramero_solitario')
{
    $body = $body . "

El Ramero Solitario no acepta reservas de más de 10 personas.";
} 

$body = $body . "

Si lo desea, siempre puede

CANCELAR o MODIFICAR su reserva en el siguiente link: 🔗 

https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

        
$body = $body . "

No es necesario que nos contacte por teléfono o vía WhatsApp, ya que esto duplicaría el trabajo y ralentizaría el proceso de confirmación de reservas.";

 
//📞 Para cualquier consulta adicional, no dudes en contactar al restaurante ";
//"Reservaciones mayores de 25 personas solicitamos un depósito consumible total de $3,000 Pesos."
if($restaurant->group_type == 'farah')
{
    $body = $body . "Reservaciones mayores de 25 personas solicitamos un depósito consumible total de $3,000 Pesos.";
}  
$body = $body . "

Agradecemos su comprensión y quedamos a su disposición para cualquier consulta adicional.

Atentamente,
    
@ReservaYaRD 
";

$body = $body . "
*↓ ENGLISH ↓*";

$body = $body .

"

Hello,  " . $name . "! 

📌  This reservation is not confirmed. We will soon send you a message to confirm the availability of your reservation:
    ";
            $body = $body . "
     • 🍽️ Restaurante: " . $reservation->table->restaurant->name . "
     • 📅 Date:: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
     • 🕒 Time: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
     • 👥 Number of people: " . $reservation->people;


if($restaurant->group_type == 'ramero_solitario')
     {
         $body = $body . "
     
El Ramero Solitario does not accept reservations for more than 10 people. ";
     }   

     $body = $body . "

     If you wish, 
     
     you can always CANCEL OR MODIFY your reservation at 🔗
     
     https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;


     $body = $body . "

There is no need to contact us by phone or via WhatsApp, as this would duplicate work and slow down the reservation confirmation process.";





     $body = $body . "

We appreciate your understanding and remain at your disposal for any additional inquiries.
     
Sincerely,
         
@ReservaYaRD ";

    
            $params = array(
                'token' => 'ckrwcewisan28bw1',
                'to' => $phone,
                'body' => $body,
            );
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => http_build_query($params),
                CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded"
                ),
            ));
    
            $response = curl_exec($curl);
            $err = curl_error($curl);
    
            curl_close($curl);
    
            if ($err) {
                //echo "cURL Error #:" . $err;
            } else {
                
                $params=array(
                    'token' => 'ckrwcewisan28bw1',
                    'to' => $phone,
                    'image' => 'https://api.puerta21.club/public/images/logor2.png',
                     'caption' => 'https://reservaya.com.do'
                    );
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                      CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => "",
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 30,
                      CURLOPT_SSL_VERIFYHOST => 0,
                      CURLOPT_SSL_VERIFYPEER => 0,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => "POST",
                      CURLOPT_POSTFIELDS => http_build_query($params),
                      CURLOPT_HTTPHEADER => array(
                        "content-type: application/x-www-form-urlencoded"
                      ),
                    ));
                    
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    
                    curl_close($curl);
                 
            }
        } 

    }

    $reservation->refresh();
    return $reservation;
    }

    public function updateReservation($reservation_id, $client_id, $table_id, $comments, $people, $reservation_date, $tableNumber)

    {

        // Log::info($tableNumber);

        $reservation = Reservation::where('id', $reservation_id)->update([

            'reservation_date' => date_create($reservation_date),

            'people' => $people,

            'comments' => $comments,

            'client_id' => $client_id,

            'table_id' => $table_id,

            'table_number' => $tableNumber,

        ]);


        // Log::info("Reservation \n" . json_encode($reservation));

        $reservation = Reservation::find($reservation_id);

        if (!($reservation->reservations_status_id == 6)) {
            $reservation->reservations_status_id = 1;
            $reservation->save();
        }

        return $reservation;
    }



    public function countByRestaurantIdbetweenDatesGroupByTableId($restaurantId, $initDate, $lastDate)

    {

        // return DB::table('t_tables')

        //     ->leftjoin('t_reservations', function ($join) use ($initDate, $lastDate) {

        //         $join->on('t_tables.id', '=', 't_reservations.table_id')

        //             ->whereBetween('t_reservations.reservation_date', [$initDate, $lastDate]);

        //     })

        //     ->select(

        //         // 't_tables.encrypt_id',

        //         't_tables.capacity',

        //         DB::raw('(select c_tables_type.name from c_tables_type where c_tables_type.id =t_tables.table_type_id ) as table_name'),

        //         DB::raw('count(t_reservations.id) as reservations')

        //     )

        //     ->where(['t_tables.restaurant_id' => $restaurantId])

        //     ->groupBy('t_tables.id')

        //     ->get();



        return DB::table('t_tables')

            ->leftjoin('t_reservations', function ($join) use ($initDate, $lastDate) {

                $join->on('t_tables.id', '=', 't_reservations.table_id')

                    ->whereBetween('t_reservations.reservation_date', [$initDate, $lastDate]);
            })

            ->join('c_tables_type AS ctt', 't_tables.table_type_id', 'ctt.id')

            ->select(

                't_tables.capacity',

                'ctt.name as table_name',

                't_tables.id as table_id',

                DB::raw('count(t_reservations.id) as reservations')

            )

            ->where(['t_tables.restaurant_id' => $restaurantId])

            ->groupBy('t_tables.id', 't_tables.capacity', 'table_name')

            ->get();
    }



    public function countClientReservationsStatusByRestaurant($restaurantId, $clientId)

    {

        $reservations = $this->model

            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->select('t_reservations.*')

            ->where(['t_tables.restaurant_id' => $restaurantId, 't_reservations.client_id' => $clientId]);



        $query = DB::table('c_reservations_status')

            ->leftJoinSub($reservations, 'clients_reservations', function ($join) {

                $join->on('c_reservations_status.id', 'clients_reservations.reservations_status_id');
            })

            ->select(DB::raw('c_reservations_status.id, c_reservations_status.name, COUNT(clients_reservations.reservations_status_id) as count'))

            ->groupBy('c_reservations_status.id', 'c_reservations_status.name');



        $salida = [];

        foreach ($query->get() as $vaule) {

            $salida[$this->getKeyName($vaule->name)] = $vaule->count;
        }





        return (object)$salida;
    }



    public function getSpentByClientInRestaurant($restaurantId, $clientId)

    {

        return $this->model

            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->select(

                DB::raw('sum(t_reservations.bill) as total '),

                DB::raw('avg(t_reservations.bill) as avg '),

            )

            ->where([

                't_tables.restaurant_id' => $restaurantId,

                't_reservations.client_id' => $clientId,

                't_reservations.reservations_status_id' => 3

            ])

            // ->groupBy('t_reservations.client_id')

            ->first();
    }





    public function getCapacityPerDayByMonth($restaurantId, $year, $month)

    {

        $query = $this->model

            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->where('t_tables.restaurant_id', $restaurantId)

            ->whereMonth('reservation_date', $month)

            ->whereYear('reservation_date', $year)

            ->select(

                'table_id',

                DB::raw('count(t_reservations.id) as num_reservations'),
                //count reservations with status 5 as canceled

                DB::raw("DATE_FORMAT(reservation_date, '%Y-%m-%d') as reservation_day"),

                't_tables.capacity',

                DB::raw('sum(people) as num_people'),
                't_reservations.type',
                't_reservations.reservations_status_id',
                't_reservations.is_automatic',
                't_reservations.seen',
                //seen
                
            )



            // ->groupBy(DB::raw("DATE_FORMAT(reservation_date, '%y-%m-%d')"),'table_id')

            ->groupBy('reservation_day', 'table_id', 'type', 'reservations_status_id')

            ->orderBy('reservation_day');



        return $query->get();
    }



    public function getIncomeByMonthWithTotal($restaurantId, $year, $month)

    {



        $query = $this->model

            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->where(['t_tables.restaurant_id' => $restaurantId])

            //->whereIn('t_reservations.reservations_status_id', [2, 3])

            ->select(

                'bill',

                'people'

            );



        $total = $query->sum('bill');

        $total_people = (int)$query->sum('people');



        $query->whereMonth('reservation_date', $month)

            ->whereYear('reservation_date', $year);



        return [

            'total' => $total,

            'total_people' => $total_people,

            'total_month' => $query->sum('bill'),

            'total_people_month' => (int)$query->sum('people'),

        ];
    }



    private function queryAllWithClientAndStatusAndTable()

    {

        return $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->join('c_tables_type', 'c_tables_type.id', '=', 't_tables.table_type_id')

            ->join('c_reservations_status', 'c_reservations_status.id', '=', 't_reservations.reservations_status_id')

            ->join('t_clients', 't_clients.id', '=', 't_reservations.client_id')

            ->join('c_client_status', 'c_client_status.id', '=', 't_clients.client_status_id')

            ->join('users', 't_clients.user_id', '=', 'users.id')

            ->select(

                't_reservations.*',

                'c_reservations_status.name as status',

                'c_reservations_status.encrypt_id as status_id',

                'c_tables_type.name as table_name',

                't_clients.first_name',

                't_clients.middle_name',

                't_clients.last_name',

                't_clients.cell_phone',
                't_clients.birthday_date',
                'c_client_status.name as client_status',

                'users.email',

                't_clients.encrypt_id as linkid',
                'users.photo',

                DB::raw('concat(t_clients.first_name," ",t_clients.middle_name," ",t_clients.last_name) as client_name'),

                // DB::raw('(select t_category_client_restaurant.category_id from t_category_client_restaurant where t_category_client_restaurant.restaurant_id = t_tables.restaurant_id and t_category_client_restaurant.client_id = t_clients.id  ) as category_id'),

            );
    }



    private function queryAllWithClientAndStatusAndTableByName($search)

    {

        return $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->join('c_tables_type', 'c_tables_type.id', '=', 't_tables.table_type_id')

            ->join('c_reservations_status', 'c_reservations_status.id', '=', 't_reservations.reservations_status_id')

            ->join('t_clients', 't_clients.id', '=', 't_reservations.client_id')

            ->join('c_client_status', 'c_client_status.id', '=', 't_clients.client_status_id')

            ->join('users', 't_clients.user_id', '=', 'users.id')

            ->Where(function ($query) use ($search) {

                $query

                    ->orwhere('t_clients.last_name', 'like', '%' . $search . '%')

                    ->orwhere('t_clients.middle_name', 'like', '%' . $search . '%')

                    ->orwhere('t_clients.first_name', 'like', '%' . $search . '%');
            })

            ->select(

                't_reservations.*',

                'c_reservations_status.name as status',

                'c_reservations_status.encrypt_id as status_id',

                'c_tables_type.name as table_name',

                't_clients.first_name',

                't_clients.middle_name',

                't_clients.last_name',

                't_clients.cell_phone',
                't_clients.birthday_date',

                'c_client_status.name as client_status',

                'users.email',
                'users.photo',
                't_clients.encrypt_id as linkid',

                DB::raw('concat(t_clients.first_name," ",t_clients.middle_name," ",t_clients.last_name) as client_name'),

                // DB::raw('(select t_category_client_restaurant.category_id from t_category_client_restaurant where t_category_client_restaurant.restaurant_id = t_tables.restaurant_id and t_category_client_restaurant.client_id = t_clients.id  ) as category_id'),

            );
    }



    public function clientReservationListFounders($request, $type, $client_id, $page_size)

    {

        if ($type == 'search') {

            $search = '%' . $request->name . '%';



            $clients = $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                ->join('t_restaurants', 't_tables.restaurant_id', '=', 't_restaurants.id')

                ->Where(function ($query) use ($search) {

                    $query->orwhere('t_restaurants.name', 'like', $search);
                })

                ->select('t_reservations.reservation_date', 't_reservations.people', 't_reservations.bill', 't_restaurants.name')

                ->where('t_reservations.client_id', $client_id)

                ->paginate($page_size);
        } else {

            $clients = $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                ->join('t_restaurants', 't_tables.restaurant_id', '=', 't_restaurants.id')

                ->select('t_reservations.reservation_date', 't_reservations.people', 't_reservations.bill', 't_restaurants.name')

                ->where('t_reservations.client_id', $client_id)

                ->paginate($page_size);
        }



        return $clients;
    }



    public function queryfindByRestaurantIdWithClientByMonthForFounders($restaurant_id, $month, $year, $page_size, $order_by, $search)

    {

        if ($search) {

            $query = $this->queryAllWithClientAndTableByName($search)

                ->where(['t_tables.restaurant_id' => $restaurant_id])

                ->whereMonth('t_reservations.reservation_date', $month)

                ->whereYear('t_reservations.reservation_date', $year);
        } else {



            $query = $this->queryAllWithClientAndTableByName('')

                ->where(['t_tables.restaurant_id' => $restaurant_id])

                ->whereMonth('t_reservations.reservation_date', $month)

                ->whereYear('t_reservations.reservation_date', $year);
        }

        if ($order_by) {

            $query->orderBy($order_by[0], $order_by[1]);
        }



        $reservations = $query->paginate($page_size);



        return $reservations;
    }



    public function queryfindByRestaurantIdWithClientByMonthForFoundersReport($restaurant_id, $month, $year)

    {

        $query = $this->queryAllWithClientAndTableByName('')

            ->where(['t_tables.restaurant_id' => $restaurant_id])

            ->whereMonth('t_reservations.reservation_date', $month)

            ->whereYear('t_reservations.reservation_date', $year);



        $reservations = $query->get();



        return $reservations;
    }



    private function queryAllWithClientAndTableByName($search)

    {

        $query = $this->model->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->join('c_tables_type', 'c_tables_type.id', '=', 't_tables.table_type_id')

            ->join('c_reservations_status', 'c_reservations_status.id', '=', 't_reservations.reservations_status_id')

            ->join('t_clients', 't_clients.id', '=', 't_reservations.client_id');

        if ($search) {

            $query->Where(function ($query) use ($search) {

                $query

                    ->orwhere('t_clients.last_name', 'like', '%' . $search . '%')

                    ->orwhere('t_clients.middle_name', 'like', '%' . $search . '%')

                    ->orwhere('t_clients.first_name', 'like', '%' . $search . '%');
            });
        }

        $query->select(

            't_reservations.bill',
            't_reservations.people',
            't_reservations.reservation_date',
            't_clients.first_name',
            't_clients.middle_name',
            't_clients.last_name',
            't_clients.id as client_id'

        );



        return $query;
    }



}