<?php



namespace App\Repositories\Eloquent;



use App\Models\{User, Client, Publication, ReportPublication};

use App\Repositories\ClientRepositoryInterface;

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Log;

use App\Traits\AuxiliarFunctions;



class ClientRepository extends BaseRepository implements ClientRepositoryInterface

{

    use AuxiliarFunctions;

    /**

     * ClientRepository constructor.

     */

    public function __construct(Client $client)

    {

        parent::__construct($client);

    }



    public function createWithEncryptId(array $request, int $userId, int $statusClient = 3)

    {

        // $lastNames = explode(" ",$request['last_name']);

        $client = $this->model::create([

            'user_id' => $userId,

            'client_status_id' => $statusClient,

        ]);

        $client->encrypt_id = encrypt($client->id);

        $client->save();



        return $client;

    }



    public function createSocialMedia(array $data, int $client_id)

    {

        foreach ($data as $value) {

            $ok = DB::table('t_social_medias')->updateOrInsert(

                [

                'client_id' => $client_id,

                'social_media_id' => $value['social_media_id'],

                ],

                [

                'url' => $value['url'],

                ]

            );

        }

        return $data;

    }



    public function findByUserId(int $idUser)

    {

        return $this->model

            ->where('user_id', $idUser)

            ->get()

            ->first();

    }



    public function getRestaurantClients(int $restaurantId)

    {

        return $this->auxiliarRestaurantClients($restaurantId)->get();

    }



    public function getRestaurantClientsByClientStatus(int $restaurantId, array $clientStatusId, string $search)

    {

        return $this->auxiliarRestaurantClients($restaurantId)

            ->whereIn('client_status_id', $clientStatusId)

            ->addSelect(

                DB::raw('(select count(id) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as visits'),

                DB::raw('(select sum(bill) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as total_spend')

            )

            ->get();

    }



    public function getRestaurantClientsByClientStatusPaginated(int $restaurantId, array $clientStatusId, string $pageSize, array $order)

    {

        $query =  $this->auxiliarRestaurantClients($restaurantId)

            ->whereIn('client_status_id', $clientStatusId)
            ->addSelect(

                DB::raw('(select count(id) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as visits'),

                DB::raw('(select sum(bill) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as total_spend')

            );

            if (!empty($orderBy)) {

                foreach ($orderBy as $value) {

                    $query->orderBy($this->getColumnTable($value[0]), $value[1]);

                }

            }

    

            Log::debug($query->toSql());

            return $query->paginate($pageSize);

    }



    private function getColumnTable($generalColumn)

    {

        $TableColumns = [

            'nombre' => 'first_name',

        ];

        return $TableColumns[$generalColumn];

    }



    public function searchRestaurantClientsByClientStatusPaginated(int $restaurantId, array $clientStatusId, string $search, int $pageSize)

    {

        $clients = $this->auxiliarRestaurantClients($restaurantId);



        if ('' !== $search) {

            $clients->Where(function ($query) use ($search) {

                $query

                    ->orwhere('last_name', 'like', '%' . $search . '%')

                    ->orwhere('middle_name', 'like', '%' . $search . '%')

                    ->orwhere('first_name', 'like', '%' . $search . '%');

            });

        }



        return $clients->whereIn('client_status_id', $clientStatusId)

            ->addSelect(

                DB::raw('(select count(id) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as visits'),

                DB::raw('(select sum(bill) from t_reservations where t_reservations.client_id = t_clients.id and reservations_status_id in (2,3) ) as total_spend')

            )

            ->simplePaginate($pageSize);

    }



    public function getRestaurantClientsByEmailClient(int $restaurantId, string $email)

    {

        $querybuild = $this->auxiliarRestaurantClients($restaurantId);



        if ($email) {

            $search[] = ['email', 'like', '%' . $email . '%'];

            $querybuild = $querybuild->where($search);

        }



        return $querybuild->simplePaginate(5);

    }



    public function createRestaurantClient(string $email, string $firstName, string $middleName, $lastName, string $phone)

    {

        $user = User::create(

            [

                'name' => explode('@', $email)[0],

                'email' => strtolower($email),

                'email_hash' => md5(strtolower($email)),

                'role_id' => 2,

                'active' => 1,

                'created_at' => now(),

            ],

        );

        $user->encrypt_id = encrypt($user->id);

        $user->save();



        $client = $this->model->create(

            [

                'first_name' => $firstName,

                'middle_name' => $middleName,

                'last_name' => $lastName,

                'cell_phone' => $phone,

                'user_id' => $user->id,

                'client_status_id' => 5,

                'created_at' => now(),

            ],

        );

        $client->encrypt_id = encrypt($client->id);

        $client->save();



        return $client;

    }


    public function findByUserEmailorPhone($email,$phone){

        return $this->model

        ->join('users', 'users.id', 't_clients.user_id')

        ->where('users.email', $email)

        ->orWhere('t_clients.cell_phone', $phone)

        ->select(

            't_clients.*',

            'users.email as email'

            )

        ->first();

    }
    public function findByUserEmail($email)

    {

        return $this->model

            ->join('users', 'users.id', 't_clients.user_id')

            ->where('users.email', $email)
            ->select(

                't_clients.*',

                'users.email as email'

                )

            ->first();

    }
    public function findByUserPhone($phone)

    {

        return $this->model

            ->join('users', 'users.id', 't_clients.user_id')

            ->where('t_clients.cell_phone', $phone)
            ->select(

                't_clients.*',

                'users.email as email'

                )

            ->first();

    }


    public function getCategoryNameByIdAndRestaurantId(int $id, int $restaurantId)

    {

        return $this->model

            ->join('t_category_client_restaurant', 't_category_client_restaurant.client_id', '=', 't_clients.id')

            ->join('c_categories', 'c_categories.id', '=', 't_category_client_restaurant.category_id')

            ->where(['t_clients.id' => $id, 't_category_client_restaurant.restaurant_id' => $restaurantId])

            ->select('c_categories.encrypt_id','c_categories.name', 't_category_client_restaurant.status')

            ->get();

            /*->map(function($value){

                return $value->name;

            });*/

    }



    public function findByIdWithUser($id)

    {

        $client = $this->model->with('user')->where('id', $id)->first();

        if (!$client) {

            return null;

        }





        return $client;

    }



    private function auxiliarRestaurantClients(int $restaurantId)

    {

        return $this->model

            ->join('users', 'users.id', 'user_id')

            ->whereIn('t_clients.id', function ($query) use ($restaurantId) {

                $query->from('t_reservations')

                    ->join('t_tables', 't_tables.id', 't_reservations.table_id')

                    ->where(['t_tables.restaurant_id' => $restaurantId])

                   // ->whereIn('t_reservations.reservations_status_id', [2, 3, 4, 5])

                    ->select('t_reservations.client_id')

                    ->distinct()

                    ->get();

            })

            ->select(

                't_clients.*',

                'users.email',

                'users.role_id',

                'users.photo',

                't_clients.id as client_id'

            );

    }



    public function getName($client)

    {

        $name = $client->first_name." ".$client->middle_name. " ".$client->last_name;



        if($client->privacy){

            $name = $client->privacy->name_by_pseudonym ? $client->privacy->pseudonym : $name;

        }



        return $name;

    }



    public function getClientList($request, $type, $client)

    {



        if($type == 'search'){

            $search = '%'.$request->name.'%';



            $clients = $this->model->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                ->Where(function ($query) use ($search) {

                    $query

                    ->orwhere('t_clients.first_name', 'like', $search )

                    ->orwhere('t_clients.middle_name', 'like', $search )

                    ->orwhere('t_clients.last_name', 'like', $search)

                    ->orwhere('t_privacies.pseudonym', 'like', $search);

                })

                ->select('t_clients.id as client_id')

                ->where('t_clients.id','!=', $client->id)

                ->whereIn('t_clients.client_status_id',[1,2])

                ->paginate(12);

        }

        else {



            $clients = $this->model->select('t_clients.id as client_id')

                                ->where('t_clients.id','!=', $client->id)

                                ->whereIn('t_clients.client_status_id',[1,2])

                                ->paginate(12);

        }



        return $clients;

    }



    public function getProfilePublic($client, $status)

    {

        $validator = true;



        if($client->privacy){

            $validator = $client->privacy->followed_followers;

        }

        $validator = $status ? $status : $validator;



        $following = null;



    

        $user = auth()->user();



        $following = DB::table('t_follows')->where(['following_id' => $client->id, 'follower_id' => $user->client->id, 'status' => 1])->first();

        

        $data = (object)[

            "name"          => $this->getName($client),

            "description"   => $client->description,

            "photo"         => $this->getImageUrl($client->user->photo),

            "favorites"     => $client->favorites()->where('t_favorite_restaurants.status', 1)->get()->count(),

            "followers"     => $validator ? $client->followers()->where('t_follows.status', 1)->get()->count() : null,

            "followings"    => $validator ? $client->followings()->where('t_follows.status', 1)->get()->count() : null,

            // "publications"  => $client->publications,

            "following"     => $following ? 1 : 0,

        ];



        return $data;

    }



    public function getProfilePublicFollowings($request, $client)

    {

       $clients =  $client->followings()->where('t_follows.status', 1)->paginate(12);



        foreach ($clients as $key => $c) {



            $user = auth()->user();



            $following = DB::table('t_follows')->where('following_id', $c->id)->where('follower_id', $user->client->id)->where('status', 1)->first();



            $data = (object)[

                'encrypt_id'    => $c->encrypt_id,

                'name'          => $this->getName($c),

                'description'   => $c->description,

                'following'     => $following ? 1 : 0,

                'photo'         => $this->getImageUrl($c->user->photo),

            ];

            $clients[$key] = $data;

        }



        return $clients;

    }



    public function getProfilePublicFollowers($request, $client)

    {

       $clients =  $client->followers()->where('t_follows.status', 1)->paginate(12);



        foreach ($clients as $key => $client) {



            $user = auth()->user();



            $following = DB::table('t_follows')->where('following_id', $client->id)->where('follower_id', $user->client->id)->where('status', 1)->first();



            $data = (object)[

                'encrypt_id'    => $client->encrypt_id,

                'name'          => $this->getName($client),

                'description'   => $client->description,

                'following'     => $following ? 1 : 0,

                'photo'         => $this->getImageUrl($client->user->photo),

            ];

            $clients[$key] = $data;

        }



        return $clients;

    }



    public function getProfilePublicPublications($request, $client)

    {

        $publications = Publication::where('client_id', $client->id)->where('publication_type_id', 1)->orderBy('publication_date',"desc")->paginate(12);

        

        return $publications;

    }



    public function getClientStories($client_id)

    {

        $reports = ReportPublication::where('client_id', $client_id)

                                        ->where('report_status', 1)

                                        ->pluck('publication_id')

                                        ->toarray();

        // TODO : orderBy

        return $this->model

                ->rightJoin('t_publications', function ($join) use ($client_id, $reports) {

                    $join->on('t_publications.client_id', '=','t_clients.id')

                            ->orderBy('t_publications.publication_date','desc')

                            ->where('t_publications.client_id', '!=', $client_id)

                            ->where('t_publications.publication_type_id', 2)

                            ->where('t_publications.status', 1)

                            ->whereNotIn('t_publications.id', $reports)

                            ->whereNull('t_publications.deleted_at');

                })

                ->join('t_follows', 't_follows.following_id', 't_clients.id')

                ->where(['t_follows.follower_id' => $client_id, 't_follows.status' => 1])

                ->select('t_publications.client_id')

                ->distinct()

                ->paginate(12);

        

        // return $this->model

        //             ->join('t_publications', 't_publications.client_id', 't_clients.id')

        //             ->join('t_follows', 't_follows.following_id', 't_clients.id')

        //             ->where('t_publications.publication_type_id', 2)

        //             ->where('t_publications.status', 1)

        //             ->where('t_publications.client_id', '!=', $client_id)

        //             ->where('t_follows.follower_id',$client_id)

        //             ->select('t_publications.client_id','t_publications.publication_date')

        //             ->orderBy('t_publications.publication_date',"desc")

        //             ->distinct()

        //             ->paginate(12);

    }



    public function getStories($client_id, $client)

    {

        $reports = ReportPublication::where(['client_id' => $client->id, 'report_status' => 1])

                                        ->pluck('publication_id')

                                        ->toarray();

                                        

        $stories = Publication::where('publication_type_id', 2)->where('status', 1)

                                ->where('client_id', $client_id)

                                ->whereNotIn('id', $reports)

                                ->orderBy('publication_date',"asc")

                                ->paginate(12);

        

        return $stories;

    }



    public function storePublication($request, $user, $publication_type_id)

    {

        $date = date('Y-m-d H:i');

        $env  = config('app.env');

        $path = $env.'/users/'.$user->encrypt_id.'/publications';



        $path = $this->storeImage($request->file()['image'], null, $path);



        $publication = Publication::create([

                'photo'                 => $path,

                'publication_date'      => $date,

                'status'                => 1,

                'publication_type_id'   => $publication_type_id,

                'client_id'             => $user->client->id,

                'created_at'            => $date,

        ]);



        $publication->encrypt_id = encrypt($publication->id);

        $publication->save();



        $data = (object)[

            "encrypt_id"    => $publication->encrypt_id,

            "photo"         => $this->getImageUrl($path),

            "type"          => $publication->publication_type->name,

        ];



        return $data;

    }



    public function listClientsFounders($request, $type, $client_status_id, $page_size, $order_by)

    {

        if($type == 'search') {

            $search = '%'.$request->name.'%';



            $query = $this->model->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                ->Where(function ($query) use ($search) {

                    $query

                    ->orwhere('t_clients.first_name', 'like', $search )

                    ->orwhere('t_clients.middle_name', 'like', $search )

                    ->orwhere('t_clients.last_name', 'like', $search)

                    ->orwhere('t_privacies.pseudonym', 'like', $search);

                })

                ->select('t_clients.id as client_id')

                ->whereIn('t_clients.client_status_id',$client_status_id);

            if($order_by){

                $query->orderBy($order_by[0],$order_by[1]);

            }

            $clients = $query->paginate($page_size);

        }

        else {



            $query = $this->model->select('t_clients.id as client_id')

                                ->whereIn('t_clients.client_status_id',$client_status_id);

                                

            if($order_by){

                $query->orderBy($order_by[0],$order_by[1]);

            }

            $clients = $query->paginate($page_size);

        }



        return $clients;

    }



    public function clientsListReport($request, $type, $client_status_id)

    {

        if($type == 'search') {

            $search = '%'.$request->name.'%';



            $clients = $this->model->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                ->Where(function ($query) use ($search) {

                    $query

                    ->orwhere('t_clients.first_name', 'like', $search )

                    ->orwhere('t_clients.middle_name', 'like', $search )

                    ->orwhere('t_clients.last_name', 'like', $search)

                    ->orwhere('t_privacies.pseudonym', 'like', $search);

                })

                ->select('t_clients.id as client_id')

                ->whereIn('t_clients.client_status_id',$client_status_id)

                ->get();

        }

        else {

            $clients = $this->model->select('t_clients.id as client_id')

                                ->whereIn('t_clients.client_status_id',$client_status_id)

                                ->get();

        }



        return $clients;

    }



    public function getListMessagingClient($request, $type, $client)

    {



        if($type == 'search'){

            $search = '%'.$request->name.'%';



            $union = $this->model->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                                    ->Where(function ($query) use ($search) {

                                        $query

                                        ->orwhere('t_clients.first_name', 'like', $search )

                                        ->orwhere('t_clients.middle_name', 'like', $search )

                                        ->orwhere('t_clients.last_name', 'like', $search)

                                        ->orwhere('t_privacies.pseudonym', 'like', $search);

                                    })

                                    ->join('t_messages', 't_clients.id', 't_messages.sender_id')

                                    ->select('t_clients.id as client_id', 't_messages.encrypt_id as chat_eid')

                                    ->where('t_messages.receiver_id', $client->id)

                                    ->where('t_clients.id','!=', $client->id)

                                    ->whereIn('t_clients.client_status_id',[1,2]);



            $clients = $this->model->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                                    ->Where(function ($query) use ($search) {

                                        $query

                                        ->orwhere('t_clients.first_name', 'like', $search )

                                        ->orwhere('t_clients.middle_name', 'like', $search )

                                        ->orwhere('t_clients.last_name', 'like', $search)

                                        ->orwhere('t_privacies.pseudonym', 'like', $search);

                                    })

                                    ->join('t_messages', 't_clients.id', 't_messages.receiver_id')

                                    ->select('t_clients.id as client_id', 't_messages.encrypt_id as chat_eid')

                                    ->where('t_messages.sender_id',$client->id)

                                    ->where('t_clients.id','!=', $client->id)

                                    ->whereIn('t_clients.client_status_id',[1,2])

                                    ->union($union)

                                    ->paginate(12);

        }

        else {

            $union = $this->model->join('t_messages', 't_clients.id', 't_messages.sender_id')

                                ->select('t_clients.id as client_id', 't_messages.encrypt_id as chat_eid')

                                ->where('t_messages.receiver_id',$client->id)

                                ->where('t_clients.id','!=', $client->id)

                                ->whereIn('t_clients.client_status_id',[1,2]);



            $clients = $this->model->join('t_messages', 't_clients.id', 't_messages.receiver_id')

                                ->select('t_clients.id as client_id', 't_messages.encrypt_id as chat_eid')

                                ->where('t_messages.sender_id',$client->id)

                                ->where('t_clients.id','!=', $client->id)

                                ->whereIn('t_clients.client_status_id',[1,2])

                                ->union($union)

                                ->paginate(12);

        }



        return $clients;

    }



    public function getListReportedPublications($request, $type, $page_size)

    {

        // $report_publication = ReportPublication::where(['report_status' => 1])

        //                                 ->pluck('publication_id')

        //                                 ->toarray();

        $report_publication = ReportPublication::pluck('publication_id')

                                        ->toarray();

        if($type == 'search') {

            $search = '%'.$request->name.'%';



            $query = Publication::join('t_clients', 't_publications.client_id', '=', 't_clients.id')

                ->leftJoin('t_privacies', 't_clients.id', '=', 't_privacies.client_id')

                ->Where(function ($query) use ($search) {

                    $query

                    ->orwhere('t_clients.first_name', 'like', $search )

                    ->orwhere('t_clients.middle_name', 'like', $search )

                    ->orwhere('t_clients.last_name', 'like', $search)

                    ->orwhere('t_privacies.pseudonym', 'like', $search);

                })

                ->select('t_publications.id as publication_id')

                ->whereIn('t_publications.id',$report_publication);

            $reports = $query->paginate($page_size);

        }

        else {

            $reports = Publication::whereIn('id', $report_publication)->select('t_publications.id as publication_id')->paginate($page_size);

        }



        return $reports;

    }

}

