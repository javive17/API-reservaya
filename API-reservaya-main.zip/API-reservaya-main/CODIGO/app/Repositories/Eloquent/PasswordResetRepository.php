<?php

namespace App\Repositories\Eloquent;

use App\Repositories\PasswordResetRepositoryInterface;
use Illuminate\Support\Facades\DB;

class PasswordResetRepository implements PasswordResetRepositoryInterface
{

    public function createOrUpdateUserResetToken(string $email, string $resetToken)
    {
        $password_resets = DB::table('password_resets')->select('token')->where('email', '=', $email)->first();

        $now = new \DateTime;

        if (!$password_resets) {
            //insert new random user password reset token
            DB::table('password_resets')->insert(['email' => $email, 'token' => $resetToken, 'created_at' => $now]);
        } else {
            //update existing reset token for user
            DB::table('password_resets')->where('email', $email)->update(['token' => $resetToken, 'created_at' => $now]);
        }
    }

    public function checkUserResetTokenIsValid(string $resetToken){
        // $reset_token = DB::table('password_resets')->where('token', $resetToken)->first();
        return DB::table('password_resets')->where('token', $resetToken)->value('email');

    }


    public function deleteResetToken(string $resetToken){
        return DB::table('password_resets')->where('token',$resetToken)->delete();
    }


}
