<?php

namespace App\Repositories\Eloquent;

use App\Repositories\RatingRepositoryInterface;
use App\Models\Rating;
use App\Models\Reservation;
use Illuminate\Support\Facades\Log;

class RatingRepository  extends BaseRepository implements RatingRepositoryInterface
{

    /**
     * Reservationrepositori constructor.
     */
    public function __construct(Rating $rating)
    {
        parent::__construct($rating);
    }

    public function getByRestaurantId($restaurantId)
    {
        return $this->queryRatingByRestaurantId($restaurantId)
            ->get();
    }

    public function getByRestaurantIdPaginatedOrderedBy($restaurantId, $pageSize, $orderBy)
    {

        $query = $this->queryRatingByRestaurantId($restaurantId);

        if (!empty($orderBy)) {
            foreach ($orderBy as $value) {
                $query->orderBy($value[0], $value[1]);
            }
        }

        Log::debug($query->toSql());
        return $query->paginate($pageSize);
    }

    public function updateRestaurantReply($ratingId, $reply)
    {
        return $this->update(['reply' => $reply], $ratingId);
    }


    private function queryRatingByRestaurantId($restaurantId)
    {
        return $this->model
            ->join('t_reservations', 't_reservations.id', '=', 't_ratings.reservation_id')
            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
            ->select(
                't_ratings.*',
                't_reservations.reservation_date',
                't_reservations.people'
            )
            ->where(['t_tables.restaurant_id' => $restaurantId]);
    }
}
