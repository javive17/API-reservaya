<?php
namespace App\Repositories\Eloquent;
use App\Repositories\RestaurantPhotoRepositoryInterface;
use App\Models\RestaurantPhoto;

class RestaurantPhotoRepository extends BaseRepository implements RestaurantPhotoRepositoryInterface{



    /**
     * RestaurantRepository constructor.
     *
     * @param RestaurantPhoto $model
     */
    public function __construct(RestaurantPhoto $model)
    {
        parent::__construct($model);
    }

    public function store($restaurantId, $image){
        $lastphotos = RestaurantPhoto::where('restaurant_id',$restaurantId)->latest('order_photos');
        $nextOrder = 1;
        if($lastphotos->count()>0){
            $nextOrder = $lastphotos->value('order_photos')+1;
        }
        $photo = new RestaurantPhoto([
            'url' =>$image,
            'order_photos' =>$nextOrder,
            'restaurant_id'=> $restaurantId
        ]);

        $photo->save();
        $photo->encrypt_id = encrypt($photo->id);
        return $photo->save();
    }
}
