<?php

namespace App\Repositories\Eloquent;

use App\Models\PreferenceClientRestaurant;
use Illuminate\Support\Facades\Log;
use App\Repositories\ClientRestaurantPreferenceRepositoryInterface;

class ClientRestaurantPreferenceRepository
extends BaseRepository
implements ClientRestaurantPreferenceRepositoryInterface
{


    /**
     * ClientRepository constructor.
     */
    public function __construct(PreferenceClientRestaurant $preferenceClientRestaurant)
    {
        parent::__construct($preferenceClientRestaurant);
    }

    public function findByRestaurantIdAndClientId($restaurantId, $clientId)
    {
        return $this->model->where(['restaurant_id' => $restaurantId, 'client_id' => $clientId])->first();
    }

    public function updatePreference($restaurantId, $clientId, $data)
    {

        $preference = $this->findByRestaurantIdAndClientId($restaurantId, $clientId);
        if(!$preference){
            $preference = $this->createDefault($restaurantId, $clientId);
        }
        return $this->model
            ->where(['restaurant_id' => $restaurantId, 'client_id' => $clientId])
            ->update($data);
    }

    public function createDefault($restaurantId, $clientId)
    {

        $data = [
            'rating' => 5,
            'friend' => 'none',
            'drink' => 'none',
            'food' => 'none',
            'table' => 'none',
            'extra_comments' => 'none',
            'client_id' => $clientId,
            'restaurant_id' => $restaurantId
        ];

        $preference = $this->create($data);

        $preference->encrypt_id = encrypt($preference->id);
        $preference->save();

        return $preference;
    }
}
