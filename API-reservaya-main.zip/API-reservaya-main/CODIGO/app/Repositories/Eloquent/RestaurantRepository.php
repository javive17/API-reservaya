<?php



namespace App\Repositories\Eloquent;



use App\Repositories\RestaurantRepositoryInterface;

use App\Models\{Restaurant, Table, RestaurantPhoto, RestaurantServiceDay, Address, User, Reservation, Offer};

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Log;

use App\Traits\{AuxiliarFunctions, Notification};





class RestaurantRepository  extends BaseRepository implements RestaurantRepositoryInterface

{

    use AuxiliarFunctions, Notification;



    /**

     * RestaurantRepository constructor.

     *

     * @param Restaurant $model

     */

    public function __construct(Restaurant $model)

    {

        parent::__construct($model);

    }



    public function address($id)

    {

        return $this->find($id)->address;

    }

    public function photos($id)

    {

        return $this->find($id)->photos;

    }

    public function capacity($id)

    {

        return $this->find($id)->tables;

    }



    public function createRestaurant($name, $owner_name, $zone_id, $cost_id, $address_id, $email)

    {
        $restaurant = $this->model::create([

            'name'          => $name,

            'owner_name'    => $owner_name,

            'email'         => strtolower($email),

            'status'        => false,

            'cost_id'       => $cost_id,

            'country_id'    => 1, // TODO

            'zone_id'       => $zone_id,

            'address_id'    => $address_id,

        ]);
        $restaurant->encrypt_id = encrypt($restaurant->id);
        $restaurant->save();
        return $restaurant;

    }



    public function showRestaurant($restaurant)

    {

        $address = $restaurant->address;

        $photos = $restaurant->photos->map(function ($photo) {

            return [

                'id' => $photo->encrypt_id,

                'photo' => $this->getImageUrl($photo->url),

                'order' => $photo->order_photos,

            ];

        });

        $tables = $restaurant->tables->map(function ($table) {

            $type = $table->type;
            return [

                'id' => $table->encrypt_id,

                'capacity' => $table->capacity,

                'type' => ['id ' => $type->encrypt_id, 'name' => $type->name],

            ];

        });

        $schedule = $restaurant->serviceDays->map(function ($serviceDay) {

            $day = $serviceDay->day;
            return [

                'id'        => $serviceDay->encrypt_id,

                'opening'   => $serviceDay->opening,

                'closing'   => $serviceDay->closing,
                'break_start'   => $serviceDay->break_start,
                'break_end'   => $serviceDay->break_end,  

                'status'    => $serviceDay->status,

                'day'       => ['id' => $day->encrypt_id, 'name' => $day->name],

            ];

        });



        $description = [

            'description'   => $restaurant->description,

            'phone'         => $restaurant->phone,

            'cheff_name'    => $restaurant->cheff_name,
            'paymentMethod'    => $restaurant->payment_method,
        ];



        $cost = [

            'id'    => $restaurant->cost->encrypt_id,

            'name'  => $restaurant->cost->name,

        ];



        $extraServices = $restaurant->extraServices->map(function ($extraServices) {

            return [

                'id'        => $extraServices->encrypt_id,

                'name'      => $extraServices->name,

                'status'    => $extraServices->pivot->status,

            ];

        });



        // $kitchens = $restaurant->kitchens->map(function ($kitchen) {

        //     return [

        //         'id'    => $kitchen->encrypt_id,

        //         'name'  => $kitchen->name,

        //         'status'    => $kitchen->pivot->status,

        //     ];

        // });



        $kitchens = [];

        foreach($restaurant->kitchens as $kitchen){

            if($kitchen->pivot->status){

                $k = (object)[

                    'encrypt_id'    => $kitchen->encrypt_id,

                    'name'          => $kitchen->name,

                    'status'        => $kitchen->pivot->status,

                ];

                array_push($kitchens, $k);

            }

        }
        //db query c_sectors
        $sectors = DB::table('c_sector')->get();
        
        $offers = Offer::where('restaurant_id', $restaurant->id)->get();




        $salida = [

            'id' => $restaurant->encrypt_id,
        'sectors' => $sectors,
        

        'sector_id' => $restaurant->sector_id,
        'has_offer' => $restaurant->offers,
        'offers' => $offers,
            'name' => $restaurant->name,

            'description' => $description,

            'menu' => $restaurant->menu_url,
            'special_menu' => $restaurant->menu_especial_url,
            'link' => $restaurant->link_url,
            

            'address' => [

                'id' => $address->encrypt_id,

                'latitude' => $address->latitude,

                'longitude' => $address->longitude,

                'address' => $address->address,

            ],

            'cost' => $cost,

            'kitchens' => $kitchens,

            'extra_services' => $extraServices,

            'photos' => $photos,

            'capacity' => $tables,

            'schedule' => $schedule,
            
            'cover' => $restaurant->cover,
            'automatic_reservations' => $restaurant->automatic_reservations,
            'accept_automatic_reservation' => $restaurant->accept_automatic_reservation,

        ];

        return $salida;

    }



    public function createUpdateKitchens($restaurant_id, $data, $status)

    {

        foreach ($data as $value) {

            DB::table('t_restaurants_kitchens')->updateOrInsert([ 'restaurant_id' => $restaurant_id, 'kitchen_id' => $value ], ['status' => $status]);

        }

    }



    public function createUpdateExtraServices($restaurant_id, $data, $status)

    {

        foreach ($data as $value) {

            DB::table('t_restaurants_extra_services')->updateOrInsert([ 'restaurant_id' => $restaurant_id, 'extra_service_id' => $value ], ['status' => $status]);

        }

    }

    public function createUpdateServiceDay($restaurant_id, $data)

    {

        foreach ($data['service_days'] as  $value) {

            DB::table('t_restaurant_service_days')->updateOrInsert([ 'restaurant_id' => $restaurant_id, 'day_id' => $value['day_id'] ],

                ['status' => $value['status'],'opening' => $value['opening'], 'closing' => $value['closing'], 'break_start' => $value['breakStart'], 'break_end' => $value['breakEnd']]

            );

        }

    }



    public function createUpdateCapacity($restaurant_id, $data, $ids)

    {

        foreach ($data as $value) {

            $table = DB::table('t_tables')->updateOrInsert(

                    [ 'restaurant_id' => $restaurant_id, 'table_type_id' => $value['table_type_id'] ],

                    [ 'capacity' => $value['capacity'] ]

                );

            if ($table) {

                $id = DB::table('t_tables')

                    ->where([

                        'restaurant_id' => $restaurant_id,

                        'table_type_id' => $value['table_type_id'],

    

                    ])->value('id');

                $encrypt_id = encrypt($id);

                DB::table('t_tables')->where('id', $id)->update(['encrypt_id' => $encrypt_id]);

            }

        }



        DB::table('t_tables')->whereNotIn('table_type_id', $ids)

            ->where(['restaurant_id' => $restaurant_id])

            ->update(['capacity' => 0, 'updated_at' => now()->toDateTimeString()]);

    }



    public function createAddress($address, $latitude, $longitude)

    {

        $new_address = Address::create([

            'address'   => $address,

            'latitude'  => $latitude,

            'longitude' => $longitude,

        ]);

        $new_address->encrypt_id = encrypt($new_address->id);

        $new_address->save();



        return $new_address;

    }



    public function updateAddress($id, $data)

    {

        $addres =  $this->find($id)->address;



        $addres->address = $data['address'];

        $addres->latitude = $data['latitude'];

        $addres->longitude = $data['longitude'];



        $addres->save();

    }
    public function storeCover($id, $request)
    {
        $restaurant =  $this->find($id);
        $env  = config('app.env');

        $path = $env.'/restaurants/'.$restaurant->encrypt_id.'/profile';
        $path = $this->storeImage($request->file()['image'], null, $path);
        $restaurant->cover=$path;
        $restaurant->save();
        return $path;

    }
    public function storePhoto($id, $request)

    {

        $restaurant =  $this->find($id);



        $lastphotos = RestaurantPhoto::where('restaurant_id', $id)->latest('order_photos');

        $nextOrder = 1;

        if ($lastphotos->count() > 0) {

            $nextOrder = $lastphotos->value('order_photos') + 1;

        }



        $env  = config('app.env');

        $path = $env.'/restaurants/'.$restaurant->encrypt_id.'/profile';



        $path = $this->storeImage($request->file()['image'], null, $path);



        $photo = new RestaurantPhoto([

            'url' => $path,

            'order_photos' => $nextOrder

        ]);



        $photo  = $restaurant->photos()->save($photo);

        $photo->encrypt_id = encrypt($photo->id);

        $photo->save();

        

        return $path;

    }



    public function deletePhoto($restaurantId, $photoId)

    {

        $photo = RestaurantPhoto::find($photoId);



        if(!$photo){

            return ['status' => 404, 'message' => 'No existe la fotografía'];

        }



        if($photo->restaurant_id != $restaurantId){

            return ['status' => 401, 'message' => 'La foto no le pertenece al restaurante'];

        }



        $delete = $this->deleteImage($photo->url);



        $photo->forceDelete();



        return ($photo)? ['status' => 200, 'message' => 'Información eliminada correctamente']:['status' => 500, 'message' => null];

    }



    public function getRestaurantServiceDay(int $id, int $numDayWeek)

    {

        return RestaurantServiceDay::where(['restaurant_id' => $id, 'day_id' => $numDayWeek, 'status' => 1])

            ->first();

    }



    public function totalCapacity($id){

       return  $this->find($id)->tables->sum('capacity');

    }



    public function getListRestaurantsFounders($request, $type, $order_by, $page_size)

    {

        if($type == 'search'){

            $search = '%'.$request->name.'%';



            $query = $this->model->select('t_restaurants.id as restaurant_id')

                        ->join('c_zones', 't_restaurants.zone_id','=','c_zones.id')

                        ->Where(function ($query) use ($search) {

                            $query

                            ->orwhere('t_restaurants.name', 'like', $search );

                        });

            if($order_by){

                $query->orderBy($order_by[0],$order_by[1]);

            }

                                

            $restaurants = $query->paginate($page_size);

        }

        else {

            $query = $this->model->select('t_restaurants.id as restaurant_id')

                        ->join('c_zones', 't_restaurants.zone_id','=','c_zones.id');

            if($order_by){

                $query->orderBy($order_by[0],$order_by[1]);

            }

                                

            $restaurants = $query->paginate($page_size);

        }



        return $restaurants;

    }



    public function validateRestaurant($restaurant_id)

    {

        $restaurant = Restaurant::find($restaurant_id);

        $validator = true;

        if(!$restaurant->description || !$restaurant->phone) {

            $validator = false;

        }

        if (!$restaurant->address) {

            $validator = false;

        }

        if (!isset($restaurant->tables[0])) {

            $validator = false;

        }

        

        if (!isset($restaurant->serviceDays[0])) {

            $validator = false;

        }



        $restaurant->status = $validator;

        $restaurant->save();



        if($restaurant->status && $restaurant->active) {

            if(!$restaurant->notification) {



                $users = User::where('active', true)->where('role_id', 2)->get();



                foreach ($users as $user) {

                    if($user->firebase_token) {

                        $title          = "Nuevo Restaurante";

                        $description    = $restaurant->name." se ha unido a PUERTA 21.";

                        $information    = ['restaurant_eid' => $restaurant->encrypt_id];

                        $this->sendNotification($user->firebase_token, $title, $description, $information);

                    }

                }



                $restaurant->notification = true;

                $restaurant->save();

            }

        }

    }



    public function inactiveRestaurant($restaurant, $status) 

    {

        if (!$status) {

            $date = date('Y-m-d');

            $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                                        ->select('t_reservations.*')

                                        ->where(['t_tables.restaurant_id' => $restaurant->id])

                                        ->where('t_reservations.reservation_date', '>', $date)

                                        ->where('t_reservations.reservations_status_id', 1)

                                        ->get();

            foreach ($reservations as $reservation) {

                $user = $reservation->client->user;

                if($user->firebase_token) {

                    $title          = "Reserva Cancelada";

                    $description    = "Su reserva en ".$restaurant->name." ha sido cancelada pues el restaurante ya no forma parte de nuestro club. Le invitamos a ver otras opciones en PUERTA 21.";

                    $information    = ['restaurant_eid' => $restaurant->encrypt_id];

                    $this->sendNotification($user->firebase_token, $title, $description, $information);

                }

                $reservation->reservations_status_id = 5; // cancel

                $reservation->save();

            }

        }

        $users = User::where(['active' => !$status, 'restaurant_id' => $restaurant->id])->get();



        foreach ($users as $user) {

            $user->tokens()->delete();

            $user->active = $status;

            $user->save();

        }

    }

}

