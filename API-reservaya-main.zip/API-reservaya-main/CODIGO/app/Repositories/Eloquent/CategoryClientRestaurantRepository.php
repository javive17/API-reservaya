<?php

namespace App\Repositories\Eloquent;

use App\Repositories\CategoryClientRestaurantRepositoryInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CategoryClientRestaurantRepository implements CategoryClientRestaurantRepositoryInterface
{
    public function store(int $categoryId, int $clientId, int $restaurantId, int $status)
    {
        $table_name = 't_category_client_restaurant';

        $ok = DB::table($table_name)->updateOrInsert(
            [
                'client_id' => $clientId,
                'restaurant_id' => $restaurantId,
                'category_id' => $categoryId,
            ],
            [
                'status' => $status,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        if ($ok) {
            $id = DB::table($table_name)
                ->where([
                    'client_id' => $clientId,
                    'restaurant_id' => $restaurantId,
                    'category_id' => $categoryId,

                ])->value('id');
            Log::debug("t_category_client_restaurant id " . $id);
            $encrypt_id = encrypt($id);
            DB::table($table_name)->where('id', $id)->update(['encrypt_id' => $encrypt_id]);
        }


        return $id;
    }
}
