<?php

namespace App\Repositories\Eloquent;

use App\Repositories\UserRepositoryInterface;
use App\Repositories\Eloquent\BaseRepository;
use App\Traits\AuxiliarFunctions;
use App\Models\User;

class UserRepository  extends BaseRepository implements UserRepositoryInterface
{
    use AuxiliarFunctions;
    /**
     * UserRepository constructor.
     *
     * @param User $model
     */
    public function __construct(User $model)
    {
        parent::__construct($model);
    }


    public function createWithEncryptId(array $userRequest, String $password = null, int  $roleId = 2, $chief_manager=false)
    {
        $user = $this->model::create([
            'email' => strtolower($userRequest['email']),
            'name'  => $userRequest['name'],
            'email_hash' => md5(strtolower($userRequest['email'])),
            'password' => $password ? bcrypt($password) : $password,
            'role_id' => $roleId,
            'chief_manager' => $chief_manager
        ]);

        $user->encrypt_id = encrypt($user->id);
        $user->save();
        return $user;
    }

    public function findByHashedMail(string $hashedEmail)
    {
        return  $this->model->where('email_hash', $hashedEmail)->first();
    }

    public function verifyUserEmail(int $id)
    {
        return $this->update(['email_verified_at' => \date('Y-m-d H:i:s'), 'active' => 1], $id);
    }

    public function findByMail(string $email)
    {
        return $this->model->where('email', $email)->first();
    }
    public function createRestaurantStaff($email, $password, $roleId, $restaurantId)
    {
        $name = explode("@", $email)[0];
        $now = \date('Y-m-d H:i:s');
        $user = $this->create(
            [
                'name' => $name,
                'email' => strtolower($email),
                'email_hash' => md5(strtolower($email)),
                'password' => bcrypt($password),
                'role_id' => $roleId,
                'active'            => 1,
                'email_verified_at' => $now,
                'created_at'        => $now,
                'restaurant_id' => $restaurantId
            ]
        );
        $user->encrypt_id = encrypt($user->id);
        $user->save();
        return $user;
    }

    public function allRestaurantStaff($restaurantId, $email)
    {

        $search = [
            ['restaurant_id', $restaurantId]
        ];
        if ($email) {
            $search[] = ['email', 'like', '%' . $email . '%'];
        }

        return $this->model->where($search)->with("role");
    }

    public function allRestaurantStaffFilterByEmailOrderByPaginated($restaurantId, $email, $orderBy = [], $pageSize = 10)
    {
        $search = [
            ['restaurant_id', $restaurantId]
        ];
        if ($email) {
            $search[] = ['email', 'like', '%' . $email . '%'];
        }

        return $this->model
            ->where($search)
            ->with("role")
            ->paginate($pageSize);
    }

    public function existUserWithEmail($id, $email)
    {
        $user = $this->model
            ->where([
                ['email', $email],
                ['id','!=',$id]
            ])
            ->first();
        return $user;
    }

    public function storePhoto($file, $user)
    {
        $env  = config('app.env');
        $path = $env.'/users/'.$user->encrypt_id.'/profile';

        $path = $this->storeImage($file->file()['image'], $user->photo, $path);

        $user->photo = $path;
        $user->save();

        $photo = $this->getImageUrl($path);

        return $photo;
    }
}
