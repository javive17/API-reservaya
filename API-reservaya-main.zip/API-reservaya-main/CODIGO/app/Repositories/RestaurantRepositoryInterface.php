<?php
namespace App\Repositories;

interface RestaurantRepositoryInterface extends RepositoryInterface{

    public function address($id);
    public function photos($id);
    public function capacity($id);
    public function totalCapacity($id);

    public function createRestaurant($name, $owner_name,$zone_id, $cost_id, $address_id, $email);

    public function showRestaurant($restaurant);

    public function createUpdateKitchens($restaurant_id, $data, $status);

    public function createUpdateExtraServices($restaurant_id, $data, $status);
    
    public function createUpdateServiceDay($restaurant_id, $data);

    public function createUpdateCapacity($restaurant_id, $data, $ids);

    public function createAddress($address, $latitude, $longitude);

    public function updateAddress($id,$data);

    public function storePhoto($id, $request);

    public function deletePhoto($restaurantId, $photoId);

    public function getRestaurantServiceDay(int $id, int $numDayWeek);

    public function getListRestaurantsFounders($request, $type, $order_by, $page_size);

    public function validateRestaurant($restaurant_id);

    public function inactiveRestaurant($restaurant, $status);
}
