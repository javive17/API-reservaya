<?php

namespace App\Repositories;

interface CategoryClientRestaurantRepositoryInterface
{
    public function store(int $categoryId, int $clientId, int $restaurantId, int $status);
}
