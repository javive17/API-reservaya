<?php



namespace App\Repositories;



interface ReservationRepositoryInterface extends RepositoryInterface

{

    public function findByRestaurantId($restaurantId);

    public function SendPushNotificationToRestaurant($restaurantID, $reservationID);



    public function findByRestaurantIdWithClientByMonthOrderedPaginated($restaurantId, $year, $month, $pageSize, $orderBy);



    public function findByRestaurantIdWithClientByMonth($restaurantId, $year, $month);



    public function findByRestaurantIdWithClientAndStatusAndTable($restaurantId);



    public function findByRestaurantIdAndDateIdWithClientAndStatusAndTable($restaurantId, $date);



    public function findByRestaurantIdAndDateIdWithClientAndStatusAndTableFilterByTableTypes($restaurantId, $date, $tableTypes, $pageSize, $orderBy, $search);



    public function findByRestaurantIdAndReservationDate($restaurantId, $date);



    public function findByRestaurantIdAndReservationDateAndTableId($restaurantId, $date, $tableId);



    public function store($client_id, $table_id, $comments, $people, $reservation_date, $tableNumber, $type, $startDate, $endDate, $userId);



    public function updateReservation($reservation_id, $client_id, $table_id, $comments, $people, $reservation_date, $tableNumber);



    public function countByRestaurantIdbetweenDatesGroupByTableId($restaurantId, $initDate, $lastDate);



    public function countClientReservationsStatusByRestaurant($restaurantId, $clientId);



    public function getSpentByClientInRestaurant($restaurantId, $clientId);



    public function getCapacityPerDayByMonth($restaurantId, $year, $month);



    public function getIncomeByMonthWithTotal($restaurantId, $year, $month);



    public function clientReservationListFounders($request, $type, $client_id, $page_size);



    public function queryfindByRestaurantIdWithClientByMonthForFounders($restaurant_id, $month, $year, $page_size, $order_by, $search);



    public function queryfindByRestaurantIdWithClientByMonthForFoundersReport($restaurant_id, $month, $year);
}
