<?php

namespace App\Repositories;


interface PasswordResetRepositoryInterface
{
    /**
     * check if user already has a previous reset token and update it if so.
     */
    public function createOrUpdateUserResetToken(string $email, string $resetToken);
    /**
     * check if user reset token is valid
     */
    public function checkUserResetTokenIsValid(string $resetToken);
    /**
     * Delete reset token
     */
    public function deleteResetToken(string $resetToken);
}
