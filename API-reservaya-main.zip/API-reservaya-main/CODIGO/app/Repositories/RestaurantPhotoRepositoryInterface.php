<?php
namespace App\Repositories;

interface RestaurantPhotoRepositoryInterface extends RepositoryInterface{


    public function store($restaurantId, $image);
}
