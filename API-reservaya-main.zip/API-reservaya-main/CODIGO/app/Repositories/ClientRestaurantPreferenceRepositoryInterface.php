<?php
namespace App\Repositories;

interface ClientRestaurantPreferenceRepositoryInterface extends RepositoryInterface{

    public function findByRestaurantIdAndClientId($restaurantId,$clientId);

    public function updatePreference($restaurantId,$clientId,$data);
    public function createDefault($restaurantId,$clientId);
}
