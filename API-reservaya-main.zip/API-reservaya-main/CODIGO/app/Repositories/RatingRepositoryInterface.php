<?php

namespace App\Repositories;


interface RatingRepositoryInterface extends RepositoryInterface
{
    public function getByRestaurantId($restaurantId);

    public function getByRestaurantIdPaginatedOrderedBy($restaurantId,$pageSize,$orderBy);

    public function updateRestaurantReply($ratingId,$replay);

}
