<?php

namespace App\Repositories;

interface CatalogRepositoryInterface
{

    public function getList(string $modelName);
}
