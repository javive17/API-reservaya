<?php

namespace App\Http\Middleware;

use Closure;
use App\Traits\GeneralResponse;
use Illuminate\Support\Facades\Auth as FacadesAuth;

class CheckIsManager
{
    use GeneralResponse;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(FacadesAuth::user()->role_id === 3){
            return $next($request);

        }
        return $this->genResponse( 0, 401, null, "Solo los gerentes pueden hacer esta acción");

    }
}
