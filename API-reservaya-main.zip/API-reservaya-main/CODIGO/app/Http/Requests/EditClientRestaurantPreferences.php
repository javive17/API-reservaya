<?php



namespace App\Http\Requests;



use Illuminate\Foundation\Http\FormRequest;

/**

 * @bodyParam rating numeric  La calificacion de cliente debe estar entre 0 y 5. Example: 2.5

 * @bodyParam friend string  El amigo conocido del cliente. Example: El Papa jonh

 * @bodyParam drink string  La bebida preferida del cliente. Example: Martini seco

 * @bodyParam food string  La comida preferida del cliente. Example: Ribeye

 * @bodyParam table string Lugar o mesa preferida del cliente. Example:Lejos de la gente

 */

class EditClientRestaurantPreferences extends FormRequest

{

    /**

     * Determine if the user is authorized to make this request.

     *

     * @return bool

     */

    public function authorize()

    {

        return true;

    }



    /**

     * Get the validation rules that apply to the request.

     *

     * @return array

     */

    public function rules()

    {

        return [

            'rating' => 'sometimes|numeric|between:0,5',

            'friend' => 'sometimes|string',

            'drink' => 'sometimes|string',

            'food' => 'sometimes|string',

            'table' => 'sometimes|string',

            'extra_comments' => 'sometimes|string',

            'birthday_date' => 'sometimes|string',

        ];

    }

}

