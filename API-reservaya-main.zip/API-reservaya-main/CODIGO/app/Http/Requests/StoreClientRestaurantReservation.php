<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuxiliarFunctions;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

/**
 * @bodyParam number_people int required La cantidad de personas que van a ir al restaurante. Example: 4
 * @bodyParam date string required La fecha de la reservación en el restaurante. Example: 2021-07-19 16:00
 * @bodyParam table_id string required El id de la mesa a que se quiere reservar.
 * @bodyParam comments string  Los comentarios de el cliente para su reserva en el restaurante. Example: Un comentario
 * @bodyParam table_number string  El numero de mesa para la reservación. No-example
 */
class StoreClientRestaurantReservation extends FormRequest
{

    use AuxiliarFunctions;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'number_people' => ['required', 'numeric'],
            'date' => [
                'required ',
                'date_format:Y-m-d H:i',
                function ($attribute, $value, $fail) {
                    if ($value < date('Y-m-d H:i')) {
                        $fail('La fecha debe ser mayor o igual a la fecha y hora del dia.');
                    }
                },
            ],
            'table_type_eid' => 'required',
            'restaurant_eid' => 'required',
            'comments' => 'sometimes|string|max:250',
        ];
    }
}
