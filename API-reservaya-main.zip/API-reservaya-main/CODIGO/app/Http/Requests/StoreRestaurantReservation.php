<?php



namespace App\Http\Requests;



use Illuminate\Foundation\Http\FormRequest;

use App\Traits\AuxiliarFunctions;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\Validator;



/**

 * @bodyParam number_people int required La cantidad de personas que van a ir al restaurante. Example: 4

 * @bodyParam date string required La fecha de la reservación en el restaurante. Example: 2021-07-19 16:00

 * @bodyParam table_type_id string required El id de la mesa a que se quiere reservar.

 * @bodyParam comments string  Los comentarios de el cliente para su reserva en el restaurante. Example: Un comentario

 * @bodyParam client_id id  El id de el cliente que queire reservar en el restaurante,

 * si no es parte de el sistema se debe pasar la informacion para crear al cliente. No-example

 * @bodyParam client.name string  El nombre del cliente.

 * @bodyParam client.middle_name string El apellido paterno.

 * @bodyParam client.last_name string  El apellido materno.

 * @bodyParam client.phone string  El numero del cliente.

 * @bodyParam client.email string  El correo del cliente.

 * @bodyParam categories array Las categoria del cliente.

 * @bodyParam table_number string  El numero de mesa para la reservación. No-example

 */

class StoreRestaurantReservation extends FormRequest

{



    use AuxiliarFunctions;

    /**

     * Determine if the user is authorized to make this request.

     *

     * @return bool

     */

    public function authorize()

    {

        return true;

    }



    /**

     * Get the validation rules that apply to the request.

     *

     * @return array

     */

    public function rules()

    {

        return [

            'number_people' => ['required', 'numeric'],

            'table_type_id' => ['required'],

            'date' => [

                'required',

                'date_format:Y-m-d H:i',

                function ($attribute, $value, $fail) {

                    if ($value < date('Y-m-d H:i')) {

                        $fail('La fecha debe ser mayor o igual a la fecha y hora del dia.');

                    }

                },

            ],

            'comments' => 'sometimes|string|max:250',

            'client_id' => 'sometimes|numeric|min:1',

            'client' => [

                'sometimes',

                function ($attribute, $value, $fail) {

                    $this->validateClient($attribute, $value, $fail);

                },

            ],

            'table_number' => 'sometimes',
            'type' => 'sometimes',
            'event' => 'sometimes',
            'startDate' => 'sometimes',
            'endDate' => 'sometimes',
            'categories' => [

                'sometimes',

                'array'

            ],

        ];

    }



    protected function prepareForValidation()

    {

        $tomerge = ['table_type_id' => $this->getDecrypted($this->table_type_id),];

        if ($this->client_id) {

            $tomerge['client_id'] = $this->getDecrypted($this->client_id);

        }

        if(!$this->categories){

            $tomerge['categories'] = [];

        }

        $this->merge($tomerge);

    }









    private function validateClient($attribute, $value, $fail)

    {

        $validator = Validator::make(

            $value,

            [

                'name' => 'sometimes',

            ]

        );



        if ($validator->fails()) {

            Log::debug("Client error" . json_encode($validator->errors()));

            $fail($validator->errors()->all());

        }

    }

}

