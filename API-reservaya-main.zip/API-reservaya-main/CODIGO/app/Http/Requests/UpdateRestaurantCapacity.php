<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * @bodyParam capacity.*.type_id id required
 * @bodyParam capacity.*.capacity int required
 */
class UpdateRestaurantCapacity extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'capacity' => [
                'required',
                'array',
                function ($attribute, $value, $fail) {
                    if (!is_array($value)) {
                        return;
                    }

                    $errors = [];
                    foreach ($value as $key => $val) {
                        if (!is_array($val)) {
                            $errors[] = $attribute.' '.$key.' must be a valid json';
                        }
                        if (!array_key_exists('table_type_eid', $val)) {
                            $errors[] = $attribute.' '.$key.' table_type_eid is required.';
                        }
                        if (!array_key_exists('capacity', $val)) {
                            $errors[] = $attribute.' '.$key.' capacity is required.';
                        }
                    }
                    if (!empty($errors)) {
                        $fail($errors);
                    }
                },
            ],
        ];
    }
}
