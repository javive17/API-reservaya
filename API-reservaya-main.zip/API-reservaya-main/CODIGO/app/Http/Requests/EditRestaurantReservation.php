<?php



namespace App\Http\Requests;



use Illuminate\Foundation\Http\FormRequest;



/**

 * @bodyParam number_people numeric  Número de personas de la reservación. Example: 2

 * @bodyParam date date(Y-m-d H:i)  la fecha a editar de la reservacion. Example: 2021-07-16 16:00

 * @bodyParam table_id id  la mesa a editar de la reservacion. No-example

 * @bodyParam comments string  la los comentarios a editar de la reservacion. No-example

 * @bodyParam table_number string el numero de esa a editar de la reservacion. No-example

 */

class EditRestaurantReservation extends FormRequest

{

    /**

     * Determine if the user is authorized to make this request.

     *

     * @return bool

     */

    public function authorize()

    {

        return true;

    }



    /**

     * Get the validation rules that apply to the request.

     *

     * @return array

     */

    public function rules()

    {

        return [

            'number_people' => ['required', 'numeric'],

            'date' => [

                'required',

                'date_format:Y-m-d H:i',

            ],

            'table_type_eid' => 'required',

            'comments' => 'sometimes',
            'type' => 'sometimes',

        ];

    }

}

