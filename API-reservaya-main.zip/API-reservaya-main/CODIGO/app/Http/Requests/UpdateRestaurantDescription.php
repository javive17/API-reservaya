<?php



namespace App\Http\Requests;



use Illuminate\Foundation\Http\FormRequest;



/**

 * @bodyParam description string

 * @bodyParam address.address string required

 * @bodyParam address.latitude double required

 * @bodyParam address.longitude double required

 * @bodyParam phone string Example: 5588778899

 * @bodyParam cheff_name string Example: Albarado el cheff

 */

class UpdateRestaurantDescription extends FormRequest

{

    /**

     * Determine if the user is authorized to make this request.

     *

     * @return bool

     */

    public function authorize()

    {

        return true;

    }



    /**

     * Get the validation rules that apply to the request.

     *

     * @return array

     */

    public function rules()

    {

        return [

            'description' => 'sometimes|max:250|min:5',

            'address' => [

                'sometimes',

                function ($attribute, $value, $fail) {

                    $this->validateAddress($attribute, $value, $fail);

                },

            ],

            'phone' => 'sometimes|max:13|min:7',

            'cheff_name' => 'sometimes|min:3',
            'paymentMethod' => 'sometimes|min:3',
        ];

    }



    private function validateAddress($attribute, $value, $fail)

    {

        if (!is_array($value)) {

            $fail([$attribute.' must be a valid json']);



            return;

        }

        $errors = [];

        if (!array_key_exists('address', $value)) {

            $errors[] = $attribute.'.address is required.';

        }

        if (!array_key_exists('latitude', $value)) {

            $errors[] = $attribute.' .latitude is required.';

        } elseif (!is_float($value['latitude'])) {

            $errors[] = $attribute.'.latitude must be float.';

        }

        if (!array_key_exists('longitude', $value)) {

            $errors[] = $attribute.'.longitude is required.';

        } elseif (!is_float($value['longitude'])) {

            $errors[] = $attribute.'.longitude must be float.';

        }

        if (!empty($errors)) {

            $fail($errors);

        }

    }

}

