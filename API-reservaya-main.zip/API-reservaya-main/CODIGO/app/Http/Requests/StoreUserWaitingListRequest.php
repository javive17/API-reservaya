<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * @bodyParam email email required El correo de la persona que quiere ser parte de puerta21. No-example
 * @bodyParam social_media.*.id id required El id de la red social con la que se registra.
 * @bodyParam social_media.*.url url required La url de la red social con la que se registra.
 */
class StoreUserWaitingListRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'required|email|unique:users',
            'social_media' => 'required',
        ];
    }
}
