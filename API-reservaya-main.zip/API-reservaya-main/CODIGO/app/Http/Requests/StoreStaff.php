<?php

namespace App\Http\Requests;

use App\Traits\AuxiliarFunctions;
use Illuminate\Foundation\Http\FormRequest;

/**
 * @bodyParam email email required El correo de el nuevo staff. Example: newstaff@kokonutstudio.com
 * @bodyParam password string La contraseña de el nuevo staff. Example: Qwerty123
 * @bodyParam role_eid id required El id de el rol que tendra el nuevo staff. No-example
 */
class StoreStaff extends FormRequest
{
    use AuxiliarFunctions;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'required|email|unique:users',
            'password' => 'required|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$/',
            'role_eid' => 'required',
        ];
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'role_eid' => $this->getDecrypted($this->role_eid),
        ]);
    }
}
