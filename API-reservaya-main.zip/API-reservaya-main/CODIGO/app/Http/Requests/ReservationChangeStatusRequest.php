<?php



namespace App\Http\Requests;



use App\Traits\AuxiliarFunctions;

use Illuminate\Foundation\Http\FormRequest;



/**

 * @bodyParam reservation_id id required El id de la reservación al que se le cambiara el estatus. No-example

 * @bodyParam status_id id required El estatus al que se le cambiara a la reservacion. No-example

 */

class ReservationChangeStatusRequest extends FormRequest

{

    use AuxiliarFunctions;



    /**

     * Determine if the user is authorized to make this request.

     *

     * @return bool

     */

    public function authorize()

    {

        return true;

    }



    /**

     * Get the validation rules that apply to the request.

     *

     * @return array

     */

    public function rules()

    {

        return [

            'reservation_id' => 'required|string',

            'status_id' => 'required|numeric|between:1,11',

        ];

    }



    /**

     * Get the error messages for the defined validation rules.

     *

     * @return array

     */

    public function messages()

    {

        return [

            'status_id.between' => 'estatus a actualizar no permitido. Perimitidos ("asistió", "no asistió", "se ha ido")',

        ];

    }



    protected function prepareForValidation()

    {

        $this->merge([

            'status_id' => $this->getDecrypted($this->status_id),

        ]);

    }

}

