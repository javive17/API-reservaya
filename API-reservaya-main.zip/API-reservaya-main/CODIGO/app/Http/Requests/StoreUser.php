<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * @bodyParam photo image:mimes:jpeg,png,jpg,gif,svg La foto del nuevo cliente. No-example
 * @bodyParam data.name string required
 * @bodyParam data.last_name string required
 * @bodyParam data.email_hashed email required
 */
class StoreUser extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            // 'photo' => 'sometimes|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'photo' => 'sometimes|image|mimes:jpeg,png,jpg,gif,svg',
            'data' => [
                'required',
                'json',
                function ($attribute, $value, $fail) {
                    $datas = json_decode($value, true);
                    if (!array_key_exists('email', $datas)) {
                        $fail($attribute.'email is required.');
                    }
                    if (!array_key_exists('name', $datas)) {
                        $fail($attribute.'.name is required.');
                    }
                    if (!array_key_exists('first_lastname', $datas)) {
                        $fail($attribute.'last_name is required.');
                    }
                },
            ],
        ];

        return $rules;
    }
}
