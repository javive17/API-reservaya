<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuxiliarFunctions;
use Illuminate\Support\Facades\Log;

/**
 * @bodyParam email email El correo de el nuevo staff. Example: editedstaff@kokonutstudio.com
 * @bodyParam password string La contraseña de el nuevo staff. Example: Qwerty123
 * @bodyParam role_id id El id de el rol que tendra el nuevo staff. No-example
 */
class EditStaff extends FormRequest
{

    use AuxiliarFunctions;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'sometimes|required|email',
            'password' => 'sometimes|required|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$/',
            'role_eid' => 'sometimes|required',
        ];
    }

    protected function prepareForValidation()
    {
        if ($this->role_eid) {
            $this->merge([
                'role_eid' => $this->getDecrypted($this->role_eid),
            ]);
        }
    }
}
