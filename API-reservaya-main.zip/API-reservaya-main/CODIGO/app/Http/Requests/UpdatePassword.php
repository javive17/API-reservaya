<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Traits\AuxiliarFunctions;
use Illuminate\Support\Facades\Log;

/**
 * @bodyParam password email El correo de el nuevo staff. Example: editedstaff@kokonutstudio.com
 * @bodyParam password string La contraseña de el nuevo staff. Example: Qwerty123
 * @bodyParam password id El id de el rol que tendra el nuevo staff. No-example
 */
class UpdatePassword extends FormRequest
{

    use AuxiliarFunctions;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'password' => 'required',
            'new_password' => 'required|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$/',
            'new_password_confirmation' => 'required|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$/',
        ];
    }
}
