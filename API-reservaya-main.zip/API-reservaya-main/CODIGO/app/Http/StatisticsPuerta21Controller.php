<?php



namespace App\Http\Controllers\API\Restaurant;



use Illuminate\Http\Request;

use App\Traits\{GeneralResponse, Notification, AuxiliarFunctions};

use App\Models\Catalogs\TableType;

use App\Models\Reservation;
use App\Models\Table;
use App\Models\ReservationBlocked;
use App\Models\PardepanBlocked;

use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Log;


use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Validator;

use App\Http\Requests\EditRestaurantReservation;

use App\Http\Requests\StoreRestaurantReservation;

use App\Services\Restaurant\ClientServiceInterface;

use App\Http\Requests\ReservationAvailabilityRequest;

use App\Http\Requests\ReservationChangeStatusRequest;

use App\Services\Restaurant\ReservationServiceInterface;

use App\Mail\AcceptReservation;

use App\Mail\CancelledReservation;


use Carbon\Carbon;

use Illuminate\Support\Facades\Mail;

use App\Jobs\SendNotifications;




