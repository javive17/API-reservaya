<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MailableController extends Controller
{
    public function renderMailable(Request $request, string $mailview)
    {

        $notFound = "<h1> 404 </h1>";

        if (config('app.debug')) {


            $query = $request->all();
            $data = isset($query['url']) ? $query['url'] : "default";
            $mail = 'App\\Mail\\' . $mailview;

            if (!class_exists($mail)) {
                return $notFound;
            }

            return (new $mail($data))->render();
        }
        return $notFound;
    }
}
