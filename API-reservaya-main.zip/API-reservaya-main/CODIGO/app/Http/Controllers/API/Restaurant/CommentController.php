<?php

namespace App\Http\Controllers\API\Restaurant;

use App\Http\Controllers\Controller;
use App\Services\Restaurant\CommentServiceInterface;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\{ReplyComment, StoreComment};
/**
 * @group Restaurant comments
 */
class CommentController extends Controller
{
    use AuxiliarFunctions;
    use GeneralResponse;

    /** @var CommentServiceInterface */
    private $commentService;

    public function __construct(
        CommentServiceInterface $commentService
    ) {
        $this->commentService = $commentService;
    }

    /**
     * Index
     *
     * [Regresa una lista de todos los comentarios que han hecho los clientes a la reservacion en el restaurante]
     */
    public function index(Request $request)
    {
        $restaurantId = auth()->user()->restaurant_id;
        $pageSize = $request->query('pagesize', 10);
        $orderBy = str_replace('+', ' ', $request->query('orderBy', ''));
        Log::info($pageSize);
        Log::info($orderBy);
        $comments = $this->commentService->getByRestaurantIdPaginatedOrderedBy($restaurantId,$pageSize,$orderBy);

        return $this->genResponse(1, 200, $comments);
    }


    /**
     * Reply
     *
     * [Contesta el comentario de el cliente hacia la reservacion]
     */
    public function replyComment(ReplyComment $request,$id){

        $data = $request->validated();
        // $restaurantId = auth()->user()->restaurant_id;

        return $this->commentService->replyClientComments($id,$data['reply']);

    }

    /**
     * Delete
     *
     * [Elimina el comentario de el cliente hacia la reservacion]
     */
    public function deleteComment(Request $request, $id)
    {
        return $this->commentService->deleteComments($id);
    }
}
