<?php

namespace App\Http\Controllers\API\Restaurant;

use App\Http\Controllers\Controller;
use App\Services\Restaurant\CommentServiceInterface;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\{ReplyComment, StoreComment};
use Illuminate\Support\Facades\DB;
use App\Models\Reservation;
use App\Models\Client;
use App\Models\User;

/**
 * @group Restaurant comments
 */
class ClientsSurveyController extends Controller
{
    use AuxiliarFunctions;
    use GeneralResponse;

    /** @var CommentServiceInterface */
    private $commentService;

    public function __construct(
        CommentServiceInterface $commentService
    ) {
        $this->commentService = $commentService;
    }

    /**
     * Index
     *
     * [Regresa una lista de todos los comentarios que han hecho los clientes a la reservacion en el restaurante]
     */
    
    public function index()
    {
        $manager = auth()->user()->restaurant_id;
        // Resto del código...

        $reviews = DB::table('t_reviews')
        ->where('is_Seen', 1)
        ->where('restaurant_id', $manager)
        ->whereNotNull('comment') 
        ->count();

        $data = [
            'manager' => $manager,
            'reviews' => $reviews
        ];

        return $this->genResponse(1, 200, $data);
    }


        public function survey()
    {
        $manager = auth()->user()->restaurant_id;
        
        $averageRating = DB::table('t_reviews')
        ->where('restaurant_id', $manager)
        ->avg('rating');

        $reviews = DB::table('t_reviews')
        ->where('restaurant_id', $manager)
        //order by recentmost
        ->orderBy('created_at', 'desc')
       
        ->get();

        
        $reviewsIds = $reviews->pluck('reservation_id');
        $reservations = Reservation::whereIn('id', $reviewsIds)->pluck('client_id');
       
        $infoClient = Client::whereIn('id', $reservations)->pluck('user_id');
        $number = Client::whereIn('id', $reservations)->get();
        $infoClient2 = Client::whereIn('id', $reservations)->get();
        
        $infoUser = User::whereIn('id', $infoClient)->get();
        $date_reservations = Reservation::whereIn('id', $reviewsIds)->get();

        $combinedData = [];

        foreach ($reviews as $review) {
            $reviewData = [
                'id' => $review->id,
                'reservation_id' => $review->reservation_id,
                'user_id' => $review->user_id,
                'restaurant_id' => $review->restaurant_id,
                'comment' => $review->comment,
                'is_seen' => $review->is_seen,
                'rating' => $review->rating,
                'created_at' => $review->created_at,
                'updated_at' => $review->updated_at,
            ];
        
            $userInfo = $infoUser->firstWhere('id', $review->user_id);
        
            if ($userInfo) {
                $reviewData['name'] = $userInfo->name;
                $reviewData['cell_phone'] = $userInfo->phone;
                $reviewData['email'] = $userInfo->email;
                $reviewData['photo'] = $userInfo->photo;

            }
            $usernumber = $number->firstWhere('user_id', $review->user_id);

            if ($usernumber) {
                $reviewData['first_name'] = $usernumber->first_name;
                $reviewData['cell_phoneData'] = $usernumber->cell_phone;
                $reviewData['last_name'] = $usernumber->last_name;
                $reviewData['middle_name'] = $usernumber->middle_name;
              
            }
            $datereservation = $date_reservations->firstWhere('id', $review->reservation_id);
            if ($datereservation) {
                $reviewData['fecha'] = $datereservation->reservation_date;
              
              
            }
        
            $combinedData[] = $reviewData;
        }




        $data = [
            'combinedData' => $combinedData,
            'reviews' => $reviews,
            'reviewsid' => $infoUser,
            'averageRating' => $averageRating,
            'manager' => $manager,
            'infoClient2' => $infoClient2,
            'number' => $number,
            'date_reservations' =>  $date_reservations
            
        ];

        return $this->genResponse(1, 200, $data);
    }

    public function updateseen($id)
    {
        // Lógica para actualizar el valor de 'isSeen' en la base de datos
        // Puedes utilizar el $id para identificar el comentario específico que se debe actualizar
        
        // Ejemplo de código para cambiar el valor de 'isSeen' utilizando DB::table:
        $reviews = DB::table('t_reviews')->where('id', $id)->first();
        if ($reviews) {
            DB::table('t_reviews')->where('id', $id)->update(['is_Seen' => 0]);
        }
        
        // Puedes devolver una respuesta apropiada según el resultado de la actualización
        return response()->json(['message' => 'isSeen updated successfully']);
    }
  
  
}
