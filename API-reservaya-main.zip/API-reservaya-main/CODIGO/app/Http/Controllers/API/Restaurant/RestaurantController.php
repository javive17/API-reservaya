<?php



namespace App\Http\Controllers\API\Restaurant;



use App\Http\Controllers\Controller;

use App\Repositories\RestaurantRepositoryInterface;

use App\Traits\AuxiliarFunctions;

use App\Traits\GeneralResponse;

use Illuminate\Http\Request;

use App\Http\Requests\StorePhoto;

use Illuminate\Support\Facades\Validator;
use App\Models\Catalogs\TableType;
use App\Models\User;
use App\Models\Restaurant;

/**

 * @group Restaurant

 */

class RestaurantController extends Controller

{

    use GeneralResponse;

    use AuxiliarFunctions;



    /** @var RestaurantRepositoryInterface */

    private $repository;



    public function __construct(

        RestaurantRepositoryInterface $repository

    ) {

        $this->repository = $repository;
    }



    /**

     * Show

     * [Regresa el detalle del restaurante].

     */
    public function tabletypes(Request $request)
    {

        $manager = auth()->user();
        $tables = TableType::where("restaurant_id", null)->orWhere('restaurant_id', $manager->id)->get();
        return $this->genResponse(1, 200, $tables);
    }
    public function show()
    {
        $manager = auth()->user();
        $restaurant = $this->repository->find($manager->restaurant_id);
        $data = $this->repository->showRestaurant($restaurant);
        return $this->genResponse(1, 200, $data);
    }
    public function createrestaurant(Request $request)
    {

        $user = User::where('email', $request->email)->first();
        $main = User::where('email', $request->owner_email)->first();
        $ownerrestaurant = Restaurant::where('id', $main->restaurant_id)->first();
        if(!$ownerrestaurant){
            return $this->genResponse(0, 400, "Hay un error en la configuración de su cuenta, contactenos para solucionarlo");
        }
        if ($ownerrestaurant->owner_email == null ||     $ownerrestaurant->owner_email == '') {
            $ownerrestaurant->owner_email = $request->owner_email;
            $ownerrestaurant->save();
        }
        if ($user) {
            return $this->genResponse(0, 400, "El correo ya esta asociado a un usuario");
        } else {

            $restaurant = $this->repository->createRestaurant($request->name, $main->name, 1, 1, 1, $request->email);
            $password = $request->password;
            // $user = $this->userRepository->createWithEncryptId($data, $password, 3, true);

            $user = User::create([

                'email' => strtolower($request->email),

                'name'  => $request->name,

                'email_hash' => md5(strtolower($request->email)),

                'password' => $password ? bcrypt($password) : $password,

                'role_id' => 3,

                'chief_manager' => 1

            ]);
            $restaurant->owner_email = $request->owner_email;
            $restaurant->active = 1;
            $restaurant->pwd = $password;
            $user->active = 1;
            $restaurant->save();
            $user->encrypt_id = encrypt($user->id);
            $user->restaurant_id = $restaurant->id;
          
            $user->save();
            return $this->genResponse(1, 200, $restaurant);
        }
    }
    public function createzone(Request $request)
    {
        $manager = auth()->user();


        $tabletype = new TableType;
        $tabletype->name = $request->name;
        $tabletype->restaurant_id = $manager->id;
        $tabletype->save();
        $tabletype->encrypt_id =  encrypt($tabletype->id);
        $tabletype->save();


        return $this->genResponse(1, 200, $tabletype);
    }

    public function storecover(Request $request)
    {
        $image = \Image::make($request->image);
        $filename = \Str::random(10) . '800.webp';
        $image->resize(1280, 720);
        $image->encode('webp', 75)->save('public/webp/'.$filename);
        $manager = auth()->user();
        $restaurant = $this->repository->find($manager->restaurant_id);
        $restaurant->webp = $filename;
        $restaurant->save();

        $newPhoto = $this->repository->storeCover($manager->restaurant_id, $request);

        return $this->genResponse(1, 200, $newPhoto);
    }
    /**

     * Store photos.

     *

     * [Guarda las fotos de el restaurante. El restaurante solo puede tener hasta 20 fotos.]

     * 

     * @bodyParam image Imagen de perfil

     *

     * @param mixed $image

     */

    public function storePhotos(StorePhoto $request)

    {

        $data = $request->validated();



        $manager = auth()->user();



        $newPhoto = $this->repository->storePhoto($manager->restaurant_id, $request);



        return $this->genResponse(1, 200, $newPhoto);
    }



    /**

     * Get the Address of the Restaurant

     * [Actualiza el estado de un favorito].

     */

    public function getAddress($restaurant_eid)

    {

        $id = $this->getDecrypted($restaurant_eid);



        $restaurant = $this->repository->find($id);



        if (!$restaurant) {

            return $this->genResponse(0, 404, null, 'No existe el costo enviado');
        }



        $address = $restaurant->address;



        return $this->genResponse(1, 200, $address);
    }
}
