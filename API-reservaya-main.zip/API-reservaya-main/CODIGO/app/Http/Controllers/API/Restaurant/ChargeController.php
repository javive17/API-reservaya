<?php
namespace App\Http\Controllers\API\Restaurant;
use App\Http\Controllers\Controller;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use App\Services\Restaurant\ChargeServiceInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Exports\ChargesExport;
use Illuminate\Support\Facades\Log;
/**
 *  @group Restaurant Charge
 */
class ChargeController extends Controller {

    use AuxiliarFunctions;
    use GeneralResponse;


    /** @var ChargeServiceInterface */
    private $chargeService;

    public function __construct(ChargeServiceInterface $chargeService)
    {
        $this->chargeService =$chargeService;

    }

    /**
     * index
     *
     * [Lista de cargos del restaurante]
     */
    public function index(Request $request,$date)
    {
        $pageSize = $request->query('pagesize', 15);
        $restaurantId = auth()->user()->restaurant_id;

        $validator = Validator::make(
            ['date' => $date],
            ['date' => 'required|date_format:Y-m']
        );

        if ($validator->fails()) {
            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);
        }

        return $this->chargeService->getRestaurantChargePerMonthPaginated($restaurantId,$date,$pageSize );
    }

    /**
     * export
     *
     * [Reporte de cargos del restaurante]
     */
    public function export($date){
        $restaurantId = auth()->user()->restaurant_id;
        $validator = Validator::make(
            ['date' => $date],
            ['date' => 'required|date_format:Y-m']
        );

        if ($validator->fails()) {
            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);
        }

        $charges= $this->chargeService->getRestaurantChargePerMonth($restaurantId,$date);

        // return $this->genResponse(1,200,$charges);
        return (new ChargesExport($charges));


    }

}
