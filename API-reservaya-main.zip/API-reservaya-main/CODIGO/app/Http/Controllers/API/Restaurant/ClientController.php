<?php



namespace App\Http\Controllers\API\Restaurant;



use App\Http\Controllers\Controller;

use App\Services\Restaurant\ClientServiceInterface;

use App\Http\Requests\EditClientRestaurantPreferences;

use App\Http\Requests\EditClientRestaurantCategory;

use App\Traits\AuxiliarFunctions;

use App\Traits\GeneralResponse;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\DB;

use App\Exports\ClientsExport;

use App\Models\Client;

use App\Models\User;

use App\Models\Catalogs\{NutritionalRequirement, Allergy, Table, Drink};



class ClientController extends Controller

{

    use GeneralResponse;

    use AuxiliarFunctions;



    /** @var ClientServiceInterface */

    private $clientService;



    public function __construct(

        ClientServiceInterface $clientService

    ) {

        $this->clientService = $clientService;
    }



    /**

     * @group Restaurante clientes

     *

     * Clientes del restaurante

     *

     * [Regresa todo los clientes que tiene el restaurante lo

     * clientes pueden ser de la aplicación o de clientes agregados por las reservaciones hechas al restaurante].

     *

     * @urlParam type required el tipo de cliente que se quieres mostrar Example: puerta21|general-public

     * @queryParam page El numero de pagina  Example:1

     * @queryParam pagesize El tamaño de la pagina por omisión el tamaño es 10 Example:15

     * @queryParam orderBy El orden por columna (acendente o descendente)  Example:nombre

     *

     * @param mixed $type

     */

    public function index(Request $request, $type)

    {

        if ('puerta21' !== $type && 'general-public' !== $type) {

            return $this->genResponse(0, 404);
        }
        $manager = auth()->user();

        //$pageSize = $request->query('pagesize', 10);
        $pageSize = 1000;
        $orderBy = str_replace('+', ' ', $request->query('orderBy', ''));

        $clients = $this->clientService->getClientsByRestaurantIdAndType($manager->restaurant_id, $type, $pageSize, $orderBy);
        return $this->genResponse(1, 200, $clients);
    }



    /**

     * @group Restaurante clientes

     *

     * Search client by client's email

     *

     * [regresa el cliente que tengan un email igual al que se le pasa por la url,

     * si no existen ningun cliente regresa un 404 ]

     *

     * @urlParam email required El correo con el que se va buscar Example:client@kokonutstudio.com

     *

     * @response  {

     *  "id": "eyJpdiI6Ilg2NDhpekRiaTlCOENaZkorelB5V1E9PSIsInZhbHVlIjoiOW1KRVMrcnJWUkh0RGF6dlJqYlN3dz09IiwibWFjIjoiMmQ4NGEwNzFmYmUyYzM4YWM3MGMyMjk5NTQ1MTA3MjQyOTZkNzJiODQ0OTU4YzIwYzlhY2Y3YzM1NzZmMDdkYiJ9",

     *  "first_name": "client",

     *  "middle_name": "Pfannerstill",

     *  "last_name": "Oberbrunner",

     *  "cell_phone": "+1.440.316.3350",

     *  "email": "client@kokonutstudio.com",

     *  "categories": []

     * }

     */
    public function searchAllClients(){
       
        //client is linked to user via user_id get all clients join with user
        $clients = Client::join('users', 'users.id', '=', 't_clients.user_id')
        //select from clients only the id, the name, middle name and last name and phone

        ->select('t_clients.id', 't_clients.cell_phone', 't_clients.first_name','t_clients.middle_name','t_clients.last_name', 'users.email')
        // whre cellphone is not null
        ->whereNotNull('t_clients.cell_phone')
        ->get();


        return $this->genResponse(1, 200, $clients);
    }

    public function searchClientsByEmail(string $email)

    {

        $manager = auth()->user();

        Log::info('email : ' . $email);



        $validator = Validator::make(

            ['email' => $email],

            ['email' => 'required|email']

        );



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);
        }

        $client = $this->clientService->findByRestaurantAndEmail($manager->restaurant_id, $email);

        if (!$client) {

            return $this->genResponse(0, 404);
        }



        if (isset($client['status'])) {

            return $this->genResponse(0, 400, $client, 'A los usuarios del sistema no se le pueden crear reservaciones');
        }



        return $this->genResponse(1, 200, $client);
    }



    public function searchClientsByEmailOrPhone(string $emailorphone)

    {

        $manager = auth()->user();

        Log::info('email : ' . $emailorphone);



        $validator = Validator::make(

            ['email' => $emailorphone],

            ['email' => 'required']

        );



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);
        }

        $client = $this->clientService->findByRestaurantAndEmail($manager->restaurant_id, $emailorphone);

        if (!$client) {

            return $this->genResponse(0, 404);
        }



        if (isset($client['status'])) {

            return $this->genResponse(0, 400, $client, 'A los usuarios del sistema no se le pueden crear reservaciones');
        }



        return $this->genResponse(1, 200, $client);
    }



    /**

     * @group Restaurante clientes

     *

     * Show client

     *

     * [Regresa el detalle de el cliente, la informacion que se envie dependera de el tipo de cliente]

     *

     * @urlParam type required el tipo de cliente Example:puerta21

     * @urlParam encrypt_id required el id de cliente

     *

     * @param mixed $type

     * @param mixed $encrypt_id

     */

    public function show($type, $encrypt_id)

    {

        Log::debug("Show");



        if ('puerta21' !== $type && 'general-public' !== $type) {

            return $this->genResponse(0, 404);
        }



        $restaurantId = auth()->user()->restaurant_id;



        $client = $this->clientService->findByIdAndTypeWithRestaurantInfo($this->getDecrypted($encrypt_id), $restaurantId, $type);



        if (!$client) {

            return $this->genResponse(0, 404);
        }



        return $this->genResponse(1, 200, $client);
    }



    /**

     * @group Restaurante clientes

     * Search clients

     *

     * [Regresa los clientes filtrados por el typo de clientes y el nombre]

     *

     * @urlParam type required el tipo de cliente Example:puerta21

     * @urlParam search required el valor con el cual buscar por nombre

     *

     * @queryParam page La pagina  Example:1

     * @queryParam pagesize El tamaño de la pagina por omisión el tamaño es 15 Example:12

     *

     * @param mixed $type

     * @param mixed $search

     */

    public function searchClients(Request $request, $type, $search = '')

    {

        $pageSize = $request->query('pagesize', 15);

        Log::info('url parameters', ['type' => $type, 'search' => $search, 'pagesize' => $pageSize]);



        if ('puerta21' !== $type && 'general-public' !== $type) {

            return $this->genResponse(0, 404);
        }
        $restaurantId = auth()->user()->restaurant_id;
        $data = $this->clientService->serchClientsByRestaurantIdAndType($type, $search, $restaurantId, $pageSize);
        return $this->genResponse(1, 200, $data);
    }



    /**

     * @group Restaurante clientes

     *

     * Export clients

     *

     * [Regresa un csv con los clientes segun su tipo busqueda u orden]

     *

     * @urlParam type required el tipo de cliente Example:puerta21

     * @urlParam search required el valor con el cual buscar por nombre

     */

    public function export(Request $request, $type, $search = '')

    {

        $pageSize = $request->query('pagesize', 15);

        Log::info('url parameters', ['type' => $type, 'search' => $search, 'pagesize' => $pageSize]);



        if ('puerta21' !== $type && 'general-public' !== $type) {

            return $this->genResponse(0, 404);
        }



        $restaurantId   = auth()->user()->restaurant_id;

        $data           = $this->clientService->getDataToExportByRestaurantIdAndType($restaurantId, $type, $search, null);

        $type_title     = ($type == 'general-public') ? 'Público en general' : 'Puerta 21';

        return (new ClientsExport($data, $type_title));
    }



    /**

     * @group Restaurante clientes

     *

     * Edit restaurant client preferences

     *

     * [Edita las preferecias que tiene el cliente del restaurante]

     *

     */
    //
    public function editClientData(Request $request, $id)
    {
        return $request;
        $clientId = $this->getDecrypted($id);
    }
    public function editRestaurantPreferences(EditClientRestaurantPreferences $request, $id)

    {

        $restaurantId = auth()->user()->restaurant_id;



        $data = $request->validated();

        Log::debug("Data" . json_encode($data));

        $clientId = $this->getDecrypted($id);


        //caso particular de editar la fecha desde las preferencias client_edit
        if ($request->birthday_date) {

            $client=Client::findOrFail($clientId);

            if (!$client) {
 
                $response = ['status' => 404, 'message' => 'No existe el cliente'];
            }else{
                $client->birthday_date = $request->birthday_date;
                $client->save();
                $response = ['status' => 200, 'message' => 'Información actualizada correctamente'];
            }


        } else {

            $response = $this->clientService->updateRestaurantClientPreferences($restaurantId, $clientId, $data);
        }


        return $this->genResponse((int)($response['status'] === 200), $response['status'], null, $response['message']);
    }



    /**

     * @group Restaurante clientes

     *

     * Editar categoria del Cliente

     *

     * [Actualiza las categoria de un cliente]

     *

     * @bodyParam client_eid El id encryptado del cliente

     * @bodyParam category_eid El id encryptado de la categoria

     * @bodyParam status El status de la categoria

     *

     * @param mixed $client_eid

     * @param mixed $category_eid

     * @param boolean $status

     */

    public function editRestaurantCategory(EditClientRestaurantCategory $request)

    {

        $restaurantId = auth()->user()->restaurant_id;



        $data = $request->validated();



        Log::debug("Data" . json_encode($data));



        $clientId   = $this->getDecrypted($request->client_eid);

        $categoryId = $this->getDecrypted($request->category_eid);



        $response = $this->clientService->updateRestaurantClientCategory($restaurantId, $clientId, $categoryId, $request->status);



        return $this->genResponse((int)($response['status'] === 200), $response['status'], null, $response['message']);
    }

    public function clientsAll(Request $request, $pages, $type)

    {

        if ('puerta21' !== $type && 'general-public' !== $type) {
            return $this->genResponse(0, 404);
        }
        $manager = auth()->user();
    
        $pageSize = $pages * 100;
    
        $orderBy = str_replace('+', ' ', $request->query('orderBy', ''));
    
        $clients = $this->clientService->getClientsByRestaurantIdAndType($manager->restaurant_id, $type, $pageSize, $orderBy);
        return $this->genResponse(1, 200, $clients);
    }

    public function updateNutritionalReq(Request $request)

    {

        //TODO Update

        $client = Client::where('encrypt_id', $request->id)->first();

        foreach ($request->data as $item) {

            $nutritional_requirement = NutritionalRequirement::where('name', $item['key'])->first();

            if ($item['boolean'] == true) {

                DB::table('t_client_nutritional_requirements')->where('client_id', $client->id)->where('nutritional_requirement_id', $nutritional_requirement->id)->delete();

                DB::table('t_client_nutritional_requirements')->insert(

                    ['client_id' => $client->id, 'nutritional_requirement_id' => $nutritional_requirement->id]

                );
            } else {



                DB::table('t_client_nutritional_requirements')->where('client_id', $client->id)->where('nutritional_requirement_id', $nutritional_requirement->id)->delete();
            }
        }

        return $this->genResponse(1, 200, $nutritional_requirement->encrypt_id);
    }

    public function updateNames(Request $request)
    {

        $client = Client::where('encrypt_id', $request->id)->first();
        if ($client->id == 1) {
            return $this->genResponse(1, 400, ['errors' => 'No se puede editar un cliente sin reserva / walk-in']);
        }
        if ($request->phone != "") {
            $count = Client::where('cell_phone', $request->phone)->get()->count();

            if ($count > 0) {
                return $this->genResponse(1, 400, ['errors' => 'El número de teléfono que marcó corresponde a otro cliente, por favor ponga un número de teléfono diferente para cada usuario']);
            } else {
                $client->cell_phone = $request->phone;
                $client->save();
            }
        }
        if ($request->name != "") {
            $client->first_name = $request->name;
            $client->save();
        }
        if ($request->mname != "") {
            $client->middle_name = $request->mname;
            $client->save();
        }
        if ($request->lname != "") {
            $client->last_name = $request->lname;
            $client->save();
        }

        return $this->genResponse(1, 200,  $client->encrypt_id, 'ok');
    }
    public function updateDrinks(Request $request)

    {

        //TODO Update

        $client = Client::where('encrypt_id', $request->id)->first();

        foreach ($request->data as $item) {

            $drink = Drink::where('name', $item['key'])->first();

            if ($item['boolean'] == true) {

                DB::table('t_client_drinks')->where('client_id', $client->id)->where('drink_id', $drink->id)->delete();

                DB::table('t_client_drinks')->insert(

                    ['client_id' => $client->id, 'drink_id' => $drink->id]

                );
            } else {



                DB::table('t_client_drinks')->where('client_id', $client->id)->where('drink_id', $drink->id)->delete();
            }
        }

        return $this->genResponse(1, 200, $drink->encrypt_id);
    }

    public function updateAllergies(Request $request)

    {

        //TODO Update

        $client = Client::where('encrypt_id', $request->id)->first();

        foreach ($request->data as $item) {

            $allergy = Allergy::where('name', $item['key'])->first();

            if ($item['boolean'] == true) {

                DB::table('t_client_allergies')->where('client_id', $client->id)->where('allergy_id', $allergy->id)->delete();

                DB::table('t_client_allergies')->insert(

                    ['client_id' => $client->id, 'allergy_id' => $allergy->id]

                );
            } else {



                DB::table('t_client_allergies')->where('client_id', $client->id)->where('allergy_id', $allergy->id)->delete();
            }
        }

        return $this->genResponse(1, 200, $allergy->encrypt_id);
    }

    public function updateTables(Request $request)

    {

        //TODO Update

        $client = Client::where('encrypt_id', $request->id)->first();

        foreach ($request->data as $item) {

            $table = Table::where('name', $item['key'])->first();

            if ($item['boolean'] == true) {

                DB::table('t_client_tables')->where('client_id', $client->id)->where('table_id', $table->id)->delete();

                DB::table('t_client_tables')->insert(

                    ['client_id' => $client->id, 'table_id' => $table->id]

                );
            } else {



                DB::table('t_client_tables')->where('client_id', $client->id)->where('table_id', $table->id)->delete();
            }
        }

        return $this->genResponse(1, 200, $table->encrypt_id);
    }
}
