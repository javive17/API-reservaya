<?php

namespace App\Http\Controllers\API\Restaurant;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreStaff;
use App\Http\Requests\EditStaff;
use App\Http\Requests\UpdatePassword;
use App\Services\Restaurant\StaffServiceInterface;
use Illuminate\Http\Request;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use Illuminate\Support\Facades\Log;
use App\Models\Catalogs\Role;

/**
 * @group Restaurant staff
 */
class StaffController extends Controller
{
    use GeneralResponse;
    use AuxiliarFunctions;

    /** @var StaffServiceInterface */
    private $staffService;

    public function __construct(
        StaffServiceInterface $staffService
    ) {
        $this->staffService = $staffService;
    }

    /**
     * Store.
     *
     * [Crea personal para el restaurante]
     */
    public function store(StoreStaff $request)
    {
        $data = $request->validated();

        if(!Role::find($data['role_eid'])){
            return $this->genResponse(0, 404, null,'No existe el rol enviado');
        }

        if(!in_array($data['role_eid'],$this->back_office)){
            return $this->genResponse(0, 400, null,'El rol no pertenece al staff');
        }

        $manager = auth()->user();

        return $this->staffService->store($manager->restaurant_id, $data['role_eid'], $data['email'], $data['password']);
    }

    /**
     * Staff.
     *
     * [Regresa una lista de todo el personal del restaurante. El personal se puede filtrar mediante el correo]
     *
     * @urlparam email string El correo por el que se quiere filtrar al personal
     *
     * @param null|mixed $email
     */
    public function index(Request $request)
    {
        $manager = auth()->user();
        $email = $request->query('email', null);
        Log::info('search by email == > ' . $email);
        $pageSize = $request->query('pagesize', 10);
        return $this->staffService->getByRestaurantIdPaginated($manager->restaurant_id,$pageSize,$email);
    }

    /**
     * Edit.
     *
     * [Editar personal del restaurante]
     */
    public function edit(EditStaff $request, $id)
    {
        $data = $request->validated();

        if (isset($data['role_eid'])) {
            if(!Role::find($data['role_eid'])){
                return $this->genResponse(0, 404, null,'No existe el rol enviado');
            }

            if(!in_array($data['role_eid'],$this->back_office)){
                return $this->genResponse(0, 400, null,'El rol no pertenece al staff');
            }
        }
        
        $manager = auth()->user();

        return $this->staffService->update($manager->id, $id, $data);
    }

    /**
     * Delete.
     *
     * [Eliminar personal del restaurante]
     */
    public function delete($id){
        $manager = auth()->user();

        return $this->staffService->delete($manager->id,$id);
    }

    /**
     * Show.
     *
     * [Detalle del personal del restaurante]
     */
    public function show($id){
        return $this->staffService->show($id);
    }

    /**
     * Update password.
     *
     * [Actualizar contraseña]
     */
    public function updatePassword(UpdatePassword $request)
    {
        $data = $request->validated();

        return $this->staffService->updatePassword($data);
    }
}
