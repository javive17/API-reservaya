<?php



namespace App\Http\Controllers\API\Restaurant;



use App\Http\Controllers\Controller;

use App\Http\Requests\UpdateRestaurantCapacity;

use App\Http\Requests\UpdateRestaurantDescription;

use App\Http\Requests\UpdateRestaurantPhoto;

use App\Models\Table;

use App\Models\Catalogs\{Cost, TableType, Day, ExtraService, Kitchen};

use App\Repositories\RestaurantPhotoRepositoryInterface;

use App\Repositories\RestaurantRepositoryInterface;

use App\Traits\AuxiliarFunctions;

use App\Traits\GeneralResponse;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\DB;
use App\Models\Offer;

/**

 * @group Restaurant updates

 */

class RestaurantUpdateController extends Controller

{

    use GeneralResponse;

    use AuxiliarFunctions;



    /** @var RestaurantRepositoryInterface */

    private $repository;



    /** @var RestaurantPhotoRepositoryInterface */

    private $repository1;



    public function __construct(

        RestaurantRepositoryInterface $repository,

        RestaurantPhotoRepositoryInterface $repository1

    ) {

        $this->repository = $repository;

        $this->repository1 = $repository1;
    }

/*
example request
{
    "hasOffers": 1,
    "title": "20% en vino",
    "description": "En diciembre tenemos 20% de vino",
    "startDate": "2023-12-30 00:00:00",
    "endDate": "2023-12-31 00:00:00",
    "type": "oferta",
    "dates": "[1702403898185,1703181498185,1703527098185]",
    "repeat": false,
    "monday": false,
    "tuesday": false,
    "wednesday": true,
    "thursday": true,
    "friday": false,
    "saturday": false,
    "sunday": false
}*/

    public function offer(Request $request)

    {
        $restaurantId = auth()->user()->restaurant_id;
        $offer = Offer::where('restaurant_id', $restaurantId)->first();

        if ($request->hasOffers == 1) {
            //create or update the offer where restaurant_id = auth()->user()->restaurant_id
            $success = DB::table('t_restaurants')->where('id', $restaurantId)->update(['offers' => 1]);
            if ($offer) {
                $offrt = Offer::find($offer->id);
                $offrt->title = $request->title;
                $offrt->description = $request->description;
                //stard date
                $offrt->start_date = $request->startDate;
                //end date
                $offrt->end_date = $request->endDate;
                //type
                $offrt->type = $request->type;
                   //week days as 0 or 1
                   $offrt->monday = $request->monday;
                   $offrt->tuesday = $request->tuesday;
                   $offrt->wednesday = $request->wednesday;
                   $offrt->thursday = $request->thursday;
                   $offrt->friday = $request->friday;
                   $offrt->saturday = $request->saturday;
                   $offrt->sunday = $request->sunday;
                   //dates
                   $offrt->dates = $request->dates;
                   //repeat
                   $offrt->repeats = $request->repeat;
                $offrt->save();
            } else {
                $offrt = new Offer();
                $offrt->restaurant_id = $restaurantId;
                $offrt->title = $request->title;
                $offrt->description = $request->description;
                //stard date
                $offrt->start_date = $request->startDate;
                //end date
                $offrt->end_date = $request->endDate;
                //type
                $offrt->type = $request->type;
                //week days as 0 or 1
                $offrt->monday = $request->monday;
                $offrt->tuesday = $request->tuesday;
                $offrt->wednesday = $request->wednesday;
                $offrt->thursday = $request->thursday;
                $offrt->friday = $request->friday;
                $offrt->saturday = $request->saturday;
                $offrt->sunday = $request->sunday;
                //dates
                $offrt->dates = $request->dates;
                //repeat
                $offrt->repeats = $request->repeat;


                $offrt->save();
            }
        } else {

            $success = DB::table('t_restaurants')->where('id', $restaurantId)->update(['offers' => 0]);
            if ($offer) {
                $offrt = Offer::find($offer->id);
                $offrt->delete();
            }
        }
        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }


    /**

     * Description.

     *

     * [Actualiza la descripción del restaurante]

     */
    public function sector(Request $request)
    {
        $rules = ['sector_id' => 'required'];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->genResponse(1, 401, $validator->errors());
        }

        $restaurantId = auth()->user()->restaurant_id;
        //$success = $this->repository->update(['sector_id' => $request->sector], $restaurantId);
        //use DB:: to update the sector_id
        $success = DB::table('t_restaurants')->where('id', $restaurantId)->update(['sector_id' => $request->sector_id]);
        return $this->genResponse(1, 200, null, "Información actualizada correctamente.");
    }

    public function description(UpdateRestaurantDescription $request)

    {

        $data = $request->validated();

        if (empty($data)) {

            return $this->genResponse(1, 200, $data);
        }

        $restaurantId = auth()->user()->restaurant_id;

        if (isset($data['address'])) {

            $this->repository->updateAddress($restaurantId, $data['address']);

            unset($data['address']);
        }

        if (isset($data['paymentMethod'])) {
            $data['payment_method'] = $data['paymentMethod'];
            unset($data['paymentMethod']);
            $this->repository->update($data, $restaurantId);
        } else {
            $this->repository->update($data, $restaurantId);
        }

        $this->repository->validateRestaurant($restaurantId);



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }



    /**

     * Delete Photos.

     *

     * [Eliminar la photo del restaurante]

     * 

     * @bodyParam photo_eid El id encryptado de la foto

     *

     * @param mixed $photo_eid

     * 

     */

    public function deletePhotos(Request $request)

    {

        $validator = Validator::make($request->all(), ['photo_eid' => 'required']);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }



        $photoId = $this->getDecrypted($request->photo_eid);



        $manager = auth()->user();



        $response = $this->repository->deletePhoto($manager->restaurant_id, $photoId);



        return $this->genResponse((int)($response['status'] === 200), $response['status'], null, $response['message']);
    }



    /**

     * Capacity.

     *

     * [Actualiza la capacidad del restaurante, es decir el número de personas

     * que pueden entrar en determinada zona del restaurante]

     */

    public function capacity(UpdateRestaurantCapacity $request)

    {

        $data = $request->validated();



        $restaurantId = auth()->user()->restaurant_id;



        $table_type_ids = $request->capacity;

        $ids = [];

        foreach ($table_type_ids as $key => $value) {

            $table_type_id = $this->getDecrypted($value['table_type_eid']);


            $tablet = TableType::find($table_type_id);
            if (!$tablet) {

                return $this->genResponse(0, 404, null, 'No existe el restaurante solicitado');
            } else {
                $tablet->exclusive = $value['exclusive'];
                $tablet->save();
            }

            array_push($ids, $table_type_id);

            $table_type_ids[$key]['table_type_id'] = $table_type_id;
        }



        $this->repository->createUpdateCapacity($restaurantId, $table_type_ids, $ids);



        $this->repository->validateRestaurant($restaurantId);



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }



    /**

     * Menu.

     *

     * [Actualiza la url del menu del restaurante]

     * 

     * @bodyParam menu_url La url del menu

     *

     * @param mixed $menu_url

     */

    public function menu(Request $request)

    {

        $rules = ['menu_url' => 'required|string|url'];

        $validator = Validator::make($request->all(), $rules);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }

        $restaurantId = auth()->user()->restaurant_id;
        $url = $request->link_url;
        $menu_especial_url = $request->specialmenu_url;
        $success = $this->repository->update(['menu_url' => $request->menu_url, 'link_url' => $url, 'menu_especial_url' => $menu_especial_url], $restaurantId);



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }

    public function automatic(Request $request)

    {

        $rules = ['vautomatic' => 'required', 'visAutomatic' => 'required'];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }
        $restaurantId = auth()->user()->restaurant_id;

        $success = $this->repository->update(['automatic_reservations' => $request->vautomatic, 'accept_automatic_reservation' => $request->visAutomatic], $restaurantId);
        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }


    /**

     * Costo.

     *

     * [Actualiza la rango de precio del restaurante]

     * 

     * @bodyParam cost_eid El id encryptado del costo

     *

     * @param mixed $cost_eid

     */

    public function cost(Request $request)

    {

        $rules = ['cost_eid' => 'required'];

        $validator = Validator::make($request->all(), $rules);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }



        $costId = $this->getDecrypted($request->cost_eid);



        $restaurantId = auth()->user()->restaurant_id;



        $cost = Cost::find($costId);



        if (!$cost) {

            return $this->genResponse(0, 404, null, 'No existe el costo');
        }



        $success = $this->repository->update(['cost_id' => $costId], $restaurantId);



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }



    /**

     * Servicios extras.

     *

     * [Actualiza los servicios extras del restaurante]

     * 

     * @bodyParam extra_service_eid El id encryptado del servicio extra

     * @bodyParam status El del servicio extra

     *

     * @param mixed $extra_service_eid

     * @param boolean $status

     */

    public function extraService(Request $request)

    {

        $rules = ['extra_service_eid' => 'required', 'status' => 'required|boolean'];

        $validator = Validator::make($request->all(), $rules);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }



        $extraServiceId = $this->getDecrypted($request->extra_service_eid);



        $restaurantId = auth()->user()->restaurant_id;



        $extra_service = ExtraService::find($extraServiceId);



        if (!$extra_service) {

            return $this->genResponse(0, 404, null, 'No existe el setvicio extra');
        }



        DB::table('t_restaurants_extra_services')->updateOrInsert(
            ['restaurant_id' => $restaurantId, 'extra_service_id' => $extraServiceId],

            ['status' => $request->status]

        );



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }



    /**

     * Kitchens.

     *

     * [Actualiza las cocinas del restaurante]

     * 

     * @bodyParam kitchen_eid El id encryptado de la cocina

     * @bodyParam status El del servicio extra

     *

     * @param mixed $kitchen_eid

     * @param boolean $status

     */

    public function kitchen(Request $request)

    {

        $rules = ['kitchen_eid' => 'required', 'status' => 'required|boolean'];

        $validator = Validator::make($request->all(), $rules);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }



        $kitchenId = $this->getDecrypted($request->kitchen_eid);



        $restaurantId = auth()->user()->restaurant_id;



        $kitchen = Kitchen::find($kitchenId);



        if (!$kitchen) {

            return $this->genResponse(0, 404, null, 'No existe la cocina');
        }



        DB::table('t_restaurants_kitchens')->updateOrInsert(
            ['restaurant_id' => $restaurantId, 'kitchen_id' => $kitchenId],

            ['status' => $request->status]

        );



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }



    /**

     * Días de servicios.

     *

     * [Actualiza los dias de servicio del restaurante]

     * 

     * @bodyParam service_days.*.service_eid id required

     * @bodyParam service_days.*.opening time required

     * @bodyParam service_days.*.closing time required

     * @bodyParam service_days.*.status booelan required

     *

     * @param mixed $service_eid

     * @param mixed $opening

     * @param mixed $closing

     * @param boolean $status

     */

    public function serviceDays(Request $request)

    {

        $rules_primary      = ['service_days' => 'required|array'];

        $rules_secondary    = ['day_eid' => 'required', 'opening' => 'required|date_format:H:i:s', 'closing' => 'required|date_format:H:i:s', 'status' => 'required|boolean', 'breakEnd' => 'required|date_format:H:i:s', 'breakStart' => 'required|date_format:H:i:s'];

        $validator          = Validator::make($request->all(), $rules_primary);



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());
        }



        $data = $request->all();



        foreach ($data['service_days'] as $key => $value) {

            $validator = Validator::make($value, $rules_secondary);

            if ($validator->fails()) {

                return $this->genResponse(1, 401, $validator->errors());
            }

            $dayId = $this->getDecrypted($value['day_eid']);



            $day = Day::find($dayId);



            if (!$day) {

                return $this->genResponse(0, 404, null, 'No existe el day enviado');
            }

            $data['service_days'][$key]['day_id'] = $dayId;
        }



        $restaurantId = auth()->user()->restaurant_id;



        $this->repository->createUpdateServiceDay($restaurantId, $data);



        $this->repository->validateRestaurant($restaurantId);



        return $this->genResponse(1, 200, null, "Información actualizada correctamente");
    }
}
