<?php



namespace App\Http\Controllers\API\Restaurant;



use Illuminate\Http\Request;

use App\Traits\{GeneralResponse, Notification, AuxiliarFunctions};

use App\Models\Catalogs\TableType;
use App\Models\User;
use App\Models\Reservation;
use App\Models\Table;
use App\Models\ReservationBlocked;
use App\Models\PardepanBlocked;
use App\Models\Client;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Log;


use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Validator;

use App\Http\Requests\EditRestaurantReservation;

use App\Http\Requests\StoreRestaurantReservation;

use App\Services\Restaurant\ClientServiceInterface;

use App\Http\Requests\ReservationAvailabilityRequest;

use App\Http\Requests\ReservationChangeStatusRequest;

use App\Services\Restaurant\ReservationServiceInterface;

use App\Mail\AcceptReservation;

use App\Mail\CancelledReservation;


use Carbon\Carbon;

use Illuminate\Support\Facades\Mail;

use App\Jobs\SendNotifications;

/**

 *  @group Restaurant reservation

 */

class ReservationController extends Controller

{

    use AuxiliarFunctions, GeneralResponse, Notification;



    /** @var ReservationServiceInterface */

    private $reservationService;



    /** @var ClientServiceInterface */

    private $clientService;



    public function __construct(

        ReservationServiceInterface $reservationService,

        ClientServiceInterface $clientService

    ) {

        $this->reservationService = $reservationService;

        $this->clientService = $clientService;
    }

    public function  estadisticaClientes($fecha){
        //fecha is is a year i need to get all the reservations of that year, by month but from all restaurants
        $year = $fecha;
        $month = 1;
        $old = 0;
        $new = 0;
        //for each month get the total of reservations
        while ($month <= 12) {
            $old = $this->estadisticaoldclients($year, $month);
            $new = $this->estadisticanewclients($year, $month);
        

            $data[] = [
                'month' => $month,
                'old' => $old,
                'new' => $new,
                'total' => $old + $new,
            ];
            $month++;
        }
        return $this->genResponse(1, 200, $data);

    }

    public function  estadisticaoldclients($year, $month)
    {
        $reservations = Reservation::join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->whereMonth('reservation_date', $month)
            ->whereYear('reservation_date', $year)
            ->whereDate('t_clients.created_at', '<', $year . '-' . $month . '-01');

            //select only those where date client.created_at is before month and year



        $count = $reservations->get()->count();
        return $count;
    }
    public function  estadisticanewclients($year, $month)
    {
      
        $reservations = Reservation::join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->whereMonth('reservation_date', $month)
            ->whereYear('reservation_date', $year)
            //select only those where client.created_at is on the same month and year
            ->whereMonth('t_clients.created_at', $month)
            ->whereYear('t_clients.created_at', $year);

        $count = $reservations->get()->count();
        return $count;
    }
    public function categorieClientes($id)
    {
    $clients = client::where('encrypt_id', $id)->pluck('user_id');
    $email = User::where('id', $clients)->pluck('email');
    return $email;
    }

    public function reservationsHowMany(Request $request)
    {
       

        $dateStart = $request->route('date_start');
            $dateEnd = $request->route('date_end');

            // Validar y formatear $dateStart
            $dateStart = date('Y-m-d', strtotime($dateStart));
            if ($dateStart === false) {
                // Manejar el caso de fecha inválida
            }

            // Validar y formatear $dateEnd
            $dateEnd = date('Y-m-d', strtotime($dateEnd));
            if ($dateEnd === false) {
                // Manejar el caso de fecha inválida
            }

  
        
        $platforms = ['reservaya_a', 'pardepan'];
        $reservationCounts = [
            'canceled_rechazada' => Reservation::whereHas('client', function ($query) use ($platforms) {
                $query->whereIn('t_clients.platform', $platforms);
            })
            ->whereIn('reservations_status_id', [8])
            ->whereBetween('reservation_date', [$dateStart, $dateEnd]) // Filtrar por fechas
            ->count(),
            
            'canceled' => Reservation::whereHas('client', function ($query) use ($platforms) {
                $query->whereIn('t_clients.platform', $platforms);
            })
            ->whereIn('reservations_status_id', [5,8])
            ->whereBetween('reservation_date', [$dateStart, $dateEnd]) // Filtrar por fechas
            ->count(),
            'canceled_client' => Reservation::whereHas('client', function ($query) use ($platforms) {
                $query->whereIn('t_clients.platform', $platforms);
            })
            ->whereIn('reservations_status_id', [7])
            ->whereBetween('reservation_date', [$dateStart, $dateEnd]) // Filtrar por fechas
            ->count(),
            'completed' => Reservation::whereHas('client', function ($query) use ($platforms) {
                $query->whereIn('t_clients.platform', $platforms);
            })
            ->whereIn('reservations_status_id', [2, 3, 9])
            ->whereBetween('reservation_date', [$dateStart, $dateEnd]) // Filtrar por fechas
            ->count(),
            'pending' => Reservation::whereHas('client', function ($query) use ($platforms) {
                $query->whereIn('t_clients.platform', $platforms);
            })
            ->whereIn('reservations_status_id', [1, 6])
            ->whereBetween('reservation_date', [$dateStart, $dateEnd]) // Filtrar por fechas
            ->count()
            
        ];
        $cancelledCount = PardepanBlocked::whereRaw('DATE(reservation_date) = ?', [$dateStart, $dateEnd])->get();


        $data = [
            'reservationCountsts' => $reservationCounts,
            'cancelledCount' => $cancelledCount
        ];
    
        return $this->genResponse(1, 200, $data);
    }


    /**

     * Create reservation.

     *

     * [Crea una nueva reservación en el restaurante]

     *

     * @responseFile responses/restaurant/reservations-create-200.json

     * @responseFile 400 responses/restaurant/reservations-create-400.json

     * @responseFile 401 responses/unauthorized.json

     */


    public function create(StoreRestaurantReservation $request)

    {
       
       
        $data = $request->validated();

        if (!isset($data['client_id']) && !isset($data['client'])) {

            return $this->genResponse(1, 400, ['errors' => ['client' => 'El cliente o la informacion de un cliente son requeridos']]);
        }
        $categories = $this->getDecryptedArray($data['categories']);

        if (is_null($categories)) {

            return $this->genResponse(1, 400, ['errors' => ['categories' => 'deben ser ids validos']]);
        }

        Log::debug("categories " . json_encode($categories));


        $manager = auth()->user();

        if(isset($data['client_id'])){
            $clientId = $data['client_id'];
        
        }else{
    
            $clientId = $this->createClientFromReservation($data['client'], $manager->restaurant_id, $categories);
        }

        $tableId = $data['table_type_id'];



        $validator_table = TableType::find($tableId);



        if (!$validator_table) {

            return $this->genResponse(0, 400, null, 'No existe la table_type enviada');
        }

        // return $this->genResponse(0, 200, null,$data);

        $comments = isset($data['comments']) ? $data['comments'] : '';

        $tableNumber = isset($data['table_number']) ? $data['table_number'] : '';
        $type = isset($data['type']) ? $data['type'] : null;
        $type = isset($data['event']) ? $data['event'] : $type;
        //if event is 'event' then set the startdate and enddate
        if ($type == 'event') {
  
            $startDate = isset($data['startDate']) ? $data['startDate'] : null;
            $endDate = isset($data['endDate']) ? $data['endDate'] : null;
        } else {
            $startDate = null;
            $endDate = null;
        }
        $result = $this->reservationService->create($manager->restaurant_id, $clientId, $tableId, $data['number_people'], $data['date'], $comments, $tableNumber, $type, $startDate, $endDate, $manager->email);

        return $this->genResponse((int)($result['status'] == 200), $result['status'],  $result['data'], $result['message']);

        // return $this->genResponse(1, 200, $data);

    }


    public function WalkIn(Request $request)
    {


        $manager = auth()->user();
        $date = $request->date;
        $validdate = date('Y-m-d', strtotime($date));
        $reservation = new Reservation;
        $reservation->people = $request->number_people;
        $reservation->reservation_date = $date;
        $reservation->save();
        $reservation->encrypt_id =  encrypt($reservation->id);
        $reservation->client_id = 1;
        $table = Table::where('table_type_id', decrypt($request->table_type_id))->where('restaurant_id', $manager->restaurant_id)->first();
        $reservation->table_id = $table->id;
        $reservation->save();

        return $this->genResponse(1, 200, $reservation, 'ok');
    }

    /**

     * Reservation availability.

     *

     * [Regresa una lista de la disponibilidad de horarios por zonas del restaurante

     *  apartir de el dia, la hora y la cantidad de personas que queiren reservar]

     *

     * @responseFile responses/restaurant/reservations-availability-200.json

     * @responseFile 400 responses/restaurant/reservations-availability-400.json

     * @responseFile 401 responses/unauthorized.json

     */

    public function reservationAvailability(ReservationAvailabilityRequest $request)

    {

        $data = $request;
        $restaurantId = auth()->user()->restaurant_id;
        $stringDateTime = explode(' ', $data['date']);
        $people = $data['number_people'];
        $date = $stringDateTime[0];
        $hour = $stringDateTime[1];
        
        $salida = $this->reservationService->restauranCapacityBySchedule($restaurantId, $date, $hour, $people);






        return $this->genResponse(1, 200, $salida);
    }

    public function numberTotalPerMonth($year, $month)
    {
        $restaurantId = auth()->user()->restaurant_id;

        $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->where('t_tables.restaurant_id', $restaurantId)

            ->whereMonth('reservation_date', $month)

            ->whereYear('reservation_date', $year)

            ->select(
                'table_id',
                DB::raw('count(t_reservations.id) as num_reservations'),
                DB::raw("DATE_FORMAT(reservation_date, '%Y-%m-%d') as reservation_day"),
                't_tables.capacity',
                DB::raw('sum(people) as num_people'),
                't_reservations.type',
                't_reservations.reservations_status_id',
            )->groupBy('reservation_day', 'table_id')
            ->orderBy('reservation_day');

        $count1 = $reservations->Where('type', '=', 'waitinglist')->where('reservations_status_id', '=', 1)->get()->count();
        $count2 = $reservations->where('type', '=', 'pardepan')->where('reservations_status_id', '=', 6)->get()->count();

        //$total2    ->Where('type', '=', 'waitinglist')->where('reservations_status_id', '=', 1)
        //$total =   ->where('type', '=', 'pardepan')->where('reservations_status_id', '=', 6)
        return $count1 + $count2;
    }

    /**

     * Reservaciones.

     *

     * [Regresa una lista pagina de reservaciones por zona y fecha.

     * Si no se le pasa la fecha se tomara por omisión la fecha actual. \n

     * El servicio esta paginado, dependiendo de los url params, se le puede pasar page(el numero de pagina por omision es 1),

     * pagesize (el tamanio de la pagina por omicion es 10) y orderBy (orden por el cual se mostraran los registros).

     * En orderBy se le pueden pasar cualquiera de las siguientes columnas: 'categoria','nombre','asistentes','estatus', 'fecha'

     * ademas de agregar 'desc' si se quiere ver de forma descendente o dejarlo solo si se quiere ordenar de forma acendente

     * ]

     *

     * @urlParam zone required

     * [La zona del restaurante puede ser cualquiera de las siguientes:  all,bar,barra,salon-privado,interior,terraza] Example: terraza

     *

     * @urlParam date La fecha de las reservaciones que se quieren ver por omisión es la fecha actual Example:2021-07-18

     *

     * @queryParam page El numero de pagina  Example:1

     * @queryParam pagesize El tamaño de la pagina por omisión el tamaño es 10 Example:15

     * @queryParam orderBy El orden por columna (acendente o descendente)  Example:categoria,asistentes desc

     *

     *

     * @responseFile responses/restaurant/reservations-200.json

     * @responseFile 401 responses/unauthorized.json

     *

     * @param mixed      $zone

     * @param null|mixed $date

     */

    public function index(Request $request, $zone, $date = null, $hour = null)

    {

        $manager = auth()->user();

        $date = isset($date) ? $date : date('Y-m-d');

        $hour = "00:00";


        $pageSize = $request->query('pagesize', 10);

        $orderBy = str_replace('+', ' ', $request->query('orderBy', 'fecha asc'));

        $search = $request->query('search', '');




        $reservations = $this->reservationService->getReservationsByRestaurantId($manager->restaurant_id, $zone, $date, $hour, $pageSize, $orderBy, $search);


        return $this->genResponse(1, 200, $reservations);
    }


    public function indexfast(Request $request, $zone, $date = null, $hour = null)

    {

        $manager = auth()->user();

        $date = isset($date) ? $date : date('Y-m-d');

        $hour = "00:00";
        $pageSize = $request->query('pagesize', 100);

        $orderBy = str_replace('+', ' ', $request->query('orderBy', 'fecha asc'));

        $search = $request->query('search', '');

        $reservations = $this->reservationService->getReservationsByRestaurantId($manager->restaurant_id, $zone, $date, $hour, $pageSize, $orderBy, $search);
        //get count of reservations per month "pending"
        $dateUnix = strtotime($date);
        $total = $this->reservationsPerMonthTotal(date("Y", $dateUnix), date("m", $dateUnix));
 
        //get the list of reservations made for all day events
        $validdate = date('Y-m-d', strtotime($date));
        $allday = ReservationBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->where('status', 'ACTIVE')->get();
        $pardepanblocked = PardepanBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->where('restaurant_id', $manager->restaurant_id)->get();

        $cancelled = ReservationBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->where('status', 'CANCELLED')->get();
        $data2 = [

            'reservations'    => $allday,

            'cancelled' => $cancelled,

        ];
        $data = [
            'reservations' => $reservations,
            'total' => $total,
            'allDay' => $data2,
            'pardepanBlocked' => $pardepanblocked,
            'countAutomatic' => $this->countAutomatic(date("Y", $dateUnix), date("m", $dateUnix)),
            
        ];
        return $this->genResponse(1, 200, $data);
    }

    public function pardepanBlock(Request $request){

      
        $manager = auth()->user();
        $date = $request->input('date');
        $sd = $request->input('start_time');
        $ed = $request->input('end_time');
        //$hour = $request->input('hour');
        $pardepanBlocked = new  PardepanBlocked;
        $pardepanBlocked->restaurant_id = $manager->restaurant_id;
        $pardepanBlocked->reservation_date = $date;
     
        //dates are in format 06:17 PM
        $start_date = date('Y-m-d H:i:s', strtotime($date . ' ' . $sd));
      
        $end_date = date('Y-m-d H:i:s', strtotime($date . ' ' . $ed));
        $pardepanBlocked->start_time= $start_date;
        $pardepanBlocked->end_time= $end_date;

        //$pardepanBlocked->reservation_hour = $hour;
        $pardepanBlocked->save();
        $data = [
            'pardepanBlocked' => $pardepanBlocked,
        ];
        return $this->genResponse(1, 200, $data);
        
    }
    public function pardepanUnBlock(Request $request){

        $manager = auth()->user();
        $date = $request->input('date');
        //$hour = $request->input('hour');
        //remove al pardepan blocked that date
        
        $pardepanBlocked = PardepanBlocked::where('restaurant_id', $manager->restaurant_id)->where('reservation_date', $date);
        $pardepanBlocked->delete();
        $data = [
            'pardepanBlocked' => $pardepanBlocked,
        ];
        return $this->genResponse(1, 200, $data);
        
    }

    public function allDay(Request $request, $zone, $date = null, $hour = null)
    {

        $validdate = date('Y-m-d', strtotime($date));

        $reservations = ReservationBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->where('status', 'ACTIVE')->get();

        $cancelled = ReservationBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->where('status', 'CANCELLED')->get();



        $data = [

            'reservations'    => $reservations,

            'cancelled' => $cancelled,

        ];

        return $this->genResponse(1, 200, $data);
    }

    public function listImagen() {

        $banners = DB::table('t_banners')->get();

        return response()->json($banners);
    }



    /**

     * Change Status

     * [Cambia el estatus de la reservación

     *

     *  En espera puede cambiar a:

     *  Ha asistido

     *  No show

     *

     *  Ha asistido puede cambiar a:

     *  Se ha ido

     *

     *  No show no puede cambiar de estado

     *

     *  Cancelado se asigna cuando el usuario o el restaurante ha cancelado la reserva. No se puede cambiar de estatus

     * ]

     *

     *

     * @responseFile responses/restaurant/reservations-changeStatus-200.json

     * @responseFile 400 responses/restaurant/reservations-changeStatus-400.json

     * @responseFile 401 responses/unauthorized.json

     */

    public function changeStatus(ReservationChangeStatusRequest $request)

    {
        $user=auth()->user();
        $data = $request->validated();
        \Log::info($data);
        $reservationId = $this->getDecrypted($data['reservation_id']);
        $reservation = Reservation::find($reservationId);
        $group_type=  $reservation->table->restaurant->group_type;
   
        $phone = $reservation->client->cell_phone;
        $name = $reservation->client->first_name.' '.  $reservation->client->middle_name;
       
        if ($reservation->client->platform == 'pardepan') {
            $convert_restaurant_name = str_replace(' ', '-', $reservation->table->restaurant->name);
            $name_image = $convert_restaurant_name . '.png';
            $url = 'https://pardepan.puerta21.club/images/rounded/' . $name_image;
            #verificar si existe la imagen
            $headers = get_headers($url);
            if (preg_match("/404/", $headers[0])) {
                $url = 'https://pardepan.puerta21.club/images/rounded/one-picture.png';
            }

            $data_user = (object) [
                'name' => $reservation->client->first_name,
                'full_name' => $reservation->client->full_name,
                'email' => $reservation->client->user->email,
            ];

            $data_reservation = (object) [
                'reservation_eid' => $reservation->encrypt_id,
                'restaurant' => $reservation->table->restaurant->name,
                'restaurant_group_type' => $reservation->table->restaurant->group_type,
                'image' => $url,
                'date' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
                'hour' => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
                'people' => $reservation->people,
            ];
            if ($data['status_id'] == 9) {

                $obj_send_notification = (object) [
                    'to' => $reservation->client_id,
                    'reservation_id' => $reservation->id,
                    'title' => '¡Reserva confirmada!',
                    'body' => '¡BUENAS NOTICIAS! Su reserva ha sido confirmada exitosamente!',
                ];
        
                //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
               // SendNotifications::dispatch($obj_send_notification)->delay(now()->addSeconds(3));

               // Mail::to($data_user->email)->send(new AcceptReservation($data_reservation, $data_user));
            } else if ($data['status_id'] == 8) {
                $obj_send_notification = (object) [
                    'to' => $reservation->client_id,
                    'reservation_id' => $reservation->id,
                    'title' => '¡Reservación cancelada!',
                    'body' => 'Oops! Sentimos comunicarle que no hay disponibilidad...',
                ];
        
                //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
                SendNotifications::dispatch($obj_send_notification)->delay(now()->addSeconds(3));

                Mail::to($data_user->email)->send(new CancelledReservation($data_reservation, $data_user));
            }
        }

        $statusId = $data['status_id'];

        $salida = $this->reservationService->updateReservationStatus($reservationId, $statusId, $user->email);
        
        /* send the whatsapp sms  */

        if ($phone != null && $phone !== '') {
  
            if ($data['status_id'] ==  8 || $data['status_id'] ==  5  ) {

if ( $group_type != 'ramero_solitario'){

                        $body =
"*ESTIMAD@* " . $name . ":

Sentimos comunicarle que no hay disponibilidad para los siguientes datos:
            ";
                    $body = $body . "
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Número de personas*: " . $reservation->people;

            
                    /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
                    $body = $body . "
            
Le invitamos a realizar una *nueva reserva a través del siguiente enlace*: www.reservaya.do";
            
                    $body = $body . "
            
Si desea realizar una consulta o modificar los detalles de su reserva, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.
            
Un cordial saludo,

Equipo Reserva Ya!
";

}

if ( $group_type == 'ramero_solitario'){

    $body =
"*ESTIMAD@* " . $name . ":

Sentimos comunicarle que no hay disponibilidad para los siguientes datos:
";
$body = $body . "
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Número de personas*: " . $reservation->people;


/*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
$body = $body . "

Le invitamos a realizar una *nueva reserva a través del siguiente enlace*: www.reservaya.do";

$body = $body . "

Si desea realizar una consulta o modificar los detalles de su reserva, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.

Un cordial saludo,

Equipo Reserva Ya!
";

}
$body = $body . "
*↓ ENGLISH ↓*";

if ( $group_type != 'ramero_solitario'){

                    $body = $body .

"

*Dear* " . $name . ":
            
We regret to inform you that there is no availability for the following details:
                        ";
                                $body = $body . "
• *Reservation Name*: " . $name . "
• *Restaurant*: " . $reservation->table->restaurant->name . "
• *Date*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
• *Time*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Number of people*: " . $reservation->people;
            
            $body = $body . "
            
We invite you to make a new reservation through the following link: www.reservaya.do";

            $body = $body . "
            
If you have any inquiries or wish to modify the details of your reservation, please contact the restaurant directly. This phone number does not answer calls or messages.

Best regards,

@ReservaYaRD
            
";
}


if ( $group_type == 'ramero_solitario'){

    $body = $body .
"

*DEAR* " . $name . ":

We regret to inform you that there is no availability for the following details:
";
$body = $body . "
• *Reservation Name*: " . $name . "
• *Restaurant*: " . $reservation->table->restaurant->name . "
• *Date*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y') . "
• *Time*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Number of people*: " . $reservation->people;


/*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
$body = $body . "

We invite you to make a new reservation through the following link: www.reservaya.do
";

$body = $body . "
If you have any inquiries or need to modify the details of your reservation, please contact the restaurant directly. This phone number does not answer calls or messages.
Best regards,

Reserva Ya! Team
";

}
                    $params = array(
                        'token' => 'ckrwcewisan28bw1',
                        'to' => $phone,
                        'body' => $body,
                    );
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => http_build_query($params),
                        CURLOPT_HTTPHEADER => array(
                            "content-type: application/x-www-form-urlencoded"
                        ),
                    ));
            
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
            
                    curl_close($curl);
            
                    if ($err) {
                        echo "cURL Error #:" . $err;
                    } else {
                        $params=array(
                            'token' => 'ckrwcewisan28bw1',
                            'to' => $phone,
                            'image' => 'https://api.puerta21.club/public/images/logor2.png',
        'caption' => 'https://reservaya.com.do'
                            );
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                              CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                              CURLOPT_RETURNTRANSFER => true,
                              CURLOPT_ENCODING => "",
                              CURLOPT_MAXREDIRS => 10,
                              CURLOPT_TIMEOUT => 30,
                              CURLOPT_SSL_VERIFYHOST => 0,
                              CURLOPT_SSL_VERIFYPEER => 0,
                              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                              CURLOPT_CUSTOMREQUEST => "POST",
                              CURLOPT_POSTFIELDS => http_build_query($params),
                              CURLOPT_HTTPHEADER => array(
                                "content-type: application/x-www-form-urlencoded"
                              ),
                            ));
                            
                            $response = curl_exec($curl);
                            $err = curl_error($curl);
                            
                            curl_close($curl);
                    }
                    //return $response;
                    }
                 
if( $statusId == 9 ){
   
if ( $group_type != 'farah'){
$body ="¡Buenas noticias " . $name . "!

Nos complace anunciarte que tu reserva en ".$reservation->table->restaurant->name." ha sido confirmada exitosamente 😊

📅 Fecha: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
🕒 Hora: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')."
👥 Número de personas: " . $reservation->people;
} 

if ( $group_type == 'farah'){
    $body = "
    
*¡BUENAS NOTICIAS!* Su reserva ha sido confirmada *exitosamente!* 😊
    
Estimado cliente por acá le compartimos nuestro menú. ".$reservation->table->restaurant->name." has been successfully confirmed
    
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Número de personas*: " . $reservation->people;   

} 

if($group_type == 'opera'){

$body = $body. "

Le esperamos 15 minutos después de la hora pautada, una vez trascurridos si no ha llegado el 50% de sus invitados la mesa estaría sujeta a disponibilidad.

Para grupos mayores de 10 personas el monto mínimo de consumo por persona es de 1800 DOP.

*No permitimos lo siguiente:*
* Velas de bengalas
* Alimentos o bebidas de otros establecimientos
* Sesiones fotográfica profesionales
* Mascotas";

}
if ( $group_type == 'lacasta')
{
    //🕐 Te recordamos que la validez de esta reserva es de 15 minutos después de la hora programada.                              
$body = $body. "

🕐 Te recordamos que la validez de esta reserva es de 15 minutos después de la hora programada.";

}
if ( $group_type == 'maraca' || $group_type == 'larimar')
{
$body = $body. "

📌 Por favor, evitar: 
- Gorras
- Escotes pronunciados
- Franelas
- Faldas y shorts muy cortos
- Bermudas 
- Chancletas 
- Ropa deportiva
- Jeans rotos

*POLÍTICA DE EVENTOS / CUMPLEAÑOS*
Si desea puede traer su bizcocho, este es permitido en la mesa únicamente al finalizar el servicio.

No permitimos lo siguiente:
* Velas de bengalas
* Individuales de mesa
* Centros de mesa
* Globos
* Arreglo de flores
* Sesiones fotográfica profesionales

🕐 Te recordamos que la validez de esta reserva es de 10 minutos después de la hora programada. Si no llegas con el 50% de tus invitados, la mesa estará sujeta a disponibilidad.";

}
if ( $group_type == 'farah')
{
$link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;



$body = $body. "


Es de su conocimiento  que debe de llegar el grupo completo para poder ocupar la mesa. Su tiempo  de espera es 15 minutos  después de la hora pautada para su reservación. Pasado el tiempo la mesa se le cederá a otro cliente.

Respetuosamente requerimos un código de vestimenta CASUAL. Queda bajo nuestra discreción el derecho de admisión.
 
No se permiten:
 
• BERMUDAS
• CHANCLETAS
• JEANS ROTOS
• CAMISA o TSHIRT de hombres SIN mangas
 
Por favor compartir esta información con las demás personas de su reserva. 

Si lo desea, siempre puede CANCELAR su reserva en 
";

}
if ( $group_type == 'noah')
{

$body = $body. "

Es de su conocimiento  que debe de llegar el grupo completo para poder ocupar la mesa. Su tiempo  de espera es 15 minutos  después de la hora pautada para su reservación. Pasado el tiempo la mesa se le cederá a otro cliente.

*Código de vestuario*

No se permiten:

- Gorras
- Jeans Rotos
- Escote pronunciado
- Transparencia
- Bermudas
- Camisetas
- Sandalia
- Shorts
Favor de compartir dicha información con sus invitados

✨*Información Salón Privado*✨

- Capacidad mínima: 10 personas 
- Capacidad máxima : 22 personas 
- Consumo mínimo : RD $ 30 mil pesos.

*Forma de pago*: Efectivo o tarjeta. 

*Depósito* 50% requerido para apartado de área privada

Puede traerse  pastel y decoración que no afecte el diseño del restaurante 
No se permite clavar o  pegar en el área privada. 

Para cotizaciones puede escribir a:

- noahrestaurantstgo@joklahen.com
- Noahrestaurant@hotmail.com";

}
if ( $group_type == 'meson-carne')
{
 $body = $body. "

Respetuosamente requerimos un código de vestimenta semi-formal o formal. Por favor comparta esta información con las otras personas en el grupo.

No permitimos: Gorras, franelas, chancletas, bermudas, escotes o aberturas de blusas y vestidos muy pronunciadas, jeans con rotos.

Favor de avisar en caso de traer cámaras profesionales, esto requiere autorización previa.

↓ *LOS DOMINGOS:* ↓

• El festín dominical es una actividad familiar que realizamos los domingos. Son varios platos llevados en cacerolas y en porciones acorde a las personas en la mesa. Está compuesto por aperitivos, platos fuertes y postres. 

• El precio del Festín dominical es por persona ($1,199 + 28% de impuestos = $1,534.72). 

• Niños: 0-4 no pagan / 5-9 la mitad.

• Horario: 12:00 - 4:00 P.M.

• No incluye bebidas.

• Menú: https://mybakarta.com/El-Meson-De-La-Cava/E9YpLX7uN61WOIh2717G
 ";


}
                                        
        if ( $group_type== 'casa_de_campo'){
$body = $body. "
*IMPORTANTE:* En caso de necesitar acceso al resort, por favor póngase en contacto con el restaurante vía limoncello888@hotmail.com";
        } 
                            
        if ( $group_type == 'peperoni_casa_de_campo') {      
 $body = $body. "
*IMPORTANTE:* Sólo y exclusivamente aquellos que son propietarios o invitados por un propietario podrán acceder al resort. La reserva sin previo acceso a Casa de Campo no es válida.";
        }
                            
        if ( $group_type == 'cap_cana') 
        {
$link = "https://reservaya.com.do/usuario/reservation/formulario/".$reservation->encrypt_id;
$body = $body. "
*IMPORTANTE:* Si no tiene acceso a Cap Cana, por favor, use el siguiente enlace ".$link." para completar su información y la de todos sus acompañantes para generar el código QR de acceso a Cap Cana. Su información será sólo compartida con la oficina de control de acceso a Cap Cana.";
        }
                            
        if ( $group_type == 'cap_cana_maralia'){
                                        
         //   $body = $body. "
//*IMPORTANTE:* Para visitantes no proprietarios / no residentes, existe un consumo mínimo de 50 USD por persona. Por favor, descárguese la siguiente aplicación para realizar el pago:
        
//1- IOS (App Store) https://apps.apple.com/us/app/cap-cana/id1451501100
//2- Android (Play Store) https://play.google.com/store/apps/details?id=co.xhinola.capcana.guests
//3- ( No es posible descargar el App desde computadora )";
        }
        $link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

if ( $group_type != 'meson-carne'){                                     
$body = $body. "

Le informamos que la vigencia de esta reserva son 10 minutos luego de la hora estipulada de la misma.

Si lo desea, siempre puede CANCELAR su reserva en el siguiente link: 

" .$link;
}
if ( $group_type == 'meson-carne'){                                     
    $body = $body. "    
    Si lo desea, siempre puede CANCELAR su reserva en " .$link;
    }
if ( $group_type == 'lalocanda')
{
$body = $body. "

•  La reserva se mantendrá por 15 minutos posteriores a la hora establecida. Pasado este tiempo quedará automáticamente cancelada, y se dará ingreso de acuerdo a la disponibilidad que maneje el restaurante en ese momento, por éste motivo le solicitamos ser puntual. 

•  Procure asistir con el número exacto de invitados que ha reservado para que no excedan la capacidad de los asientos asignados. Si resultan menos favor informar con antelación.

•  Favor respetar nuestro código de vestimenta que es casual o semiformal,no pantalones cortos o rotos, gorras y/o sandalias

•  La ubicación de las mesas se realiza de manera automática, de acuerdo con el orden de entrada de su reserva y la cantidad de personas de la misma.

";

}

                                    
if( $group_type == 'zuquero'){
$body = $body. "
Le informamos que debe llegar su grupo completo para concederles su mesa. 
                                        
Luego de 15 minutos pasados la hora de su reserva, la mesa será cedida.
                                        
Globos y pastel son permitidos en la mesa al momento de cantar cumpleaños.
                                        
Por favor le requerimos un código de vestimenta casual-elegante.
                                        
No se permiten:
- Sombreros
- Gorras
- Bermudas
- Chancletas
- T-Shirt sin mangas
- O bandas contratadas particularmente.
- Traer bebidas de ningun tipo.
                            
Por favor compartir esta información con las demás personas de su grupo y reserva. 
";
        
}
                                        
if( $group_type == 'botaniko'){
                                        
$body = $body. "    
Respetuosamente se requiere un código de vestimenta casual elegante.
Botaniko se reserva el derecho de seleccionar en la entrada.
                                        
No se permiten:
                           
- T-shirt o camisetas de hombre sin mangas                 
- Gorras    
- Bermudas               
- Jeans rotos                
- Escotes pronunciados                
- Faldas cortas                 
- Cinturas descubiertas                
- Chancletas  
        
Por favor compartir esta información con las demás personas de su grupo y reserva. ¡Le esperamos!";
                                        
        }
  

if( $group_type == 'peperoni')
        {
        $body = $body. "
Respetuosamente requerimos un código de vestimenta CASUAL ELEGANTE. Queda bajo nuestra discreción el derecho de admisión.
                            
No se permiten:
                      
- Gorras             
- Bermudas            
- Jeans rotos              
- Escotes pronunciados           
- Faldas cortas         
- Cinturas descubiertas            
- Chancletas                         
- Camisa o tshirt de hombres sin manga
                                        
Si no cumple con nuestro código de vestimenta, no se le permitirá la entrada ni permanecer en el establecimiento.

Por favor compartir esta información con las demás personas de su reserva. Le esperamos!";
        
}
                       
$body = $body. "

Si deseas modificar la reserva es decir: cambiar la hora, el día o número de personas y la reserva ya ha sido aceptada por el restaurante tendrás cancelar la reserva y volver a realizarla.
        
📞 Para consultas, te sugerimos contactar directamente al restaurante                                

¡Gracias por elegirnos!
 
@ReservaYaRD
";

$body = $body . "
*↓ ENGLISH ↓*";

if ( $group_type == 'farah')
{
    $link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

    $body = $body . "

*GOOD NEWS!* Your reservation has been successfully confirmed! 😊
        
Estimado cliente por acá le compartimos nuestro menú. ".$reservation->table->restaurant->name." has been successfully confirmed
        
* Reservation name:  " . $name . "
* Restaurant: " . $reservation->table->restaurant->name . "
* Date: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
* Time: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
* Number of people:" . $reservation->people;   


$body = $body. "


Please note that the entire group must arrive together in order to be seated. Your waiting time is 15 minutes after the scheduled reservation time. After this time, the table will be given to another customer.
 
We kindly request a CASUAL dress code. Admission is at our discretion.
 
The following are not allowed:

* SHORTS
* FLIP-FLOPS
* RIPPED JEANS
* MEN'S SHIRT or T-SHIRT without sleeves
 
Please share this information with the other members of your reservation.

If you wish, you can always CANCEL your reservation at your reservation at 
" . $link . "

If you have any inquiries or need to modify the details of your reservation, please contact the restaurant directly. This phone number does not answer calls or messages.

Best regards,

Reserva Ya! Team
";



}

if ( $group_type == 'meson-carne'){
    $body = $body . "
    
Good news  " . $name . "!
    
We are pleased to inform you that your reservation at  ".$reservation->table->restaurant->name." has been successfully confirmed 😊
    
📅 Date: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
🕒 Time: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')."
👥 Number of people: " . $reservation->people;
    
    } 

    if ( $group_type == 'cap_cana') 
    {

$body = $body . "
    
Good news  " . $name . "!
            
We are pleased to inform you that your reservation at  ".$reservation->table->restaurant->name." has been successfully confirmed 😊
            
📅 Date: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
🕒 Time: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')."
👥 Number of people: " . $reservation->people;
            
$link = "https://reservaya.com.do/usuario/reservation/formulario/".$reservation->encrypt_id;
$link2 = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

$body = $body. "

*IMPORTANT:* If you don't have access to Cap Cana, please use the following link  ".$link."  to complete your information and that of all your companions to generate the QR code for access to Cap Cana. Your information will only be shared with the Cap Cana access control office.

Please note that this reservation is valid for 10 minutes after the scheduled time.

If you wish, you can always CANCEL your reservation at 
" . $link2 . "

📞 For inquiries, we suggest contacting the restaurant directly.

Thank you for choosing us!

@ReservaYaRD

";

        
    }


if ( $group_type != 'meson-carne' && $group_type != 'farah' && $group_type != 'cap_cana' ){
$body = $body . "

Good news  " . $name . "!

We are pleased to inform you that your reservation at   ".$reservation->table->restaurant->name." has been successfully confirmed 😊

📅 Date: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
🕒 Time: ".Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')."
👥 Number of people: " . $reservation->people;

}

if ( $group_type == 'meson-carne')
{
 $body = $body. "

We kindly request a semi-formal or formal dress code. Please share this information with the other people in your group.

We do not allow: Caps, t-shirts, flip-flops, shorts, low-cut or revealing blouses and dresses, ripped jeans.

Please inform us in advance if you plan to bring professional cameras, as this requires prior authorization.

↓ *SUNDAYS:* ↓

• The Sunday feast is a family activity that we organize on Sundays. It consists of several dishes brought in casseroles and portions according to the number of people at the table. It includes appetizers, main courses, and desserts.

• The price of the Sunday feast is per person ($1,199 + 28% taxes = $1,534.72).

• Children: 0-4 years old don't pay / 5-9 years old pay half price.

• Hours: 12:00 - 4:00 P.M.

• Beverages are not included.

 ";


}

$link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

 if ( $group_type != 'meson-carne' && $group_type != 'farah' && $group_type != 'cap_cana'){

$body = $body. "

🕒We remind you that the validity of this reservation is 10 minutes after the stipulated time of the reservation.

If you wish, you can always CANCEL your reservation at 

" . $link;
} 
if ( $group_type != 'farah' && $group_type != 'cap_cana' ){
$body = $body. "

📞 For inquiries or modifications to the reservation, feel free to contact the restaurant directly.
   
Thank you for choosing us!
 
@ReservaYaRD

";
} 


         $params = array(
            'token' => 'ckrwcewisan28bw1',
            'to' => $phone,
            'body' => $body,
        );
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                                CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_ENCODING => "",
                                CURLOPT_MAXREDIRS => 10,
                                CURLOPT_TIMEOUT => 30,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                CURLOPT_CUSTOMREQUEST => "POST",
                                CURLOPT_POSTFIELDS => http_build_query($params),
                                CURLOPT_HTTPHEADER => array(
                                    "content-type: application/x-www-form-urlencoded"
                                ),
                            ));
                            
                            $response = curl_exec($curl);
                            $err = curl_error($curl);
                            
                            curl_close($curl);
                            
                            if ($err) {
                               //Log::debug("cURL Error #:" . $err);
                            
                            } else {

                                if ( $group_type == 'meson-carne')
                                {
                                    $image = 'https://api.puerta21.club/public/images/logor2.png';
                                    $caption = '';
                                }else{
                                $image = 'https://api.puerta21.club/public/images/logor2.png';
                                $caption ="https://reservaya.com.do";
                            }
                            
                                $params=array(
                                    'token' => 'ckrwcewisan28bw1',
                                    'to' => $phone,
                                    'image' => $image,
                                    'caption' => $caption
                                    );
                                    
                                    $curl = curl_init();
                                    curl_setopt_array($curl, array(
                                      CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                                      CURLOPT_RETURNTRANSFER => true,
                                      CURLOPT_ENCODING => "",
                                      CURLOPT_MAXREDIRS => 10,
                                      CURLOPT_TIMEOUT => 30,
                                      CURLOPT_SSL_VERIFYHOST => 0,
                                      CURLOPT_SSL_VERIFYPEER => 0,
                                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                      CURLOPT_CUSTOMREQUEST => "POST",
                                      CURLOPT_POSTFIELDS => http_build_query($params),
                                      CURLOPT_HTTPHEADER => array(
                                        "content-type: application/x-www-form-urlencoded"
                                      ),
                                    ));
                                    
                                    $response = curl_exec($curl);
                                    $err = curl_error($curl);
                                    
                                    curl_close($curl);
                                    
                            }  
                        }
                       if($statusId == 6){

                            
    
$body =
"*ESTIMAD@* " . $name . ":
                
Muchas gracias por realizar su reserva vía Reserva Ya! 😊
                
*Esta reserva no está confirmada*. En breves minutos le confirmaremos si hay disponibilidad para los siguientes datos:";
$body = $body . "
• *Nombre de la reserva*: " . $name . "
• *Restaurante*: " . $reservation->table->restaurant->name . "
• *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y')."
• *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
• *Número de personas*: " . $reservation->people;

                
                  
/*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
$link = "https://reservaya.com.do/usuario/reservation/formulario-cancelar/".$reservation->encrypt_id;

$body = $body . "
  
Si lo desea, siempre puede

CANCELAR o MODIFICAR su reserva en el siguiente link: 🔗 " . $link ;
                
$body = $body . "
                
Un cordial saludo,
                
Equipo Reserva Ya!
 ";
                        $params = array(
                            'token' => 'ckrwcewisan28bw1',
                            'to' => $phone,
                            'body' => $body,
                        );
                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                            CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => "",
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 30,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => "POST",
                            CURLOPT_POSTFIELDS => http_build_query($params),
                            CURLOPT_HTTPHEADER => array(
                                "content-type: application/x-www-form-urlencoded"
                            ),
                        ));
                
                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                
                        curl_close($curl);
                
                        if ($err) {
                            //echo "cURL Error #:" . $err;
                        } else {
                            
                            $params=array(
                                'token' => 'ckrwcewisan28bw1',
                                'to' => $phone,
                                'image' => 'https://api.puerta21.club/public/images/logor2.png',
                                 'caption' => 'https://reservaya.com.do'
                                );
                                $curl = curl_init();
                                curl_setopt_array($curl, array(
                                  CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                                  CURLOPT_RETURNTRANSFER => true,
                                  CURLOPT_ENCODING => "",
                                  CURLOPT_MAXREDIRS => 10,
                                  CURLOPT_TIMEOUT => 30,
                                  CURLOPT_SSL_VERIFYHOST => 0,
                                  CURLOPT_SSL_VERIFYPEER => 0,
                                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                  CURLOPT_CUSTOMREQUEST => "POST",
                                  CURLOPT_POSTFIELDS => http_build_query($params),
                                  CURLOPT_HTTPHEADER => array(
                                    "content-type: application/x-www-form-urlencoded"
                                  ),
                                ));
                                
                                $response = curl_exec($curl);
                                $err = curl_error($curl);
                                
                                curl_close($curl);
                        }

                       }
                    
                }
        return $this->genResponse((int) (200 == $salida['status']), $salida['status'], null, $salida);
    }



    /**

     * Edit

     * [Edita la reservación].

     *

     * @urlParam id required El id de la reservacion a editar

     *

     * @param mixed $id

     *

     */

    public function edit(EditRestaurantReservation $request, $id)

    {

        //return $this->genResponse(1, 200, null, 'Edita la reservación');
        $data = $request->validated();
        $user = auth()->user();
        Log::info('data ' . json_encode($data));

        if (empty($data)) {

            return $this->genResponse(0, 200, null, 'Nada que editar');
        }



        $table_id = $this->getDecrypted($request->table_type_eid);



        $validator_table = TableType::find($table_id);



        if (!$validator_table) {

            return $this->genResponse(0, 400, null, 'No existe la table enviada');
        }



        $reservation_id = $this->getDecrypted($id);

        $reservation = Reservation::where('id', $reservation_id)->first();



        if (!$reservation) {

            return $this->genResponse(0, 400, null, 'No existe la reservación enviada');
        }



        $comments = isset($data['comments']) ? $data['comments'] : $reservation->comments;



        $tableNumber = $request->table_number;
        $reservation->modified_by = $user->email;
        if ($reservation->type != 'pardepan') {

            $reservation->type = $request->type;
         
        }
        $reservation->save();
        $result = $this->reservationService->update($reservation->table->restaurant_id, $reservation_id, $reservation->client_id, $table_id, $data['number_people'], $data['date'], $comments, $tableNumber);



        $receiver = $reservation->client->user;



        if ($receiver->firebase_token && $receiver->active) {

            $title          = "Modificación de reserva";

            $description    = "Su reserva en " . $reservation->table->restaurant->name . " para " . $data['date'] . " ha sido modificada.";

            $information    = ['reservation_eid' => $id];

            $this->sendNotification($receiver->firebase_token, $title, $description, $information);
        }



        return $this->genResponse((int)($result['status'] == 200), $result['status'],  $result['data'], $result['message']);
    }



    /**

     * Delete

     * [Elimina la reservación].

     *

     * @urlParam id required El id de la reservacion a eliminar

     *

     * @param mixed $id

     */

    public function delete($id)

    {

        $reservationId = $this->getDecrypted($id);



        if ($reservationId < 0) {

            return $this->genResponse(0, 400, $id, 'Error en el id de la reservacion');
        }

        $salida = $this->reservationService->delete($reservationId);



        return $this->genResponse((int) (204 == $salida['status']), $salida['status'], null, $salida['message']);
    }



    /**

     * Cancel

     * [Cancela la reservación ].

     *

     * @urlParam id required El id de la reservacion a cancelar

     *

     * @param mixed $id

     *

     * @responseFile 204

     * @responseFile 400 responses/restaurant/reservations-cancel-400.json

     * @responseFile 404 responses/not-found.json

     * @responseFile 401 responses/unauthorized.json

     */

    public function cancel($id)

    {

        $reservation_id = $this->getDecrypted($id);



        $reservation = Reservation::where('id', $reservation_id)->where('reservations_status_id', 1)->first();



        if (!$reservation) {

            return $this->genResponse(0, 400, null, 'No existe la reservación enviada');
        }



        $salida = $this->reservationService->cancel($reservation_id);



        $receiver = $reservation->client->user;



        if ($receiver->firebase_token && $receiver->active) {

            $title          = "Cancelación de reserva";

            $description    = "Su reserva en " . $reservation->table->restaurant->name . " para " . $reservation->reservation_date . " ha sido cancelada.";

            $information    = ['reservation_eid' => $id];

            $this->sendNotification($receiver->firebase_token, $title, $description, $information);
        }
        $phone = $reservation->client->cell_phone;

        if ($phone != null && $phone !== '') {



            $body =
                "*ESTIMAD@* " . $reservation->client->name . ":
    Sentimos comunicarle que no hay disponibilidad para los siguientes datos:
    ";
            $body = $body . "
    *Nombre de la reserva*:" . $reservation->client->name . "
    *Restaurante*: " . $reservation->table->restaurant->name . "
    *Hora*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A') . "
    *Número de personas*: " . $reservation->people . "
    *Fecha*: " . Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y');
    
            /*<p style="font-size:16px;">Le invitamos a realizar una <a href="https://reservaya.com.do/restaurantes" target="_blank">NUEVA RESERVA</a>.</p> */
            $body = $body . "
    
    Le invitamos a realizar una *nueva reserva a traves del siguiente enlace* https://reservaya.com.do/restaurantes";
    
            $body = $body . "
    
    Si desea realizar una consulta o modificar los detalles de su reserva, por favor, pongase en contacto directamente con el restaurante. Este número de teléfono no contesta ni llamadas ni mensajes.
    
    Un cordial saludo,
    Equipo reserva ya!
    ";
    
            $params = array(
                'token' => 'ckrwcewisan28bw1',
                'to' => $phone,
                'body' => $body,
            );
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/chat",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => http_build_query($params),
                CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded"
                ),
            ));
    
            $response = curl_exec($curl);
            $err = curl_error($curl);
    
            curl_close($curl);
    
            if ($err) {
          
            } else {
                
                $params=array(
                                 'token' => 'ckrwcewisan28bw1',
                    'to' => $phone,
                    'image' => 'https://api.puerta21.club/public/images/logor2.png',
        'caption' => 'https://reservaya.com.do'
                    );
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                      CURLOPT_URL => "https://api.ultramsg.com/instance79410/messages/image",
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => "",
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 30,
                      CURLOPT_SSL_VERIFYHOST => 0,
                      CURLOPT_SSL_VERIFYPEER => 0,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => "POST",
                      CURLOPT_POSTFIELDS => http_build_query($params),
                      CURLOPT_HTTPHEADER => array(
                        "content-type: application/x-www-form-urlencoded"
                      ),
                    ));
                    
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    
                    curl_close($curl);
              
            }
        } 

        return $this->genResponse((int) (204 == $salida['status']), $salida['status'], null, $salida['message']);
    }





    /**

     * Reservations Per Month

     * [Regresa todas las reservaciones de cada dia del mes]

     *

     * @urlParam year required El año Example:2021

     * @urlParam month required El mes Example:7

     *

     * @responseFile responses/restaurant/reservations-perMonth-200.json

     * @responseFile 400 responses/restaurant/reservations-perMonth-400.json

     * @responseFile 401 responses/unauthorized.json

     */
    public function reservationsPerMonthTotalDEBUG($year, $month)
    {

        //['t_reservations.type', '=', 'pardepan'],['t_reservations.reservations_status_id', '=', 6]

        $restaurantId = auth()->user()->restaurant_id;

        $days = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->where('t_tables.restaurant_id', $restaurantId)
            ->whereYear('reservation_date', $year)
            ->whereMonth('reservation_date', $month)
            ->where('type', '=', 'pardepan')->where('reservations_status_id', '=', 6)
            ->select(

                'table_id',

                DB::raw('count(t_reservations.id) as num_reservations'),

                DB::raw("DATE_FORMAT(reservation_date, '%Y-%m-%d') as reservation_day"),

                't_tables.capacity',

                DB::raw('sum(people) as num_people'),
                't_reservations.type',
                't_reservations.reservations_status_id',
            )->groupBy('reservation_day', 'table_id')
            ->orderBy('reservation_day')->get();
    
   
        return  $days ;
    }

    public function reservationsPerMonthTotal($year, $month)
    {

        //['t_reservations.type', '=', 'pardepan'],['t_reservations.reservations_status_id', '=', 6]

        $restaurantId = auth()->user()->restaurant_id;

        $days = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

            ->where('t_tables.restaurant_id', $restaurantId)
            ->whereYear('reservation_date', $year)
            ->whereMonth('reservation_date', $month)
            ->where('type', '=', 'pardepan')->where('reservations_status_id', '=', 6)
            ->select(

                'table_id',

                DB::raw('count(t_reservations.id) as num_reservations'),

                DB::raw("DATE_FORMAT(reservation_date, '%Y-%m-%d') as reservation_day"),

                't_tables.capacity',

                DB::raw('sum(people) as num_people'),
                't_reservations.type',
                't_reservations.reservations_status_id',
            )->groupBy('reservation_day', 'table_id')
            ->orderBy('reservation_day')->get()->count();
      
        return  $days;
    }
    public function countAutomatic($year, $month){
        $restaurantId = auth()->user()->restaurant_id;

        $days = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
        ->where('t_tables.restaurant_id', $restaurantId)
        ->whereYear('reservation_date', $year)
        ->whereMonth('reservation_date', $month)
        ->where('type', '=', 'pardepan')
        ->where('reservations_status_id', '=', 9)
        ->where('is_automatic', '=', 1)
        ->where('seen', '=', 0)
        ->get()->count();
        return $days;

    }
    public function blockedreservations($year, $month)
    {
        $restaurantId = 1;
        
        $startDate = "{$year}-{$month}-01";
        $endDate = date('Y-m-t', strtotime($startDate));
    
        $reservationDates = PardepanBlocked::where('restaurant_id', $restaurantId)
            ->whereBetween('reservation_date', [$startDate, $endDate])
            ->get(['reservation_date']) // Obtener solo la columna reservation_date
            ->map(function ($item) {
                return intval(date('d', strtotime($item->reservation_date))); // Obtener solo el día de cada fecha
            })
            ->toArray();
    
        return $reservationDates;
    }
    public function reservationsPerMonth($year, $month)

    {

        $tocheck = ["year" => $year, "month" => $month];

        Log::debug("year and month " . json_encode($tocheck));



        $validator = Validator::make(

            $tocheck,

            [

                'year' => 'required|date_format:Y',

                'month' => 'required|date_format:m',

            ],

            [

                'year.date_format' => 'El año debe ser un valor numerico valido.',

                'month.date_format' => 'El mes debe ser un valor numerico valido.',

            ]

        );



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);
        }



        $restaurantId = auth()->user()->restaurant_id;



        $days = $this->reservationService->getCapacityByMonth($restaurantId, $year, $month);



        return $this->genResponse(1, 200, $days);
    }





    /**

     * Show reservation

     *

     * [Muestra la reservacion segun el id de la url]

     *

     * @urlParam id required El id de la reservacion No-example

     *

     * @responseFile responses/restaurant/reservations-show-200.json

     * @responseFile 404 responses/not-found.json

     * @responseFile 401 responses/unauthorized.json

     */

    public function show($id)
    {

        Log::info("id   =" . $id);



        $reservationId = $this->getDecrypted($id);



        $reservation = $this->reservationService->detail($reservationId);





        return $this->genResponse((!$reservation) ? 0 : 1, (!$reservation) ? 404 : 200, $reservation);
    }



    /**

     * create client from reservation

     *

     * [Crear cliente desde la reservación]

     */

    private function createClientFromReservation($client, $restaurantId, $categories)

    {

        $last_name = isset($client['last_name']) ?  $client['last_name'] : '';
        $first_name= isset($client['name']) ?  $client['name'] : '';

        $email = "";
        $phone = "";
        //check if both email and phone are null or ""
        if ($client['email'] == null || $client['email'] == "") {
            //set phone as a random unique string with prefix "random"
            $phone =  uniqid();
           
        }else{
            if (filter_var($client['email'], FILTER_VALIDATE_EMAIL)) {
                $email = $client['email'];
            }else{
                $email = "";
                $phone = $client['email'];
            }
        }


    
   
        //fix para que permita el apellido vacio en la reserva
        $middleName = $client['middle_name'];
        if ($client['middle_name'] == null) {
            $middleName = '';
        }
        return $this->clientService->createRestaurantClient(

            $email,

            $first_name,

            $middleName,

            $last_name,

            $phone,

            $categories,

            $restaurantId

        );
    }

    public function saveAllDay(Request $request)
    {

        $reservation = new ReservationBlocked;

        $reservation->name = $request->name;

        $reservation->email = $request->email;

        $reservation->phone = $request->phone;

        $reservation->reason = $request->reason;

        $reservation->people = $request->people;

        $reservation->reservation_date = $request->date;

        $reservation->status = "ACTIVE";

        $reservation->save();

        return $this->genResponse(1, 200, $reservation);
    }

    public function removeAllDay(Request $request)
    {

        $date = $request->date;

        $validdate = date('Y-m-d', strtotime($date));

        $reservations = ReservationBlocked::whereRaw('DATE(reservation_date) = ?', [$validdate])->get();

        foreach ($reservations as $reservation) {

            $reservation->status = "CANCELLED";

            $reservation->save();
        }

        return $this->genResponse(1, 200, $reservations);
    }
}
