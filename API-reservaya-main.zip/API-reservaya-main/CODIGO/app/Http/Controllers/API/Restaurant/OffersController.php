<?php

namespace App\Http\Controllers\API\Restaurant;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOffer;
use App\Http\Requests\EditOffer;
use App\Http\Requests\UpdatePassword;
use Illuminate\Http\Request;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use Illuminate\Support\Facades\Log;
use App\Models\Catalogs\Role;
//use model de offers
use App\Models\Offer;

/**
 * @group Restaurant offer
 */
class OffersController extends Controller
{
    use GeneralResponse;
    use AuxiliarFunctions;



    /**
     * Store.
     *
     * [Crea personal para el restaurante]
     */
    public function store(Request $request)
    {

        
        $manager = auth()->user();
        $offrt = new Offer();
        $offrt->status = 1;
        $restaurantId = $manager->restaurant_id;
        $offrt->restaurant_id = $restaurantId;
        $offrt->title = $request->title;
        $offrt->description = $request->description;
        //stard date
        $offrt->start_date = $request->startDate;
        //end date
        $offrt->end_date = $request->endDate;
        //type
        $offrt->type = $request->type;
        //week days as 0 or 1
        $offrt->monday = $request->monday;
        $offrt->tuesday = $request->tuesday;
        $offrt->wednesday = $request->wednesday;
        $offrt->thursday = $request->thursday;
        $offrt->friday = $request->friday;
        $offrt->saturday = $request->saturday;
        $offrt->sunday = $request->sunday;
        //dates
        $offrt->dates = $request->dates;
        //repeat
        $offrt->repeats = $request->repeat;


        $offrt->save();
        //return response success
        return $this->genResponse(1,200,null);

    }

    /**
     * Offer.
     *
     * [Regresa una lista de todo el personal del restaurante. El personal se puede filtrar mediante el correo]
     *
     * @urlparam email string El correo por el que se quiere filtrar al personal
     *
     * @param null|mixed $email
     */
    public function index(Request $request)
    {
        $manager = auth()->user();
        $offers = Offer::where('restaurant_id',$manager->restaurant_id)->get();

   
        return $this->genResponse(1,200,$offers);
    }

    /**
     * Edit.
     *
     * [Editar personal del restaurante]
     */
    public function edit(Request $request, $id)
    {
 
        $manager = auth()->user();
        $offer = Offer::where('id',$id)->where('restaurant_id',$manager->restaurant_id)->first();
        if($offer){
            $offer->status = 1;
            $restaurantId = $manager->restaurant_id;
            $offer->restaurant_id = $restaurantId;
            $offer->title = $request->title;
            $offer->description = $request->description;
            //stard date
            $offer->start_date = $request->startDate;
            //end date
            $offer->end_date = $request->endDate;
            //type
            $offer->type = $request->type;
            //week days as 0 or 1
            $offer->monday = $request->monday;
            $offer->tuesday = $request->tuesday;
            $offer->wednesday = $request->wednesday;
            $offer->thursday = $request->thursday;
            $offer->friday = $request->friday;
            $offer->saturday = $request->saturday;
            $offer->sunday = $request->sunday;
            //dates
            $offer->dates = $request->dates;
            //repeat
            $offer->repeats = $request->repeat;
    
    
            $offer->save();
            //return response success
            return $this->genResponse(1,200,null);
        }else{
            return $this->genResponse(0,404,null);
        }
        

        //return $this->offersService->update($manager->id, $id, $data);
    }

    /**
     * Delete.
     *
     * [Eliminar personal del restaurante]
     */
    public function delete($id){
        $offerid = $id;
        $manager = auth()->user();
        $offer = Offer::where('id',$offerid)->where('restaurant_id',$manager->restaurant_id)->first();
        if($offer){
            $offer->delete();
            return $this->genResponse(1,200,null);
        }else{
            return $this->genResponse(0,404,null);
        }
    }

    /**
     * Show.
     *
     * [Detalle del personal del restaurante]
     */
    public function show($id){
        $manager = auth()->user();
        $offer = Offer::where('id',$id)->where('restaurant_id',$manager->restaurant_id)->first();
        if($offer){
            return $this->genResponse(1,200,$offer);
        }else{
            return $this->genResponse(0,404,null);
        }
       // return $this->offersService->show($id);
    }

    /**
     * Update password.
     *
     * [Actualizar contraseña]
     */
    public function checkAvailability($date, $restaurantId){


    
      
    }

}
