<?php

namespace App\Http\Controllers\API\puerta21;

use App\Models\{Restaurant, Client, User, Reservation, PardepanBlocked};

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\{GeneralResponse, AuxiliarFunctions};

class DashboardController extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    #protection with token
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    #get all data for dashboard
    public function index()
    {
        #define var 
        $user_day = 0;
        $user_total = 0;
        $reservation_day = 0;
        $reservation_total = 0;
        $reservation_overview = [];
        $reservations_years = [];
        $percentage_reservation_y = 0;
        $percentage_user_y = 0;
        $percentage_users_year = 0;
        $percentage_reservation_year = 0;
        $labels_months_abr = [];
        $data_months = [];
        $labels_months_abr_clients = [];
        $data_months_clients = [];
        $clients_overview = [];
        $currentDate = now();
        $currentMonth = $currentDate->format('m');

        $lastMonthDate = $currentDate->copy()->subMonth();
        $lastMonth = $lastMonthDate->format('m'); 

        #get user day pardepan , 
        $user_day = Client::whereDate('created_at', date('Y-m-d'))->where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })->count();

        #get porcentual user yesterday
        $user_yesterday = Client::whereDate('created_at', date('Y-m-d', strtotime("-1 days")))
            ->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            })->count();

        if ($user_yesterday > 0) {
            $percentage_user_y = round(($user_day - $user_yesterday) / $user_yesterday * 100);
        } else {
            $percentage_user_y = 0;
        }

        #get user total
        $user_total = Client::where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })->count();

        #get porcentual users last year
        $users_years = Client::where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })
        ->selectRaw('count(*) as total, YEAR(created_at) as year')
            ->groupBy('year')
            ->get();

        $current_year = $users_years->where('year', date('Y'))->first();
        $past_year = $users_years->where('year', date('Y') - 1)->first();

        if ($current_year && $past_year) {
            $percentage_users_year = round(($current_year->total - $past_year->total) / $past_year->total * 100);
        } else {
            $percentage_users_year = 0;
        }
        

        #get reservation for day, client platform pardepan or reservaya_a date('Y-m-d')
        $reservation_day = Reservation::whereDate('created_at', date('Y-m-d'))->whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })->count();

        #Reservation Overview for the last year
        $reservation_overview_last_year = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })
        ->selectRaw('count(*) as total, MONTH(created_at) as month')
        ->whereYear('created_at', date('Y') - 1)
        ->groupBy('month')
        ->get();

        #ORDER BY MONTH ASC
        $reservation_overview_last_year = $reservation_overview_last_year->sortBy('month');

        #get data for last year
        $data_months_last_year = $reservation_overview_last_year->map(function ($value) {
            return $value->total;
        });

        $labels_months_abr_last_year = $reservation_overview_last_year->map(function ($value) {
            return $this->getMonthName($value->month);
        });

        #LABELS MONTHS ONLY VALUE RETURN
        $labels_months_abr_last_year = $labels_months_abr_last_year->values();

        #DATA MONTHS ONLY VALUE RETURN for last year
        $data_months_last_year = $data_months_last_year->values();

         #Reservation Overview for the last year
         $reservation_overview_initial_year = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })
        ->selectRaw('count(*) as total, MONTH(created_at) as month')
        ->whereYear('created_at', date('Y') - 2)
        ->groupBy('month')
        ->get();

        #ORDER BY MONTH ASC
        $reservation_overview_initial_year = $reservation_overview_initial_year->sortBy('month');

        #get data for last year
        $data_months_initial_year = $reservation_overview_initial_year->map(function ($value) {
            return $value->total;
        });

        $data_months_initial_year = $data_months_initial_year->values();
        

        #get porcentual reservation yesterday
        $reservation_yesterday = Reservation::whereDate('created_at', date('Y-m-d', strtotime("-1 days")))->whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })->count();
        if ($reservation_yesterday > 0) {
            $percentage_reservation_y = round(($reservation_day - $reservation_yesterday) / $reservation_yesterday * 100);
        } else {
            $percentage_reservation_y = 0;
        }

        #get reservation total
        $reservation_total = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })->count();

        #reservations for years
        $reservations_years = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })->selectRaw('count(*) as total, YEAR(created_at) as year')
            ->groupBy('year')
            ->get();

        #get the percentage of the current year with the past year
        $current_year = $reservations_years->where('year', date('Y'))->first();
        $past_year = $reservations_years->where('year', date('Y') - 1)->first();
        
        if ($current_year && $past_year) {
            $percentage_reservation_year = round(($current_year->total - $past_year->total) / $past_year->total * 100);
        } else {
            $percentage_reservation_year = 0;
        }

        #Reservation Overview for the last year
        $reservation_overview = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })->selectRaw('count(*) as total, MONTH(created_at) as month')
            ->whereYear('created_at', date('Y'))
            ->groupBy('month')
            ->get();

        #ORDER BY MONTH ASC
        $reservation_overview = $reservation_overview->sortBy('month');
        #get labels 
        $labels_months_abr = $reservation_overview->map(function ($value) {
            return $this->getMonthName($value->month);
        });

        #LABELS MONTHS ONLY VALUE RETURN
        $labels_months_abr = $labels_months_abr->values();

        #get data 
        $data_months = $reservation_overview->map(function ($value) {
            return $value->total;
        });

        #DATA MONTHS ONLY VALUE RETURN
        $data_months = $data_months->values();

        #Clients Overview for the last year
        $clients_overview = Client::where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })->selectRaw('count(*) as total, MONTH(created_at) as month')
            ->whereYear('created_at', date('Y'))
            ->groupBy('month')
            ->get();
            

        #ORDER BY MONTH ASC
        $clients_overview = $clients_overview->sortBy('month');

        #get labels clients
        $labels_months_abr_clients = $clients_overview->map(function ($value) {
            return $this->getMonthName($value->month);
        });

        #LABELS MONTHS ONLY VALUE RETURN
        $labels_months_abr_clients = $labels_months_abr_clients->values();

        #get data clients
        $data_months_clients = $clients_overview->map(function ($value) {
            return $value->total;
        });

        #DATA MONTHS ONLY VALUE RETURN
        $data_months_clients = $data_months_clients->values();

        $client_overview_last_year = Client::where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })->selectRaw('count(*) as total, MONTH(created_at) as month')
            ->whereYear('created_at', date('Y') - 1)
            ->groupBy('month')
            ->get();


        
        #ORDER BY MONTH ASC
        $clients_overview_past = $client_overview_last_year->sortBy('month');

        #get labels clients
        $labels_months_abr_clients_past =  $client_overview_last_year->map(function ($value) {
            return $this->getMonthName($value->month);
        });

        #LABELS MONTHS ONLY VALUE RETURN
        $labels_months_abr_clients_past =  $labels_months_abr_clients_past->values();


        $data_months_clients_past = $clients_overview_past->map(function ($value) {
            return $value->total;
        });

        #DATA MONTHS ONLY VALUE RETURN
        $data_months_clients_past =  $data_months_clients_past->values();

        $client_overview_last_initial2 = Client::where(function($query) {
            $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
        })->selectRaw('count(*) as total, MONTH(created_at) as month')
            ->whereYear('created_at', date('Y') - 2)
            ->groupBy('month')
            ->get();
        
        #ORDER BY MONTH ASC
        $clients_overview_initial2 = $client_overview_last_initial2->sortBy('month');

        #get labels clients
        $labels_months_abr_clients_initial2 =  $client_overview_last_initial2->map(function ($value) {
            return $this->getMonthName($value->month);
        });

        #LABELS MONTHS ONLY VALUE RETURN
        $labels_months_abr_clients_initial2 =  $labels_months_abr_clients_initial2->values();

        $data_months_clients_initial = $clients_overview_initial2->map(function ($value) {
            return $value->total;
        });

        #DATA MONTHS ONLY VALUE RETURN
        $data_months_clients_initial =  $data_months_clients_initial->values();



        // Calculate the average of the current month
        $totalClientsMonth = Client::where(function($query) {
            $query->where('platform', 'pardepan')
                  ->orWhere('platform', 'reservaya_a');
        })
        ->whereMonth('created_at', $currentMonth)
        ->count();


            $totalClientsMonthPast = Client::where(function($query) {
                $query->where('platform', 'pardepan')
                    ->orWhere('platform', 'reservaya_a');
            })
            ->whereMonth('created_at', $lastMonth)
            ->count();

        $averageMonth = round($totalClientsMonth / $currentDate->format('d'));

        $averageMonthPast = round($totalClientsMonthPast / $currentDate->format('d'));

        // Calculate the comparison percentage
        

        if ($averageMonthPast > 0) {
            $media_percentage = round(($averageMonth - $averageMonthPast) / $averageMonthPast * 100);
        } else {
            $media_percentage = 0;
        }

         #Reservation  for the most
         $totalreservationMonth = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })
        ->whereMonth('created_at', $currentMonth)
        ->count();


         #Reservation  for the most
         $totalreservationMonthPast = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->OrWhere('platform', 'reservaya_a');
            });
        })
        ->whereMonth('created_at',  $lastMonth)
        ->count();
        $reservation_overview2 = Reservation::whereHas('client', function ($query) {
            $query->where(function($query) {
                $query->where('platform', 'pardepan')->orWhere('platform', 'reservaya_a');
            });
        })
        ->selectRaw('count(*) as total, YEAR(created_at) as year, MONTH(created_at) as month')
        ->groupBy('year', 'month')
        ->orderBy('year', 'asc')
        ->orderBy('month', 'asc')
        ->get();
    
    $data_months2 = $reservation_overview2->map(function ($value) {
        return $value->total;
    });
        

        $reservationaverageMonth = round($totalreservationMonth / $currentDate->format('d'));

        if ($reservationaverageMonth > 0) {
            $reservation_media_percentage = round(($totalreservationMonth -  $totalreservationMonthPast) / $totalreservationMonthPast * 100);
        } else {
            $reservation_media_percentage = 0;
        }

        $data = [ 
            'user_day' => $user_day,
            'percentage_user_y' => $percentage_user_y,
            'user_total' => $user_total,
            'percentage_users_year' => $percentage_users_year,
            'reservation_day' => $reservation_day,
            'percentage_reservation_y' => $percentage_reservation_y,
            'reservation_total' => $reservation_total,
            'percentage_reservation_year' => $percentage_reservation_year,
            'reservation_overview' => $reservation_overview,
            'labels_months_abr' => $labels_months_abr,
            'data_months' => $data_months,
            'reservations_years' => $reservations_years,
            'clients_overview' => $clients_overview, 
            'labels_months_abr_clients' => $labels_months_abr_clients,
            'data_months_clients' => $data_months_clients,
            'media_percentage' => $media_percentage,
            'averageMonth' => $averageMonth,
            'totalClientsMonth' => $totalClientsMonth,
            'reservationaverageMonth' => $reservationaverageMonth,
            'reservation_media_percentage' => $reservation_media_percentage,
            'data_months_last_year' =>$data_months_last_year,
            'labels_months_abr_last_year' => $labels_months_abr_last_year,
            'data_months_clients_past' => $data_months_clients_past,
            'data_months_clients_initial' => $data_months_clients_initial,
            'data_months_initial_year' => $data_months_initial_year
            
           
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");

    }

    #get all data for dashboard
    public function homeTop()
    {
        #define var 
        $top_restaurants = [];

        #get top restaurants by reservations only clients pardepan limit 10
        $top_restaurants = Restaurant::selectRaw('count(*) as total, t_restaurants.name as restaurant_name, t_restaurants.id as restaurant_id, t_restaurants.thumbnail as thumbnail')
            ->join('t_tables', 't_restaurants.id', '=', 't_tables.restaurant_id')
            ->join('t_reservations', 't_tables.id', '=', 't_reservations.table_id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->groupBy('t_restaurants.id')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        #count reservations canceled [5, 7], completed [2,3,9], pending [1,6] 'reservations_status_id', 5
        foreach ($top_restaurants as $key => $value) {
            $restaurants[] = [
                'restaurant_name' => $value->restaurant_name,
                'restaurant_id' => $value->restaurant_id,
                'image' => $value->photos->map(function ($photo) {
                    return [
                        'id' => $photo->encrypt_id,
                        'photo' => $this->getImageUrl($photo->url),
                        'order' => $photo->order_photos,
                    ];
                }),
                'total' => $value->total,
                'reservations' => [
                    'canceled' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [5,7])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count(),
                    'completed' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [2,3,9])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count(),
                    'pending' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [1,6])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count()
                ]
            ];
        }

    
        $data = [
            'restaurants_top' => $restaurants,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");
    }


    #get all data for dashboard top zonas
    public function topZone() {
        #Returns the zones with the most reservations taking into account that a restaurant has zone_id. only clients pardepan limit 10
        $top_zone = Reservation::selectRaw('count(*) as total, c_zones.name as zone_name, c_zones.id as zone_id')
            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
            ->join('t_restaurants', 't_tables.restaurant_id', '=', 't_restaurants.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->groupBy('c_zones.id')
            ->orderBy('total', 'desc')
            ->limit(10) 
            ->get();
        
        return $this->genResponse(1, 200, $top_zone, "Información consultada correcatmente");
    }


}
