<?php

namespace App\Http\Controllers\API\puerta21;

use App\Models\{Restaurant, Client, User, Reservation, PardepanBlocked};
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class BannersController extends Controller
{
   

    public function listImagen() {

        $banners = DB::table('t_banners')->get();

        return response()->json($banners);
    }
    public function createdBanner(Request $request)
    {
        // Validar los campos del formulario
        $validatedData = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'posicion' => 'required',
            'enlace' => 'required',
            'imagen' => 'required|image|max:2048', // Validar el archivo de imagen
        ]);
    
        // Guardar la imagen en el servidor
        $imagePath = $request->file('imagen')->store('banners', 'public');
    
        // Crear un nuevo registro en la tabla 't_banners'
        $newBanner = [
            'titulo' => $validatedData['title'],
            'descripcion' => $validatedData['description'],
            'posicion' => $validatedData['posicion'],
            'enlace' => $validatedData['enlace'],
            'imagen' => $imagePath, // Guardar la ruta de la imagen
        ];
    
        $bannerId = DB::table('t_banners')->insertGetId($newBanner);
    
        // Retornar respuesta de éxito
        return $this->genResponse(1, 201, ['id' => $bannerId]);
    }



    public function editBanner(Request $request, $id)
    {
        $banner = DB::table('t_banners')->where('id', $id)->first();
        if ($banner) {
            // Actualizar los campos del banner
            $banner->titulo = $request->title;
            $banner->descripcion = $request->description;
            $banner->posicion = $request->posicion;
            $banner->enlace = $request->enlace;
    
            // Verificar si se ha enviado una nueva imagen
            if ($request->hasFile('imagen')) {
                // Generar una nueva ruta de imagen
                $imagePath = $request->file('imagen')->store('banners', 'public');
                $banner->imagen = $imagePath;
            }
    
            // Guardar los cambios en la base de datos
            DB::table('t_banners')->where('id', $id)->update([
                'titulo' => $banner->titulo,
                'descripcion' => $banner->descripcion,
                'posicion' => $banner->posicion,
                'enlace' => $banner->enlace,
                'imagen' => $banner->imagen
            ]);
    
            // Retornar respuesta de éxito
            return $this->genResponse(1, 200, null);
        } else {
            // Retornar respuesta de error
            return $this->genResponse(0, 404, null);
        }
    }


    public function statusBanner(Request $request, $id)
    {
        $banner = DB::table('t_banners')->where('id', $id)->first();
        if ($banner) {
            // Actualizar los campos del banner
            $banner->activo = $request->activo;
           
    
            // Guardar los cambios en la base de datos
            DB::table('t_banners')->where('id', $id)->update([
                'activo' => $banner->activo,
               
            ]);
    
            // Retornar respuesta de éxito
            return $this->genResponse(1, 200, null);
        } else {
            // Retornar respuesta de error
            return $this->genResponse(0, 404, null);
        }
    }

    public function DetailsBanner($id){
        $Bannerid = $id;
        $manager = auth()->user();
        $banner = DB::table('t_banners')->where('id',$id)->first();
        if($banner){
            
            return $this->genResponse(1,200,$banner);
        }else{
            return $this->genResponse(0,404,null);
        }
    }

    protected function genResponse($success, $statusCode, $data)
{
    $response = [
        'success' => $success,
        'status_code' => $statusCode,
        'data' => $data
    ];

    return response()->json($response);
}

public function bannerImage(Request $request)
{
    $image = \Image::make($request->image);
    $filename = \Str::random(10) . '800.webp';
    $image->resize(1280, 720);
    $image->encode('webp', 75)->save('public/banners/'.$filename);

    $newPhoto = $filename; // Asignar el nombre del archivo a la variable $newPhoto

    return $this->genResponse(1, 200, $newPhoto);
}


     
}





