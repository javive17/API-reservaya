<?php

namespace App\Http\Controllers\API\puerta21;

use App\Models\{Restaurant, Client, User, Reservation, PardepanBlocked};

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\{GeneralResponse, AuxiliarFunctions};

class RestaurantController extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    #protection with token
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    #get all data for dashboard
    public function restaurants()
    {
        #define var 
        $top_restaurants = [];

        #get top restaurants by reservations only clients pardepan and reservya_a limit 10
        $top_restaurants = Restaurant::selectRaw('count(*) as total, t_restaurants.name as restaurant_name, t_restaurants.id as restaurant_id, t_restaurants.thumbnail as thumbnail, c_zones.name as zone_name')
            ->join('t_tables', 't_restaurants.id', '=', 't_tables.restaurant_id')
            ->join('t_reservations', 't_tables.id', '=', 't_reservations.table_id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->groupBy('t_restaurants.id')
            ->orderBy('total', 'desc')
            ->get();

        #count reservations canceled [5, 7], completed [2,3,9], pending [1,6] 'reservations_status_id', 5
        foreach ($top_restaurants as $key => $value) {
            $restaurants[] = [
                'restaurant_name' => $value->restaurant_name,
                'restaurant_id' => $value->restaurant_id,
                'image' => $value->photos->map(function ($photo) {
                    return [
                        'id' => $photo->encrypt_id,
                        'photo' => $this->getImageUrl($photo->url),
                        'order' => $photo->order_photos,
                    ];
                }),
                'zone' => $value->zone_name,
                'total' => $value->total,
                'reservations' => [
                    'canceled' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [4,5,7,8,10])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count(),
                    'completed' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [2,3,9])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count(),
                    'pending' => Reservation::whereHas('client', function ($query) {
                        $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                    })->whereIn('reservations_status_id', [1,6])->whereHas('table', function ($query) use ($value) {
                        $query->where('restaurant_id', $value->restaurant_id);
                    })->count() 
                ]
            ];
        }

    
        $data = [
            'restaurants_top' => $restaurants,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");
    }


    public function show(Request $request) {

        $this->validate(
            $request,
            [
                'date_start'    => 'nullable|date|before_or_equal:date_end',
                'date_end'      => 'nullable|date|after_or_equal:date_start',
            ],
            [
                'date_start.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'date_end.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );
        
        #get restaurant
        $restaurants = Restaurant::selectRaw('count(*) as total, t_restaurants.name as restaurant_name, t_restaurants.id as restaurant_id, t_restaurants.thumbnail as thumbnail, c_zones.name as zone_name')
            ->join('t_tables', 't_restaurants.id', '=', 't_tables.restaurant_id')
            ->join('t_reservations', 't_tables.id', '=', 't_reservations.table_id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->where('t_restaurants.id', $request->id)
            ->groupBy('t_restaurants.id')
            ->orderBy('total', 'desc')
            ->get();

        if (count($restaurants) == 0) {
            return $this->genResponse(0, 404, null, "No se encontró el restaurante");
        }

        $restaurant = $restaurants[0];

        #restaurant 
        $restaurant_data = [
            'restaurant_name' => $restaurant->restaurant_name,
            'restaurant_id' => $restaurant->restaurant_id,
            'image' => $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
                    'photo' => $this->getImageUrl($photo->url),
                    'order' => $photo->order_photos,
                ];
            }),
            'zone' => $restaurant->zone_name,
            'total' => $restaurant->total,
            'reservations' => [
                'canceled' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [4,5,7,8,10])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(),
                'completed' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [2,3,9])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(),
                'pending' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [1,6])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count() 
            ]
        ];

        $data = [
            'restaurant' => $restaurant_data,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");   
    }


    public function reservesgraph(Request $request) {

        $this->validate(
            $request,
            [
                'date_start'    => 'nullable|date|before_or_equal:date_end',
                'date_end'      => 'nullable|date|after_or_equal:date_start',
            ],
            [
                'date_start.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'date_end.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );
        

        
        #get restaurant
        $restaurants = Restaurant::selectRaw('count(*) as total, t_restaurants.name as restaurant_name, t_restaurants.id as restaurant_id, t_restaurants.thumbnail as thumbnail, c_zones.name as zone_name')
            ->join('t_tables', 't_restaurants.id', '=', 't_tables.restaurant_id')
            ->join('t_reservations', 't_tables.id', '=', 't_reservations.table_id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->where('t_restaurants.id', $request->id)
            ->groupBy('t_restaurants.id')
            ->orderBy('total', 'desc')
            ->get();

        if (count($restaurants) == 0) {
            return $this->genResponse(0, 404, null, "No se encontró el restaurante");
        }

        $restaurant = $restaurants[0];
        $cancelledCount = PardepanBlocked::whereDate('reservation_date', '>=', $request->date_start)  ->where('restaurant_id', $request->id)
       // $cancelledCount = PardepanBlocked::whereRaw('DATE(reservation_date) = ?', [$request->date_start, $request->date_end])->get();
        ->get();
        
        #restaurant 
        $restaurant_data = [
            'restaurant_name' => $restaurant->restaurant_name,
            'restaurant_id' => $restaurant->restaurant_id,
            'cancelledCount' =>  $cancelledCount,
            'image' => $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
                    'photo' => $this->getImageUrl($photo->url),
                    'order' => $photo->order_photos,
                ];
            }),
            'zone' => $restaurant->zone_name,
            'total' => $restaurant->total,
            'reservations' => [
                'canceled_rechazada' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [5,8,7])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(),
                'canceled' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [5,8])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(),
                'canceled_client' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [7])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(), 

                  'completed' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [2,3,9])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count(),

                'pending' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [1,6])->whereHas('table', function ($query) use ($restaurant) {
                    $query->where('restaurant_id', $restaurant->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
                ->count() 


                
            ]
        ];

        $data = [
            'restaurant' => $restaurant_data,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");   
    }


    public function zones() {
        #Returns the zones with the most reservations taking into account that a restaurant has zone_id. only clients pardepan limit 10
        $top_zone = Reservation::selectRaw('count(*) as total, c_zones.name as zone_name, c_zones.id as zone_id')
            ->join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
            ->join('t_restaurants', 't_tables.restaurant_id', '=', 't_restaurants.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->groupBy('c_zones.id')
            ->orderBy('total', 'desc')
            ->get();
        
        return $this->genResponse(1, 200, $top_zone, "Información consultada correcatmente");
    }

    public function zoneShow(Request $request) {

        $this->validate(
            $request,
            [
                'date_start'    => 'nullable|date|before_or_equal:date_end',
                'date_end'      => 'nullable|date|after_or_equal:date_start',
            ],
            [
                'date_start.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'date_end.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );

        #variable
        $zone_id = $request->id;
        
        #get restaurants by zone
        $restaurants = Restaurant::selectRaw('count(*) as total, t_restaurants.name as restaurant_name, t_restaurants.id as restaurant_id, t_restaurants.thumbnail as thumbnail, c_zones.name as zone_name')
            ->join('t_tables', 't_restaurants.id', '=', 't_tables.restaurant_id')
            ->join('t_reservations', 't_tables.id', '=', 't_reservations.table_id')
            ->join('t_clients', 't_reservations.client_id', '=', 't_clients.id')
            ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
            ->whereIn('t_clients.platform', ['reservaya_a', 'pardepan'])
            ->where('c_zones.id', $zone_id)
            ->groupBy('t_restaurants.id')
            ->orderBy('total', 'desc')
            ->get();

        if (count($restaurants) == 0) {
            return $this->genResponse(0, 404, null, "No se encontró la zona");
        }

        #foreach restaurants get name, id, reservations total
        $results = [];
        foreach ($restaurants as $key => $value) {

            $reservation_total = Reservation::whereHas('client', function ($query) {
                $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
            })->whereHas('table', function ($query) use ($value) {
                $query->where('restaurant_id', $value->restaurant_id);
            })->whereDate('t_reservations.reservation_date', '>=', $request->date_start)->whereDate('t_reservations.reservation_date', '<=', $request->date_end)
            ->count();

            if($reservation_total == 0) continue;

            $results[] = [
                'restaurant_name'   => $value->restaurant_name,
                'restaurant_id'     => $value->restaurant_id,
                'reservation_total' => $reservation_total,
            ];
        }

        #order by reservation total  
        usort($results, function($a, $b) {
            return $b['reservation_total'] <=> $a['reservation_total'];
        });

        //solo dejar 6 restaurantes
        $results = array_slice($results, 0, 100); 

        $data = [
            'zone_name' => $restaurants[0]->zone_name,
            'zone_id' => $zone_id,
            'restaurants' => $results,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");   
    }
}
