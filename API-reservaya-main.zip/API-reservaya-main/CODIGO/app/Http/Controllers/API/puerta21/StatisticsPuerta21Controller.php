<?php

namespace App\Http\Controllers\API\puerta21;

use App\Models\{Restaurant, Client, User, Reservation, PardepanBlocked};

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\{GeneralResponse, AuxiliarFunctions};

class StatisticsPuerta21Controller extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    public function puerta21reservesgraph(Request $request) {

        $this->validate(
            $request,
            [
                'start_date'    => 'nullable|date|before_or_equal:end_date',
                'end_date'      => 'nullable|date|after_or_equal:start_date',
            ],
            [
                'start_date.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'end_date.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );
        
        $manager = auth()->user();
     
        

     
        $cancelledCount = PardepanBlocked::whereDate('reservation_date', '>=', $request->start_date)  ->where('restaurant_id', $manager->restaurant_id)
    // $cancelledCount = PardepanBlocked::whereRaw('DATE(reservation_date) = ?', [$request->startdate, $request->end_date])->get();
        ->get();
        $restaurant = Restaurant::where('id', $manager->restaurant_id)->first();
    
        #restaurant 
        $restaurant_data = [
            'restaurant_name' => $restaurant->restaurant_name,
            'restaurant_id' => $manager->restaurant_id,
            'cancelledCount' =>  $cancelledCount,
            'image' => $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
     
                    'order' => $photo->order_photos,
                ];
            }),
            'zone' => $restaurant->zone_name,
            'total' => $restaurant->total,
            'reservations' => [
                'canceled' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [5,8])->whereHas('table', function ($query) use ($manager) {
                    $query->where('restaurant_id', $manager->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->start_date)->whereDate('t_reservations.reservation_date', '<=', $request->end_date)
                ->count(),
                'canceled_client' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [7])->whereHas('table', function ($query) use ($manager) {
                    $query->where('restaurant_id', $manager->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->start_date)->whereDate('t_reservations.reservation_date', '<=', $request->end_date)
                ->count(), 

                'completed' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [2,3,9])->whereHas('table', function ($query) use ($manager) {
                    $query->where('restaurant_id', $manager->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->start_date)->whereDate('t_reservations.reservation_date', '<=', $request->end_date)
                ->count(),

                'pending' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereIn('reservations_status_id', [1,6])->whereHas('table', function ($query) use ($manager) {
                    $query->where('restaurant_id', $manager->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->start_date)->whereDate('t_reservations.reservation_date', '<=', $request->end_date)
                ->count(),
                'total' => Reservation::whereHas('client', function ($query) {
                    $query->whereIn('t_clients.platform', ['reservaya_a', 'pardepan']);
                })->whereHas('table', function ($query) use ($manager) {
                    $query->where('restaurant_id', $manager->restaurant_id);
                })->whereDate('t_reservations.reservation_date', '>=', $request->start_date)->whereDate('t_reservations.reservation_date', '<=', $request->end_date)->count(), 


                
            ]
        ];

        $data = [
            'restaurant' => $restaurant_data,
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");   
    }


    public function puerta21usersPlatform(Request $request)
    {

        
        $this->validate($request, [
            'year' => 'required|integer',
        ]);

        $manager = auth()->user();

        // bring all clients divided by platform, those who are platform = Otro will go to puerta_21 and those who are pardepan will go to reservation_ya, divide it by months
        $clients = Client::query();
        $reservations = Reservation::query();
        #platform pardepan and reservaya_a
      #platform pardepan and reservaya_a
      $clients = $clients->whereIn('platform', ['pardepan', 'reservaya_a'])
      ->whereHas('reservations', function ($query) use ($manager) {
          $query->whereHas('table', function ($query) use ($manager) {
              $query->where('restaurant_id', $manager->restaurant_id);
          });
      });
          $reservations = Reservation::query()
        ->where('type', '!=', 'pardepan')
        ->whereHas('table', function ($query) use ($manager) {
            $query->where('restaurant_id', $manager->restaurant_id);
        });


        if ($request->year) {
            $clients = $clients->whereYear('created_at', $request->year);
            $reservations = $reservations->whereYear('created_at', $request->year);
        }

        #agrupar por año y luego poner por platform
        $clients = $clients->get()->groupBy(function ($item) {
            return $item->created_at->format('Y');
        });

        #agrupar por platform
        $clients = $clients->map(function ($item) {
            return $item->groupBy(function ($item) {
                return $item->platform;
            });
        });

        $reservations = $reservations->get()->groupBy('type')->map(function ($item) {
            return $item->groupBy(function ($item) {
                return $item->created_at->format('m');
            });
        });

        #agrupo por mes y los mes que no tenga datos los pongo en 0
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->groupBy(function ($item) {
                    return $item->created_at->format('m');
                });
            });
        });

        

        #counter
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->map(function ($item) {
                    return $item->count();
                });
            });
        });

        $reservations = $reservations->map(function ($item) {
            return $item->map(function ($item) {
                return $item->count();
            });
        });

        
        #los meses que no tengan datos ponerlos en 0,
        $months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
        foreach ($months as $key => $value) {
            if (isset($clients[$request->year]['reservaya_a'])) {
                if (!isset($clients[$request->year]['reservaya_a'][$value])) {
                    $clients[$request->year]['reservaya_a'][$value] = 0;
                }
            }
            $types = $reservations->keys()->toArray();
            if (isset($clients[$request->year]['pardepan'])) {
                if (!isset($clients[$request->year]['pardepan'][$value])) {
                    $clients[$request->year]['pardepan'][$value] = 0;
                }
            }
        }

        #ordenar por mes
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->sortBy(function ($item, $key) {
                    return $key;
                });
            });
        });

        #labels getMonthName por platform
        $labels_clients = [
            'reservaya_a' => [],
            'pardepan' => [],
        ];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                foreach ($value2 as $key3 => $value3) {
                    $labels_clients[$key2][] = $this->getMonthName($key3);
                }
            }
        }

        #verificar cual labels es mayor y dejar ese como labels
        $labels_clients = $labels_clients['reservaya_a'] > $labels_clients['pardepan'] ? $labels_clients['reservaya_a'] : $labels_clients['pardepan'];

        #data por platform
        $data_clients = [
            'reservaya_a' => [],
            'pardepan' => [],
        ];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                foreach ($value2 as $key3 => $value3) {
                    $data_clients[$key2][] = $value3;
                }
            }
        }

        if (empty($data_clients['reservaya_a'])) {
            $data_clients['reservaya_a'] = array_fill(0, count($months), 0);
        }

        if (empty($data_clients['pardepan'])) {
            $data_clients['pardepan'] = array_fill(0, count($months), 0);
        }
        foreach ($types as $type) {
            foreach ($months as $month) {
                if (!isset($reservations[$type][$month])) {
                    $reservations[$type][$month] = 0;
                }
            }
        }

         # Data por tipo
         $data_reservations = $reservations->map(function ($item) {
            return array_values($item->toArray());
        });
        if ($data_reservations->isEmpty()) {
            $data_reservations = collect([
                'event' => array_fill(0, count($months), 0),
                'waitinglist' => array_fill(0, count($months), 0),
            ]);
        } else {
            if (empty($data_reservations['event'])) {
                $data_reservations['event'] = array_fill(0, count($months), 0);
            }
        
            if (empty($data_reservations['waitinglist'])) {
                $data_reservations['waitinglist'] = array_fill(0, count($months), 0);
            }
        }
        $data_reservations2 = [];
        $waitinglist = [];

        $reservationscount = Reservation::selectRaw('DATE_FORMAT(reservation_date, "%m") as month, type, COUNT(*) as count')
        ->whereHas('table', function ($query) use ($manager) {
            $query->where('restaurant_id', $manager->restaurant_id);
        })
        ->whereNotIn('type', ['pardepan'])
        ->orWhereHas('table', function ($query) use ($manager) {
            $query->whereNull('type')
                ->where('restaurant_id', $manager->restaurant_id);
        })
        ->whereYear('reservation_date', $request->year)
        ->groupBy('month', 'type')
        ->get();
        $data4 = array_fill(0, 12, 0); // Inicializar el arreglo con 0s

        foreach ($reservationscount as $row) {
            $month = (int) $row->month - 1; // Ajustar el índice del mes (0-11)
            $data4[$month] += $row->count;
        }

        $reservationsCountClientes = Reservation::selectRaw('DATE_FORMAT(reservation_date, "%m") as month, type, COUNT(*) as count')
                            ->where('type', 'pardepan')
                            ->whereYear('reservation_date', $request->year)
                            ->whereHas('table', function ($query) use ($manager) {
                                $query->where('restaurant_id', $manager->restaurant_id);
                            })
                            ->groupBy('month', 'type')
                            ->get();
        $data5 = array_fill(0, 12, 0); // Inicializar el arreglo con 0s

        foreach ($reservationsCountClientes as $row) {
            $month = (int) $row->month - 1; // Ajustar el índice del mes (0-11)
            $data5[$month] += $row->count;
        }
        $data_clients['pardepan'] = $data5;

        $data_reservations['waitinglist'] =  $data4;
                              
        foreach ($months as $month) {
            $data_reservations2[$month] = 0;
            $waitinglist[$month] = 0;

            foreach ($reservations as $type => $typeData) {
                $data_reservations2[$month] += $typeData[$month];
             
                $waitinglist[$month] += $typeData[$month];
                
            }
        }


        ksort($data_reservations2);
        ksort($waitinglist);

        $labels = array_map(function ($month) {
            return $this->getMonthName($month);
        }, array_keys($data_reservations2));

        $data_reservations_chart = array_values($data_reservations2);
        $waitinglist_chart = array_values($waitinglist);
         # Labels de meses
         $labels_reservations = $months;

         if ($clients->isEmpty()) {
            $clients[$request->year] = [
                'reservaya_a' => array_fill_keys($months, 0),
                'pardepan' => array_fill_keys($months, 0),
            ];
        } else {
            foreach ($clients as $year => $platforms) {
                foreach ($platforms as $platform => $monthsData) {
                    if ($monthsData->isEmpty()) {
                        $clients[$year][$platform] = array_fill_keys($months, 0);
                    }
                }
            }
        }
    
        if ($reservations->isEmpty()) {
            $reservations = collect([
                'reservaya_a' => array_fill_keys($months, 0),
                'pardepan' => array_fill_keys($months, 0),
            ]);
        } else {
            foreach ($reservations as $type => $monthsData) {
                if ($monthsData->isEmpty()) {
                    $reservations[$type] = array_fill_keys($months, 0);
                }
            }
        }

        #verificar si ambos datos tienen data en el mes y si no tiene poner 0 count(): Parameter must be an array or an object


        return response()->json([
            'success' => 1,
            'platform' => $request->platform,
            'month' => $request->month,
            'year' => $request->year,
            'clients' => $clients,
            'labels' => $labels_clients,
            'data2' => $data_clients,
            'data3' => $data_reservations,
            'data4' =>$waitinglist_chart,
            'data5' =>  $reservationscount,
            'data6' =>  $data4,
        ], 200);
    }
}





