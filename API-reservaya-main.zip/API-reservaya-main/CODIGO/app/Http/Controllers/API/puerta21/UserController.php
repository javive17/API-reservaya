<?php

namespace App\Http\Controllers\API\puerta21;

use DateTime;
use Illuminate\Http\Request;

use App\Models\Catalogs\Gender;

use App\Http\Controllers\Controller;
use App\Traits\{GeneralResponse, AuxiliarFunctions};
use App\Models\{Restaurant, Client, User, Reservation};
use Illuminate\Support\Facades\Date;

class UserController extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    #protection with token
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function userTypeMonths(Request $request)
    {

        $this->validate($request, [
            'month' => 'nullable|integer',
            'year' => 'required|integer',
        ]);

        // bring all clients divided by platform, those who are platform = Otro will go to puerta_21 and those who are pardepan will go to reservation_ya, divide it by months
        $clients = Client::query();

        if ($request->month) {
            $clients = $clients->whereMonth('created_at', $request->month);
        }

        if ($request->year) {
            $clients = $clients->whereYear('created_at', $request->year);
        }

        if (!$request->platform) {

            #agrupar por año y luego poner por platform
            $clients = $clients->get()->groupBy(function ($item) {
                return $item->created_at->format('Y');
            });

            #agrupar por platform
            $clients = $clients->map(function ($item) {
                return $item->groupBy(function ($item) {
                    return $item->platform;
                });
            });

            #agrupo por mes y los mes que no tenga datos los pongo en 0
            $clients = $clients->map(function ($item) {
                return $item->map(function ($item) {
                    return $item->groupBy(function ($item) {
                        return $item->created_at->format('m');
                    });
                });
            });

            #counter
            $clients = $clients->map(function ($item) {
                return $item->map(function ($item) {
                    return $item->map(function ($item) {
                        return $item->count();
                    });
                });
            });

            #los meses que no tengan datos ponerlos en 0,
            $months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
            foreach ($months as $key => $value) {
                if (isset($clients[$request->year]['Otro'])) {
                    if (!isset($clients[$request->year]['Otro'][$value])) {
                        $clients[$request->year]['Otro'][$value] = 0;
                    }
                }

                if (isset($clients[$request->year]['pardepan'])) {
                    if (!isset($clients[$request->year]['pardepan'][$value])) {
                        $clients[$request->year]['pardepan'][$value] = 0;
                    }
                }

                if (isset($clients[$request->year]['reservaya_a'])) {
                    if (!isset($clients[$request->year]['reservaya_a'][$value])) {
                        $clients[$request->year]['reservaya_a'][$value] = 0;
                    }
                }
            }

            #ordenar por mes
            $clients = $clients->map(function ($item) {
                return $item->map(function ($item) {
                    return $item->sortBy(function ($item, $key) {
                        return $key;
                    });
                });
            });

            #labels getMonthName por platform
            $labels_clients = [
                'Otro' => [],
                'pardepan' => [],
            ];
            foreach ($clients as $key => $value) {
                foreach ($value as $key2 => $value2) {
                    foreach ($value2 as $key3 => $value3) {
                        $labels_clients[$key2][] = $this->getMonthName($key3);
                    }
                }
            }

            #verificar cual labels es mayor y dejar ese como labels
            $labels_clients = $labels_clients['Otro'] > $labels_clients['pardepan'] ? $labels_clients['Otro'] : $labels_clients['pardepan'];

            #data por platform
            $data_clients = [
                'Otro' => [],
                'pardepan' => [],
            ];
            foreach ($clients as $key => $value) {
                foreach ($value as $key2 => $value2) {
                    foreach ($value2 as $key3 => $value3) {
                        $data_clients[$key2][] = $value3;
                    }
                }
            }

            #unir y sumar los datos de reservaya_a y pardepan
            $data_clients['pardepan'] = array_map(function () {
                return array_sum(func_get_args());
            }, $data_clients['pardepan'], $data_clients['reservaya_a']);

            #verificar si ambos datos tienen data en el mes y si no tiene poner 0 count(): Parameter must be an array or an object


            return response()->json([
                'success' => 1,
                'platform' => $request->platform,
                'month' => $request->month,
                'year' => $request->year,
                'clients' => $clients,
                'labels' => $labels_clients,
                'data' => $data_clients,
            ], 200);
        }

        #agrupar por año
        $clients = $clients->get()->groupBy(function ($item) {
            return $item->created_at->format('Y');
        });

        #agrupar por mes
        $clients = $clients->map(function ($item) {
            return $item->groupBy(function ($item) {
                return $item->created_at->format('m');
            });
        });

        #counter
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->count();
            });
        });

        #labels getMonthName
        $labels_clients = [];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $labels_clients[] = $this->getMonthName($key2);
            }
        }

        #data
        $data_clients = [];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $data_clients[] = $value2;
            }
        }

        return response()->json([
            'success' => 1,
            'platform' => $request->platform,
            'month' => $request->month,
            'year' => $request->year,
            'labels' => $labels_clients,
            'data' => $data_clients,
        ], 200);
    }

    public function getYear()
    {

        #return the years you have customers
        $clients = Client::query();

        #platform pardepan and reservaya_a
        $clients = $clients->whereIn('platform', ['pardepan', 'reservaya_a']);

        $years = $clients->get()->groupBy(function ($item) {
            return $item->created_at->format('Y');
        });

        #order by year desc
        $years = $years->sortByDesc(function ($item, $key) {
            return $key;
        });

        $years = $years->keys();

        return response()->json([
            'success' => 1,
            'years' => $years,
        ], 200);
    }

    public function getUsersAgeGender(Request $request)
    {

        $this->validate(
            $request,
            [
                'date_start'    => 'nullable|date|before_or_equal:today|before_or_equal:date_end',
                'date_end'      => 'nullable|date|after_or_equal:date_start|before_or_equal:today',
            ],
            [
                'date_start.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'date_end.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );

        $clients = Client::query();

        #Mostrar solo los clientes que tiene birthday_date
        $clients = $clients->whereNotNull('birthday_date');

        #platform pardepan
        $clients = $clients->whereIn('platform', ['pardepan', 'reservaya_a']);

        if ($request->date_start) {
            $clients = $clients->whereDate('created_at', '>=', $request->date_start);
        }

        if ($request->date_end) {
            $clients = $clients->whereDate('created_at', '<=', $request->date_end);
        }

        #add age to clients
        $clients = $clients->get()->map(function ($item) {
            if ($item->birthday_date) {
                $item->age = $this->obtener_edad_segun_fecha($item->birthday_date);
            }

            #add gender to clients
            if ($item->gender_id) {
                $item->gender_name = $item->gender->name;
            } else {
                $item->gender_name = 'Sin_definir';
            }

            return $item;
        });

        #calculate and update percentages according to clients related gender_name count
        $dataFilter = [
            'Hombre' => [
                '0-17' => 0,
                '18-24' => 0,
                '25-34' => 0,
                '35-44' => 0,
                '45-54' => 0,
                '55-64' => 0,
                '65+' => 0,
            ],
            'Mujer' => [
                '0-17' => 0,
                '18-24' => 0,
                '25-34' => 0,
                '35-44' => 0,
                '45-54' => 0,
                '55-64' => 0,
                '65+' => 0,
            ],
            'Otro' => [
                '0-17' => 0,
                '18-24' => 0,
                '25-34' => 0,
                '35-44' => 0,
                '45-54' => 0,
                '55-64' => 0,
                '65+' => 0,
            ],
            'Sin_definir' => [
                '0-17' => 0,
                '18-24' => 0,
                '25-34' => 0,
                '35-44' => 0,
                '45-54' => 0,
                '55-64' => 0,
                '65+' => 0,
            ],
        ];

        $totalClients = $clients->count();

        foreach ($clients as $client) {
            foreach ($dataFilter as $key => $filter) {
                if ($client['gender_name'] == $key) {
                    foreach ($filter as $key2 => $filter2) {
                        if ($client->age >= 0 && $client->age <= 17) {
                            if ($key2 == '0-17') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 18 && $client->age <= 24) {
                            if ($key2 == '18-24') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 25 && $client->age <= 34) {
                            if ($key2 == '25-34') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 35 && $client->age <= 44) {
                            if ($key2 == '35-44') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 45 && $client->age <= 54) {
                            if ($key2 == '45-54') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 55 && $client->age <= 64) {
                            if ($key2 == '55-64') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        } elseif ($client->age >= 65) {
                            if ($key2 == '65+') {
                                $dataFilter[$key][$key2] = $dataFilter[$key][$key2] + 1;
                            }
                        }
                    }
                }
            }
        }

        $numberData = $dataFilter;

        #sacar el el porcentaje de cada uno $dataFilter = $dataFilter / $totalClients
        foreach ($dataFilter as $key => $filter) {
            foreach ($filter as $key2 => $filter2) {
                $dataFilter[$key][$key2] = round(($filter2 / $totalClients) * 100, 2);
            }
        }

        #obtener el total dataFilter
        $total_percentage = $dataFilter['Hombre']['0-17'] + $dataFilter['Hombre']['18-24'] + $dataFilter['Hombre']['25-34'] + $dataFilter['Hombre']['35-44'] + $dataFilter['Hombre']['45-54'] + $dataFilter['Hombre']['55-64'] + $dataFilter['Hombre']['65+'] + $dataFilter['Mujer']['0-17'] + $dataFilter['Mujer']['18-24'] + $dataFilter['Mujer']['25-34'] + $dataFilter['Mujer']['35-44'] + $dataFilter['Mujer']['45-54'] + $dataFilter['Mujer']['55-64'] + $dataFilter['Mujer']['65+'] + $dataFilter['Otro']['0-17'] + $dataFilter['Otro']['18-24'] + $dataFilter['Otro']['25-34'] + $dataFilter['Otro']['35-44'] + $dataFilter['Otro']['45-54'] + $dataFilter['Otro']['55-64'] + $dataFilter['Otro']['65+'] + $dataFilter['Sin_definir']['0-17'] + $dataFilter['Sin_definir']['18-24'] + $dataFilter['Sin_definir']['25-34'] + $dataFilter['Sin_definir']['35-44'] + $dataFilter['Sin_definir']['45-54'] + $dataFilter['Sin_definir']['55-64'] + $dataFilter['Sin_definir']['65+'];

        return response()->json([
            'success' => 1,
            'data' => $dataFilter,
            #redeondear a max 100 percent
            'total_percentage' => $total_percentage > 100 ? 100 : round($total_percentage, 2),
            'totalClients' => $totalClients,
            'numberData' => $numberData,
            'date' => Date('Y-m-d'),
        ], 200);
    }

    function obtener_edad_segun_fecha($fecha_nacimiento)
    {
        $nacimiento = new DateTime($fecha_nacimiento);
        $ahora = new DateTime(date("Y-m-d"));
        $diferencia = $ahora->diff($nacimiento);
        return $diferencia->format("%y");
    }

    #get users by platform 
    public function usersPlatform(Request $request)
    {

        $this->validate($request, [
            'year' => 'required|integer',
        ]);

        // bring all clients divided by platform, those who are platform = Otro will go to puerta_21 and those who are pardepan will go to reservation_ya, divide it by months
        $clients = Client::query();

        #platform pardepan and reservaya_a
        $clients = $clients->whereIn('platform', ['pardepan', 'reservaya_a']);

        if ($request->year) {
            $clients = $clients->whereYear('created_at', $request->year);
        }

        #agrupar por año y luego poner por platform
        $clients = $clients->get()->groupBy(function ($item) {
            return $item->created_at->format('Y');
        });

        #agrupar por platform
        $clients = $clients->map(function ($item) {
            return $item->groupBy(function ($item) {
                return $item->platform;
            });
        });

        #agrupo por mes y los mes que no tenga datos los pongo en 0
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->groupBy(function ($item) {
                    return $item->created_at->format('m');
                });
            });
        });

        #counter
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->map(function ($item) {
                    return $item->count();
                });
            });
        });

        #los meses que no tengan datos ponerlos en 0,
        $months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
        foreach ($months as $key => $value) {
            if (isset($clients[$request->year]['reservaya_a'])) {
                if (!isset($clients[$request->year]['reservaya_a'][$value])) {
                    $clients[$request->year]['reservaya_a'][$value] = 0;
                }
            }

            if (isset($clients[$request->year]['pardepan'])) {
                if (!isset($clients[$request->year]['pardepan'][$value])) {
                    $clients[$request->year]['pardepan'][$value] = 0;
                }
            }
        }

        #ordenar por mes
        $clients = $clients->map(function ($item) {
            return $item->map(function ($item) {
                return $item->sortBy(function ($item, $key) {
                    return $key;
                });
            });
        });

        #labels getMonthName por platform
        $labels_clients = [
            'reservaya_a' => [],
            'pardepan' => [],
        ];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                foreach ($value2 as $key3 => $value3) {
                    $labels_clients[$key2][] = $this->getMonthName($key3);
                }
            }
        }

        #verificar cual labels es mayor y dejar ese como labels
        $labels_clients = $labels_clients['reservaya_a'] > $labels_clients['pardepan'] ? $labels_clients['reservaya_a'] : $labels_clients['pardepan'];

        #data por platform
        $data_clients = [
            'reservaya_a' => [],
            'pardepan' => [],
        ];
        foreach ($clients as $key => $value) {
            foreach ($value as $key2 => $value2) {
                foreach ($value2 as $key3 => $value3) {
                    $data_clients[$key2][] = $value3;
                }
            }
        }

        #verificar si ambos datos tienen data en el mes y si no tiene poner 0 count(): Parameter must be an array or an object


        return response()->json([
            'success' => 1,
            'platform' => $request->platform,
            'month' => $request->month,
            'year' => $request->year,
            'clients' => $clients,
            'labels' => $labels_clients,
            'data' => $data_clients,
        ], 200);
    }


    public function getClients() {
            
            $clients = Client::query();

            #Filter clients by platform pardepan and reservaya_app
            $clients = $clients->where(function ($query) {
                $query->where('platform', '=', 'pardepan')
                    ->orWhere('platform', '=', 'reservaya_a');
            });

            #id 1219
            // $clients->where('id', '=', 1219);
            $clients_data = [ 
                'date'          => [],
                'date_count'    => 0,
                'datetime'      => [],
                'datetime_count'=> 0,
            ];  

            #Filter clients by birthday_date  type date or datetime
            $clients = $clients->whereNotNull('birthday_date');
            
            foreach ($clients->get() as $key => $value) {
                if (strlen($value->birthday_date) == 10) {
                    $clients_data['date'][] = $value;
                    $clients_data['date_count']++;

                    #update client platform reservaya_app
                    // $client = Client::find($value->id);
                    // $client->platform = 'reservaya_a';
                    // $client->save();
                } else {
                    $clients_data['datetime'][] = $value;
                    $clients_data['datetime_count']++;
                }
            }
    
            $clients = $clients->get();
    
            return response()->json([
                'success' => 1,
                'clients' => $clients_data,
            ], 200);
    }


    #usersVisitPlatform
    public function usersVisitPlatform(Request $request)
    {

        $this->validate(
            $request,
            [
                'date_start'    => 'nullable|date|before_or_equal:today|before_or_equal:date_end',
                'date_end'      => 'nullable|date|after_or_equal:date_start|before_or_equal:today',
            ],
            [
                'date_start.before_or_equal' => 'La fecha de inicio debe ser menor o igual a la fecha final',
                'date_end.after_or_equal' => 'La fecha final debe ser mayor o igual a la fecha de inicio',
            ]
        );

        $reservations = Reservation::query();

        #reservations the client platform pardepan and reservaya_a
        $reservations = $reservations->whereHas('client', function ($query) {
            $query->whereIn('platform', ['pardepan', 'reservaya_a']);
        });

        if ($request->date_start) {
            $reservations = $reservations->whereDate('created_at', '>=', $request->date_start);
        }

        if ($request->date_end) {
            $reservations = $reservations->whereDate('created_at', '<=', $request->date_end);
        }
        
        #agrupar por platform
        $reservations = $reservations->get()->groupBy(function ($item) {
            return $item->client->platform;
        });
        
        #contar por cliente y que no se repita por dia
        $reservations = $reservations->map(function ($item) {
            return $item->groupBy(function ($item) {
                return $item->client_id;
            });
        });

        #contar una reserva por dia
        $reservations = $reservations->map(function ($item) {
            return $item->map(function ($item) {
                return $item->groupBy(function ($item) {
                    return $item->created_at->format('Y-m-d');
                });
            });
        });

        #contar una reserva por dia
        $reservations = $reservations->map(function ($item) {
            return $item->map(function ($item) {
                return $item->map(function ($item) {
                    return $item = 1;
                });
            });
        });

        #contar contar por plataforma
        $reservations = $reservations->map(function ($item) {
            return $item->map(function ($item) {
                return $item->count();
            });
        });

        #sum
        $reservations = $reservations->map(function ($item) {
            return $item->sum();
        });

        #order by platform pardepan first
        $reservations = $reservations->sortBy(function ($item, $key) {
            return $key;
        });

        return response()->json([
            'success' => 1,
            'data'  => [
                'labels' => $reservations->keys(),
                'data' => $reservations->values(),
            ],
        ], 200);
    }

}
