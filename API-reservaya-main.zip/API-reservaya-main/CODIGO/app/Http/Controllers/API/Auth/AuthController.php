<?php



namespace App\Http\Controllers\API\Auth;



use App\Http\Controllers\Controller;

use App\Http\Requests\ForgotPassword;

use App\Http\Requests\Login;

use App\Http\Requests\ResetPassword;

use App\Services\Auth\AuthServiceInterface;

use App\Traits\AuxiliarFunctions;

use App\Traits\GeneralResponse;

use Illuminate\Http\Request;

// use Illuminate\Support\Facades\Auth;

use Auth;
use App\Models\Restaurant;
use App\Models\User;
use App\Models\Client;
use App\Models\Device;

class AuthController extends Controller

{

    use GeneralResponse;

    use AuxiliarFunctions;



    /** @var AuthServiceInterface */

    private $authService;



    public function __construct(

        AuthServiceInterface $authService

    ) {

        $this->authService = $authService;
    }



    /**

     * @group Auth

     *

     * Handles Login Request.

     *

     * @param Request $request

     *

     * @responseFile responses/auth/login-200.json

     * @responseFile 401 responses/unauthorized.json

     *

     * @return \Illuminate\Http\JsonResponse

     */
    public function deleteAccount()
    {
        $user = auth()->user();
        if(!$user){
            return $this->genResponse(0, 401, null, 'Unauthorized');

        }
        $user = User::find($user->id);
       //soft delete
        $user->deleted_at = now();
        $user->save();

        return $this->genResponse(1, 200, null, 'User deleted');


    }
    public function checkUser(Request $request)
    {   
     
        $user = auth()->user();
        $extra = Restaurant::where('owner_email', $user->email)->first();
        $accounts=[];
        if (!empty($request->token_firebase)) {
            //check if token is present in device table
            $device = Device::where('token', $request->token_firebase)->first();
            if($device) {
                            $device = Device::updateOrCreate(
                [
                    'user_id' => $user->id,
                    'token' => $request->token_firebase,
                ],
                [
                    'token'     => $request->token_firebase,
                    'platform'  => 'mobile',
                    'user_id'   => $user->id ? $user->id : null,
                    'client_id'   => $user->client ? $user->client->id : null,
                    'restaurant_id'   => $user->restaurant ? $user->restaurant->id : null,
                ]
            );
        }

        }
        if ($user->restaurant) {
            $group = $user->restaurant->owner_email;
            $extra = Restaurant::where('owner_email', $group)->get();
            $accounts= $extra->map(function ($acc) {
           

                return [

                    "name"    => $acc->name,
                    "eid" => $acc->restaurant ? $acc->encrypt_id : null,
                    "email"   => $acc->email,
                    'password' => $acc->pwd,
                ];

            });
        }
        $data = [

            'token_type'    => 'Bearer',

            'token'         => $user->createToken('Puerta21API')->accessToken,

            'role'          => $user->role->key,

            'encrypt_id'    => $user->encrypt_id,

            'client_eid'    => $user->client ? $user->client->encrypt_id : null,

            'photo'         => $user->photo,

            'restaurant_eid'    => $user->restaurant ? $user->restaurant->encrypt_id : null,
            'restaurant_name'    => $user->restaurant ? $user->restaurant->name : null,
            'extras' =>  $accounts,
            'name' => $user->name,
            'last_name' => $user->client ? $user->client->middle_name : null,

        ];
        return $this->genResponse(1, 200, $data, 'Login');

    }
    
    public function login(Login $request)

    {

        if(isset($request->google_id)){

            // return response()->json($request->all());
            $email = $request->google_email ?? $request->email;

            $verify_user = User::where('email', $email)->first();

            if(!$verify_user || !$verify_user->google_id) {

                $user_email = User::updateOrCreate(
                    [
                        'email' => $email,
                    ], 
                    [
                        'email'     => strtolower($email),
                        'email_verified_at'  => \date('Y-m-d H:i:s'),
                        'email_hash' => md5(strtolower($email)),
                        'name'      => $request->google_name, 
                        'phone'     => $request->phone,
                        'google_id' => $request->google_id,
                        'google_token' => $request->google_token,
                        'role_id'   => 2,
                        'active'    => 1,
                    ]
                );
            }else {
                #get user by email and google_id
                $user_email = User::where('email', $email)->where('google_id', $request->google_id)->first();
                
                #return errors if user not found
                if(!$user_email) {
                    return $this->genResponse(0, 401, null, 'El correo o el google id es incorrecta');
                }
            }

            if(!$user_email->encrypt_id) {
                $user_email->encrypt_id = encrypt($user_email->id);
                $user_email->save();
            }

            if(!$user_email->photo && (isset($_FILES['google_avatar']) || isset($_FILES['avatar']))) {
                #saved image in storage folder users
                $avatar = $_FILES['google_avatar'] ?? $_FILES['avatar'];
                $avatar_name = time() . '_' . $avatar['name'];
                $tmp_name = $avatar['tmp_name'];
                $avatar_path = storage_path('app/prod/users/' . $avatar_name);
                move_uploaded_file($tmp_name, $avatar_path);

                $user_email->photo = $avatar_name;
                $user_email->save();
            }

            #create client
            $client = Client::updateOrCreate(
                [
                    'user_id' => $user_email->id,
                ],
                [
                    'user_id'   => $user_email->id,
                    'first_name'      => $request->google_name,
                    'middle_name' => $request->google_middle_name ?? '',
                    'client_status_id' => 5,
                    'gender_id' => $request->gender_id ?? 3,
                    'platform' =>  $request->platform ?? 'pardepan',
                    'birthday_date' => $request->birthday_date ?? new \DateTime(),
                    'cell_phone'     => $request->phone ?? '',
                    'active'    => 1,
                ]
            );

            if(!$client->encrypt_id) {
                $client->encrypt_id = encrypt($client->id);
                $client->save();
            }

            #login auth
            $auth = auth();
                
            auth()->login($user_email);

            $user = $auth->user();

        } else {

            $loginData = $request->validated();

            $credentials = [
    
                'email_hash' => md5(strtolower($loginData['email'])),
    
                'password' => $loginData['password'],
    
            ];
    
            /** @var Illuminate\Support\Facades\Auth $auth */
    
            $auth = auth();
    
            if ($auth->attempt($credentials)) {
    
                /** @var App\Models\User $user */
    
                $user = $auth->user();
    
            } else {
    
                return $this->genResponse(0, 401, null, 'El correo o la contraseña es incorrecta');
            }
    
        }

        if (!$user->active || $user->deleted_at) {
    
            return $this->genResponse(0, 401, null, 'Correo no verificado o Usuario no activado');
        }
        if($user->deleted_at){
            return $this->genResponse(0, 401, null, 'Usuario no encontrado');
        }

        $user->last_login = \date('Y-m-d H:i:s');

        $user->save();

        $extra = Restaurant::where('owner_email', $user->email)->first();
        $accounts=[];
        if ($user->restaurant) {
            $group = $user->restaurant->owner_email;
            $extra = Restaurant::where('owner_email', $group)->get();
            $accounts= $extra->map(function ($acc) {
           

                return [

                    "name"    => $acc->name,
                    "eid" => $acc->restaurant ? $acc->encrypt_id : null,
                    "email"   => $acc->email,
                    'password' => $acc->pwd,
                ];

            });
        }
       
        $data = [

            'token_type'    => 'Bearer',

            'token'         => $user->createToken('Puerta21API')->accessToken,

            'role'          => $user->role->key,

            'encrypt_id'    => $user->encrypt_id,

            'client_eid'    => $user->client ? $user->client->encrypt_id : null,

            'client_id'     => $user->client ? $user->client->id : null,

            'photo'         => $user->photo,

            'restaurant_eid'    => $user->restaurant ? $user->restaurant->encrypt_id : null,
            'restaurant_name'    => $user->restaurant ? $user->restaurant->name : null,
            'extras' =>  $accounts,
            'name' => $user->name,
            'last_name' => $user->client ? $user->client->middle_name : null,
        ];

        if (!empty($request->token_firebase)) {
            $device = Device::updateOrCreate(
                [
                    'user_id' => $user->id,
                    'token' => $request->token_firebase,
                ],
                [
                    'token'     => $request->token_firebase,
                    'platform'  => 'web',
                    'user_id'   => $user->id ? $user->id : null,
                    'client_id'   => $user->client ? $user->client->id : null,
                    'restaurant_id'   => $user->restaurant ? $user->restaurant->id : null,
                ]
            );

        }

        return $this->genResponse(1, 200, $data, 'Login');
    }



    /**

     * @group Auth

     *

     * Forgot password

     * [Envia un correo para recuperar la contraseña].

     */

    public function forgotPassword(ForgotPassword $request)

    {

        $forgotData = $request->validated();



        [

            'message' => $message,

            'status' => $status,

            'data' => $data

        ] = $this->authService->handleForgotPassword($forgotData['email']) + ['data' => null];



        return $this->genResponse((int) (200 !== $status), $status, $data, $message);
    }



    /**

     * @group Auth

     * Reset Password

     * [Actualiza la nueva contraseña del usuario]

     */

    public function resetPassword(ResetPassword $request)

    {

        $resetData = $request->validated();



        [

            'message' => $message,

            'status' => $status

        ] = $this->authService->handleResetPassword($resetData['reset_token'], $resetData['password']);



        return $this->genResponse((int) (200 !== $status), $status, null, $message);
    }



    /**

     * @group Auth

     * Logout

     * [Cierra la sesión]

     */

    public function logout(Request $request)

    {
        $user = Auth::user();

        $tokenFirebase = $request->headers->get('tokenFirebase');
        if($tokenFirebase) {
            Device::where('token', $tokenFirebase)->where('user_id', $user->id)->update(['client_id' => null, 'restaurant_id' => null]);
        }

        $user->firebase_token = null;

        $user->save();

        /** @var Illuminate\Support\Facades\Auth $auth */

        $auth = auth();

        $auth->user()->token()->revoke();

        // $request->user()->token()->revoke();

        return $this->genResponse(1, 200, null, 'Sesión cerrada con éxito');
    }

    /**
     * emailExists

     * [Verifica si el correo existe en la base de datos]

     */
    public function emailExists(Request $request)
    {
        $email = $request->email;
        $user = User::where('email', $email)->first();
        if($user){
            return $this->genResponse(1, 200, null, 'Email exists');
        }
        return $this->genResponse(0, 401, null, 'Email not exists');
    }

    /**
     * Email by sogetech.app@gmail.com

     * [Verifica si el correo existe en la base de datos]

     */
    public function deleteTemporalUser(Request $request)
    {
        if($request->email != 'sogetech.app@gmail.com' && $request->email != 'maria.abellan.adt@gmail.com'){
            return $this->genResponse(0, 401, null, 'No autorizado');
        }
        $user = User::where('email', $request->email)->first();
        
        if($user){
            $user->client()->delete();
            $user->delete();
            return $this->genResponse(1, 200, null, 'User deleted');
        }

        return $this->genResponse(0, 404, null, 'User not found');
    }
}
