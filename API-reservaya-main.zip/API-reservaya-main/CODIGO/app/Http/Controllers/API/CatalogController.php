<?php



namespace App\Http\Controllers\API;



use App\Http\Controllers\Controller;

use App\Repositories\CatalogRepositoryInterface;

use App\Traits\GeneralResponse;

use Illuminate\Http\Request;

use App\Models\Catalogs\{Sector};


/**

 * @group Catalogs

 */

class CatalogController extends Controller

{

    use GeneralResponse;



    /** @var UserRepositoryInterface */

    private $repository;



    public function __construct(CatalogRepositoryInterface $repository)

    {

        $this->repository = $repository;

    }



    /**

     * Catalogs.

     *

     * [Regresa la lista del catalogo del api]

     *

     * @urlparam catalogName required El nombre de el catalogo Example:role, allergy, category, cost, country, day, drink, extra-service, food, gender, industry, kitchen, etc

     *

     * @param mixed $catalogName

     */

    public function getList(Request $request, $catalogName)
    {
        //return Auth::user();
        $data = $this->repository->getList($catalogName);
        #order by name alphabetically
        //return $catalogName;
        //'table-type'
        if (!$data) {

            return $this->genResponse(0, 400, ['errors' => ['model' => 'No se encontro ningun catalogo con el nombre '.$catalogName]]);

        }



        return $this->genResponse(1, 200, $data, 'Lista de recursos');

    }

    public function getSector($id) {
        $data = Sector::where('zone_id', $id)->get();

        if(!$data->isEmpty()) {
            return $this->genResponse(1, 200, $data, 'Lista de recursos');
        } else {
            return $this->genResponse(0, 400, ['errors' => ['model' => 'No se encontraron datos en la tabla '.$modelo->getTable()]]);
        }
    } 

}

