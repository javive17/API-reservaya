<?php

namespace App\Http\Controllers\API\App;

use Illuminate\Http\Request;
use App\Traits\{GeneralResponse, AuxiliarFunctions, Notification};
use App\Traits\CoordinateValidator;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserRepositoryInterface;
use App\Repositories\ClientRepositoryInterface;
use App\Services\Restaurant\ReservationServiceInterface;
use App\Repositories\RatingRepositoryInterface;
use App\Models\{Restaurant, FavoriteRestaurant, Client, Reservation};
use App\Models\Catalogs\{Cost, Kitchen, Table, TableType, Zone};
use App\Http\Requests\{StoreClientRestaurantReservation, UpdateClientRestaurantReservation};
use phpDocumentor\Reflection\Types\Null_;
use App\Jobs\SendNotifications;

class ClientRestaurantController extends Controller
{
    use GeneralResponse, AuxiliarFunctions, CoordinateValidator, Notification;

    /** @var UserRepositoryInterface */
    private $userRepository;

    /** @var ClientRepositoryInterface */
    private $clientRepository;

    /** @var RatingRepositoryInterface */
    private $ratingRepository;

    /** @var ReservationServiceInterface */
    private $reservationService;

    public function __construct(
        UserRepositoryInterface $userRepository,
        ReservationServiceInterface $reservationService,
        ClientRepositoryInterface $clientRepository,
        RatingRepositoryInterface $ratingRepository
    ) {
        $this->reservationService = $reservationService;
        $this->userRepository = $userRepository;
        $this->clientRepository = $clientRepository;
        $this->ratingRepository = $ratingRepository;
    }

    /**
     * List
     * [Regresa lista de restaurantes].
     * type = (all, distance, filters)
     */
    public function index(Request $request, $type)
    {
        $user = auth()->user();

        $types = ['all', 'distance', 'filters', 'name'];
        if (!in_array($type, $types)) {
            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');
        }

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('list_'.$type));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $restaurants = Restaurant::where(['status' => true, 'active' => true])->get();
        $filters = [];
        switch ($type) {
            case 'distance':
                $filters = [
                    'distance'  => $request->distance,
                    'latitude'  => $request->latitude,
                    'longitude' => $request->longitude,
                ];
            break;
            case 'name':
                $restaurants = Restaurant::where('name', 'like', '%' . $request->name . '%')->where(['status' => true, 'active' => true])->get();
            break;
            case 'filters':
                $restaurants = $this->restaurantFilter($request);
            break;
            default:
                # code...
            break;
        }

        $data = $this->restaurantFormat($user, $restaurants, $type, $filters);

        return $this->genResponse(1, 200, $data);

        // Cantidad de personas que ha reservado el día de hoy
    }
    /**
     * List - My favorites
     * [Regresa lista de restaurantes favoritos].
     */
    public function listMyRestaurantsFavorites()
    {
        $user = auth()->user();

        $favorites = $user->client->favorites()->where('t_favorite_restaurants.status', 1)
                                                ->where(['t_restaurants.status' => true, 't_restaurants.active' => true])
                                                ->get();

        $data = $this->restaurantFormat($user, $favorites);

        return $this->genResponse(1, 200, $data);
    }

    /**
     * List - Restaurants favorites
     * [Regresa lista de restaurantes favoritos de un cliente].
     */
    public function listRestaurantsFavorites($client_eid)
    {
        if (!$client_id = $this->getDecrypted($client_eid)) {
            return $this->genResponse(0, 400, null, 'client_eid incorrecto');
        }
        if(!$client = Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El restaurante no existe");
        }

        $favorites = $client->favorites()->where('t_favorite_restaurants.status', 1)
                                        ->where(['t_restaurants.status' => true, 't_restaurants.active' => true])
                                        ->get();

        $user = auth()->user();

        $data = $this->restaurantFormat($user, $favorites);

        return $this->genResponse(1, 200, $data);
    }
    /**
     * Show
     * [Regresa el detalle del restaurante].
     */
    public function show($restaurant_eid)
    {
        $user = auth()->user();
        $date = date('Y-m-d H:i');

        if (!$restaurant_id = $this->getDecrypted($restaurant_eid)) {
            return $this->genResponse(0, 400, null, 'restaurant_eid incorrecto');
        }
        if(!$restaurant = Restaurant::find($restaurant_id)) {
            return $this->genResponse(0, 400, null, "El restaurante no existe");
        }

        $address = $restaurant->address;

        $rating = $this->ratingRepository->getByRestaurantId($restaurant->id);

        $favorite = FavoriteRestaurant::where('client_id', $user->client->id)->where('restaurant_id', $restaurant->id)->where('status', 1)->first();

        $description = [
            'description'   => $restaurant->description,
            'phone'         => $restaurant->phone,
            'cheff_name'    => $restaurant->cheff_name,
        ];

        $photos = $restaurant->photos->map(function ($photo) {
            return [
                'id' => $photo->encrypt_id,
                'photo' => $this->getImageUrl($photo->url),
                'order' => $photo->order_photos,
            ];
        });

        // $kitchens = $restaurant->kitchens->map(function ($kitchen) {
        //     return [
        //         'id'    => $kitchen->encrypt_id,
        //         'name'  => $kitchen->name,
        //         'status'    => $kitchen->pivot->status,
        //     ];
        // });

        $kitchens = [];
        foreach($restaurant->kitchens as $kitchen){
            if($kitchen->pivot->status){
                $k = (object)[
                    'encrypt_id'    => $kitchen->encrypt_id,
                    'name'          => $kitchen->name,
                    'status'        => $kitchen->pivot->status,
                ];
                array_push($kitchens, $k);
            }
        }

        $comments = [];
        $total = 0;
        $total_rating = 0;
        foreach ($rating as $key => $value) {
            $total_rating += $value->global;
                $total += 1;
            $client = Client::find($value->client_id);

            $comment = (object)[
                "comment"   => $value->comment, 
                "reply"     => $value->reply, 
                "global"    => $value->global,
                "date"      => $value->created_at,
                "name"      => $this->clientRepository->getName($client),
                "photo"     => $this->getImageUrl($client->user->photo)
            ];
            array_push($comments, $comment);
        }

        $salida = [
            'id'        => $restaurant->encrypt_id,
            'name'      => $restaurant->name,
            'cost'      => $restaurant->cost->name,
            'photos'    => $photos,
            'favorite'  => $favorite ? true : false,
            'description'   => $description,
            'kitchens'      => $kitchens,
            'menu'          => $restaurant->menu_url,
            'address' => [
                'id'        => $address->encrypt_id,
                'latitude'  => $address->latitude,
                'longitude' => $address->longitude,
                'address'   => $address->address,
            ],
            'rating' => $this->roundRating($total, $total_rating),
            'comments' => $comments
        ];
        
        // Cantidad de personas que ha reservado el día de hoy


        return $this->genResponse(1, 200, $salida);
    }
    /**
     * Add/Remove Favorite
     * [Actualiza el estado de un favorito].
     */
    public function favoriteRestaurant(Request $request)
    {
        $validator = Validator::make($request->all(), FavoriteRestaurant::getValidationRules('create_or_update'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$restaurant_id = $this->getDecrypted($request->restaurant_eid)) {
            return $this->genResponse(0, 400, null, 'gender_eid incorrecto');
        }

        if(!Restaurant::find($restaurant_id)) {
            return $this->genResponse(0, 400, null, "El restaurante no existe");
        }

        $user = auth()->user();

        DB::table('t_favorite_restaurants')
            ->updateOrInsert(
                ['client_id' => $user->client->id, 'restaurant_id' => $restaurant_id],
                ['status'        => $request->status]
            );

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }
    /**
     * Create reservation.
     *
     * [Crea una nueva reservación en el restaurante]
     *
     * @responseFile responses/restaurant/reservations-create-200.json
     * @responseFile 400 responses/restaurant/reservations-create-400.json
     * @responseFile 401 responses/unauthorized.json
     */
    public function createReservation(StoreClientRestaurantReservation $request)
    {
        $data = $request->validated();

        $user = auth()->user();

        $client_id = $user->client->id;

        $restaurant_id = $this->getDecrypted($request->restaurant_eid);

        $validator_restaurant = Restaurant::find($restaurant_id);
    
        if(!$validator_restaurant){
            return $this->genResponse(0, 400, null,'No existe el restaurante enviado');
        }

        $table_id = $this->getDecrypted($request->table_type_eid);

        $validator_table = TableType::find($table_id);
    
        if(!$validator_table){
            return $this->genResponse(0, 400, null,'No existe la table enviada');
        }

        $comments = isset($data['comments']) ? $data['comments'] : '';

        $tableNumber = isset($data['table_number']) ? $data['table_number'] : '';

        $result = $this->reservationService->create($restaurant_id, $client_id, $table_id, $data['number_people'], $data['date'], $comments, $tableNumber);

        $information = [
            'restaurant_eid'    => $request->restaurant_eid,
            'env'               => env('APP_ENV'),
        ];

        if($result['status']==201) {
            $this->sendNotificationCMS($this->channel_restaurant, "NewReservation", $information);
        }

        return $this->genResponse((int)($result['status']==201), $result['status'],  $result['data'], $result['message']);
    }

    /**
     * Get reservation.
     *
     * [Obtener una nueva reservación]
     *
     */
    public function getReservation($reservation_eid)
    {
        $user = auth()->user();

        $reservation_id = $this->getDecrypted($reservation_eid);

        $reservation = Reservation::where('id',$reservation_id)->where('client_id', $user->client->id)->where(function ($q){
            $q->where('reservations_status_id', 1)->orWhere('reservations_status_id', 6); 
        })->first();

        $restaurant = $reservation->table->restaurant;

        $photo = isset($restaurant->photos[0]) ? $restaurant->photos[0]->url : null; // TODO
    
        if(!$reservation) {
            return $this->genResponse(0, 400, null,'No existe la reservación enviada');
        }

        $data = (object)[
            'encrypt_id'        => $reservation->encrypt_id,
            'people'            => $reservation->people,
            'reservation_date'  => $reservation->reservation_date,
            'comments'          => $reservation->comments,
            'table_eid'         => $reservation->table->type->encrypt_id,
            'restaurant'        => $restaurant->name,
            'photo'             => $this->getImageUrl($photo),
        ];
        return $this->genResponse(1, 200, $data, 'Información guardada correctamente');

    }

    /**
     * Get reservation.
     *
     * [Obtener una nueva reservación]
     *
     */
    public function updateReservation(UpdateClientRestaurantReservation $request)
    {
        $data = $request->validated();

        $user = auth()->user();

        $client_id = $user->client->id;

        $restaurant_id = $this->getDecrypted($request->restaurant_eid);

        $validator_restaurant = Restaurant::find($restaurant_id);
    
        if(!$validator_restaurant){
            return $this->genResponse(0, 400, null,'No existe el restaurante enviado');
        }

        $table_id = $this->getDecrypted($request->table_type_eid);

        $validator_table = TableType::find($table_id);
    
        if(!$validator_table){
            return $this->genResponse(0, 400, null,'No existe la table enviada');
        }

        $reservation_id = $this->getDecrypted($request->reservation_eid);
        $reservation = Reservation::where('id',$reservation_id)->where('client_id', $client_id)->where(function($q) {
            $q->where('reservations_status_id', 1)->orWhere('reservations_status_id', 6);
        })->first();
        
        if(!$reservation) {
            return $this->genResponse(0, 400, null,'No existe la reservación enviada');
        }

        $comments = isset($data['comments']) ? $data['comments'] : $reservation->comments;

        $tableNumber = isset($data['table_number']) ? $data['table_number'] : $reservation->table_number;

        $result = $this->reservationService->update($restaurant_id, $reservation_id, $client_id, $table_id, $data['number_people'], $data['date'], $comments, $tableNumber);

        $information = [
            'restaurant_eid'    => $request->restaurant_eid,
            'env'               => env('APP_ENV'),
        ];

        if($result['status']==200) {
            $this->sendNotificationCMS($this->channel_restaurant, "UpdateReservation", $information);
        }

        if(isset($request->sendNotification)){
            $obj_send_notification = (object) [
                'to' => $reservation->table->restaurant_id,
                'reservation_id' => $reservation->id,
                'title' => '¡Reserva Actualizada!',
                'body' => '¡La reserva ha sido actualizada por el cliente.!',
            ];
    
            //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
            SendNotifications::dispatch($obj_send_notification, 'restaurant')->delay(now()->addSeconds(3));
        }

        return $this->genResponse((int)($result['status']==200), $result['status'],  $result['data'], $result['message']);
    }

    /**
     * Cancel reservation.
     *
     * [Cancelar una reservación]
     *
     */
    public function cancelReservation(Request $request, $reservation_eid)
    {
        $user = auth()->user();

        $client_id = $user->client->id;
        $date = date('Y-m-d H:i');

        $reservation_id = $this->getDecrypted($reservation_eid);
        $reservation = Reservation::where('id',$reservation_id) 
                                    ->where('client_id', $client_id) 
                                    ->where('reservation_date','>', $date)
                                    ->where(function($q) {
                                        $q->where('reservations_status_id', 1)->orWhere('reservations_status_id', 6)->orWhere('reservations_status_id', 9); 
                                    })
                                    ->first();
        if(!$reservation) {
            return $this->genResponse(0, 400, null,'No existe la reservación enviadao ya no puede ser cancelada');
        }

        $reservation->reservations_status_id = $request->type_status ?? 5;
        $reservation->save();

        $data = (object)[
            "date"          => $reservation->reservation_date,
            "people"        => $reservation->people,
            'restaurant'    => $reservation->table->restaurant->name,
            'user'          => $user
        ];

        $information = [
            'restaurant_eid'    => $reservation->table->restaurant->encrypt_id,
            'env'               => env('APP_ENV'),
        ];

        $this->sendNotificationCMS($this->channel_restaurant, "CancelReservation", $information);

        if(isset($request->type_status)){
            $obj_send_notification = (object) [
                'to' => $reservation->table->restaurant_id,
                'reservation_id' => $reservation->id,
                'title' => '¡Reserva cancelada!',
                'body' => '¡Oops! la reserva ha sido cancelada por el cliente.!',
            ];
    
            //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
            SendNotifications::dispatch($obj_send_notification, 'restaurant')->delay(now()->addSeconds(3));
        }

        return $this->genResponse(1, 200, $data, 'La reservación ah sido cancelada correctamente');
    }
    /**
     * list reservation.
     *
     * [Listar reservaciones por usuario]
     *
     */
    public function listReservation($type)
    {
        $validator = ['next', 'previous'];
        if(!in_array($type, $validator)) {
            return $this->genResponse(0, 404, null, 'Valor no encontrado');
        }
        $date = date('Y-m-d H:i');
        $user = auth()->user();
        $client = $user->client;
        $query = Reservation::select('t_reservations.encrypt_id', 't_reservations.people', 't_reservations.reservation_date', 't_tables.restaurant_id', 't_ratings.client_id as rating')
                            ->join('t_tables', 't_tables.id', 't_reservations.table_id')
                            ->leftjoin('t_ratings', 't_ratings.reservation_id', 't_reservations.id')
                            ->where('t_reservations.client_id', $client->id);
        if ($type == "next") {
            $query->where('reservation_date','>', $date)->where('reservations_status_id', 1);
        } else {
            $query->where('reservation_date','<', $date)->whereIn('reservations_status_id',[2,3]);
        }

        $reservations = $query->orderBy('reservation_date',"desc")->get();

        $data = [];

        foreach ($reservations as $reservation) {
            $restaurant = Restaurant::find($reservation->restaurant_id);
            $photo = $restaurant->photos->first();
            $salida = (object)[
                'encrypt_id'        => $reservation->encrypt_id,
                'restaurant'        => $restaurant->name,
                'restaurant_eid'    => $restaurant->encrypt_id,
                'people'        => $reservation->people,
                'photo'         =>  $photo ? ($this->getImageUrl($photo->url)) : null,
                'reservation_date'  => $reservation->reservation_date,
                'rating'        => $reservation->rating ? true : false,
            ];

            array_push($data, $salida);
        }        

        return $this->genResponse(1, 200, $data, 'Información guardada correctamente');
    }

    /**
     * restaurant format.
     *
     * [Funcion para darle estructura a la información del restaurante]
     *
     */
    private function restaurantFormat($user, $restaurants, $type=null, $filters=null)
    {
        $data = [];

        foreach ($restaurants as $restaurant) {

            if($type == "filters") {
                $restaurant = Restaurant::find($restaurant->restaurant_id);
            }

            $address = $restaurant->address;
            if($type == "distance"){
                $validator_distance = $this->distance($filters['latitude'],$filters['longitude'], $address->latitude, $address->longitude, $filters['distance']);

                if(!$validator_distance){
                    continue;
                }
            }

            $rating = $this->ratingRepository->getByRestaurantId($restaurant->id);

            $favorite = FavoriteRestaurant::where('client_id', $user->client->id)->where('restaurant_id', $restaurant->id)->where('status', 1)->first();

            $photos = $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
                    'photo' => $this->getImageUrl($photo->url),
                    'order' => $photo->order_photos,
                ];
            });

            // $kitchens = $restaurant->kitchens->map(function ($kitchen) {
            //     return [
            //         'id'    => $kitchen->encrypt_id,
            //         'name'  => $kitchen->name,
            //         'status'    => $kitchen->pivot->status,
            //     ];
            // });

            $kitchens = [];
            foreach($restaurant->kitchens as $kitchen){
                if($kitchen->pivot->status){
                    $k = (object)[
                        'encrypt_id'    => $kitchen->encrypt_id,
                        'name'          => $kitchen->name,
                        'status'        => $kitchen->pivot->status,
                    ];
                    array_push($kitchens, $k);
                }
            }

            $total = 0;
            $total_rating = 0;
            foreach ($rating as $key => $value) {
                $total_rating += $value->global;
                $total += 1;
            }
        
            $salida = (object)[
                'id'        => $restaurant->encrypt_id,
                'name'      => $restaurant->name,
                'cost'      => $restaurant->cost->name,
                'photos'    => $photos,
                'kitchens'  => $kitchens,
                'clients'   => $this->getClientsFromTheDaysReservations($restaurant->id),
                'address' => [
                    'id'        => $address->encrypt_id,
                    'latitude'  => $address->latitude,
                    'longitude' => $address->longitude,
                    'address'   => $address->address,
                ],
                'favorite'  => $favorite ? true : false,
                'rating' => $this->roundRating($total, $total_rating),
            ];

            array_push($data, $salida);
        }
        return $data;
    }

    /**
     * restaurant filter.
     *
     * [funcion de validación de filtro de búsqueda de restaurante]
     *
     */
    private function restaurantFilter($request)
    {
        $costs = [];
        if($request->costs) {
            foreach ($request->costs as $value) {
                $id = $this->getDecrypted($value);
    
                $validator = Cost::find($id);
    
                if(!$validator){
                    return $this->genResponse(0, 404, null,'No existe el costo enviado');
                }
                array_push($costs, $id);
            }
        }

        $zones = [];
        if($request->zones) {
            foreach ($request->zones as $value) {
                $id = $this->getDecrypted($value);
    
                $validator = Zone::find($id);
    
                if(!$validator){
                    return $this->genResponse(0, 404, null,'No existe la zona enviada');
                }
                array_push($zones, $id);
            }
        }

        $kitchens = [];
        if($request->kitchens) {
            foreach ($request->kitchens as $value) {
                $id = $this->getDecrypted($value);
    
                $validator = Kitchen::find($id);
    
                if(!$validator){
                    return $this->genResponse(0, 404, null,'No existe la cocina enviada');
                }
                array_push($kitchens, $id);
            }
        }
        $query = DB::table('t_restaurants');

        if($request->date) {
            $numericDayWeek  = date('w', strtotime($request->date)) + 1;
            $query->join('t_restaurant_service_days', 't_restaurant_service_days.restaurant_id', 't_restaurants.id')
                    ->where(['t_restaurant_service_days.day_id' => $numericDayWeek, 't_restaurant_service_days.status' => 1]);

            if($request->hour) {
                $query->where('t_restaurant_service_days.opening', '<=' ,$request->hour)->where('t_restaurant_service_days.closing', '>=' ,$request->hour);
            }
        }

        if($kitchens) {
            $query->join('t_restaurants_kitchens', 't_restaurants_kitchens.restaurant_id', 't_restaurants.id')
                    ->where('t_restaurants_kitchens.status',true)
                    ->whereIn('t_restaurants_kitchens.kitchen_id', $kitchens);
        }
        if($costs) {
            $query->whereIn('t_restaurants.cost_id', $costs);
        }
        if($zones) {
            $query->whereIn('t_restaurants.zone_id', $zones);
        }
        $restaurants = $query->where(['t_restaurants.status' => true, 't_restaurants.active' => true])
                                ->select('t_restaurants.id as restaurant_id')->distinct()->get();

        return $restaurants;
    }

    /**
     * get clients from the days reservations
     *
     * [clientes que reservaron en el dia actual]
     *
     */
    private function getClientsFromTheDaysReservations($restaurant_id)
    {
        $clients = [];
        $reservations = Reservation::join('t_tables', 't_tables.id', 't_reservations.table_id')
                            ->where('t_tables.restaurant_id', $restaurant_id)
                            ->whereBetween('t_reservations.reservation_date', [date('Y-m-d'), date('Y-m-d', strtotime(date('Y-m-d') . '+1 day'))])
                            ->where('t_reservations.reservations_status_id', '!=' ,5)
                            ->select('t_reservations.client_id')
                            ->distinct()
                            ->get();

        foreach ($reservations as $reservation) {
            $client = Client::find($reservation->client_id);
            $name   = $this->clientRepository->getName($client);

            $data = (object)[
                "name" => $name,
                "photo" => $this->getImageUrl($client->user->photo),
            ];
            array_push($clients, $data);
        }
        return $clients;
    }

}
