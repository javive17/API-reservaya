<?php

namespace App\Http\Controllers\API\App;

use Auth;
use Illuminate\Http\Request;
use App\Mail\InvitationEmail;
use App\Traits\GeneralResponse;
use App\Http\Requests\StorePhoto;
use App\Traits\AuxiliarFunctions;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserRepositoryInterface;
use App\Repositories\ClientRepositoryInterface;
use App\Models\{SurveySpecifications, User, Client, Privacy};
use App\Models\Catalogs\{SocialMedia, Gender, Country, Profession, Industry, NutritionalRequirement, Allergy, Table, Drink, Food};

class ClientController extends Controller
{
    use GeneralResponse;
    use AuxiliarFunctions;

    /** @var UserRepositoryInterface */
    private $userRepository;

    /** @var ClientRepositoryInterface */
    private $clientRepository;

    public function __construct(
        UserRepositoryInterface $userRepository,
        ClientRepositoryInterface $clientRepository
    ) {
        $this->userRepository = $userRepository;
        $this->clientRepository = $clientRepository;
    }

    /**
     * @group App
     * Registra un usuario previamente invitado
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), User::getValidationRules('create'));
        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $data = json_decode($request->data, true);

        $validator = Validator::make($data, User::getValidationRules('validate_data'));
        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $user   = User::where('email', $data['email'])->first();

        if ($user) {
            if ($user->password || $user->active) {
                return $this->genResponse(0, 400, null, 'Su cuenta ya ha sido registrada, haga login');
            }
        }

        foreach ($data['social_media'] as $key => $value) {
            $validator = Validator::make($value, User::getValidationRules('validate_social_media'));
            if ($validator->fails()) {
                return $this->genResponse(1, 401, $validator->errors());
            }

            $social_media_id = $this->getDecrypted($value['social_media_eid']);
            if (!SocialMedia::find($social_media_id)) {
                return $this->genResponse(0, 404, null, 'No existe la social media enviada');
            }

            $data['social_media'][$key]['social_media_id'] = $social_media_id;
        }

        if (isset($data['gender_eid'])) {
            if (!$gender_id = $this->getDecrypted($data['gender_eid'])) {
                return $this->genResponse(0, 400, null, 'gender_eid incorrecto');
            } elseif (!Gender::find($gender_id)) {
                return $this->genResponse(0, 400, null, "El genero no existe");
            }
        } else {
            $gender_id = null;
        }

        if (!$country_id = $this->getDecrypted($data['country_eid'])) {
            return $this->genResponse(0, 400, null, 'country_eid incorrecto');
        } elseif (!Country::find($country_id)) {
            return $this->genResponse(0, 400, null, "El pais no existe");
        }

        if (!$user) {
            $user = $this->userRepository->createWithEncryptId($data);
        }
        $client = $this->clientRepository->findByUserId($user->id);
        if (!$client) {
            $client = $this->clientRepository->createWithEncryptId($data, $user->id);
        }

        $columns = [
            'first_name'    => $data['name'],
            'middle_name'   => $data['first_lastname'],
            'last_name'     => isset($data['second_lastname']) ? $data['second_lastname'] : null,
            'gender_id'     => $gender_id,
            'country_id'    => $country_id,
        ];

        $this->clientRepository->createSocialMedia($data['social_media'], $client->id);

        $this->clientRepository->update($columns, $client->id);

        $this->userRepository->storePhoto($request, $user);

        return $this->genResponse(1, 201, $client);
    }

    /**
     * @group Client profile
     *
     * Guardar foto del cliente
     *
     * [Guarda la foto de perfil de un cliente]
     *
     * @bodyParam image Imagen de perfil
     *
     * @param mixed $image
     */
    public function saveProfilePicture(StorePhoto $request)
    {

        $data = $request->validated();

        $user = auth()->user();

        $newPhoto = $this->userRepository->storePhoto($request, $user);

        return $this->genResponse(1, 200, $newPhoto);
    }

    /**
     * @group Client profile
     *
     * Obtener URL de foto del cliente
     *
     * [URL de la foto de perfil de un cliente]
     *
     */
    public function getProfilePicture()
    {
        $user = auth()->user();

        $data = (object)[
            'url' => $this->getImageUrl($user->photo)
        ];

        return $this->genResponse(1, 200, $data, 'Información guardada correctamente');
    }
    /**
     * @group Client profile
     *
     * Enviar invitación a un amigos
     *
     * [Enviar email de invitación a un amigo del cliente]
     *
     * @bodyParam email email del amigo
     * @bodyParam name nombre
     * @bodyParam first_lastname apellido parterno
     * @bodyParam second_lastname apellido materno
     *
     * @param string $email
     * @param string $name
     * @param string $first_lastname
     * @param string $second_lastname
     */
    public function sendInvitation(Request $request)
    {
        $validator = Validator::make($request->all(), User::getValidationRules('invitation'));

        if ($validator->fails()) {
            return $this->genResponse(0, 400, $validator->errors());
        }

        $invited   = User::where('email', $request->email)->first();

        $data = [
            'email' => $request->email,
            'name' => $request->name,
        ];

        if (!$invited) {
            $invited = $this->userRepository->createWithEncryptId($data);
        } else {
            if ($invited->role_id != 2) {
                return $this->genResponse(0, 400, null, 'No puedes invitar a este usuario');
            }
        }
        $client = $this->clientRepository->findByUserId($invited->id);
        if (!$client) {
            $client = $this->clientRepository->createWithEncryptId($data, $invited->id, 3);
        }

        $columns = [
            'first_name'    => $request->name,
            'middle_name'   => $request->first_lastname,
            'last_name'     => isset($request->second_lastname) ? $request->second_lastname : null,
        ];

        $this->clientRepository->update($columns, $client->id);

        $user = auth()->user();

        DB::table('t_client_invitations')->updateOrInsert(['client_id' => $user->client->id, 'invited_id' => $client->id], ['created_at' => date('Y-m-d H:i:s')]);

        $name = $user->client->first_name . ' ' . $user->client->middle_name;

        Mail::to($request->email)->send(new InvitationEmail($name));

        return $this->genResponse(1, 200, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar profesiones del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveProfessions(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Profession::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe la profesión enviada');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->professions()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id' => $user->client->id],
                    ['profession' => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar industrias del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveIndustries(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Industry::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe la industria enviada');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->industries()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'    => $user->client->id],
                    ['industry'     => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar requisitos alimenticios del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveNutritionalRequirements(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create_nutritional_requirement'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];
        if ($request->data) {
            foreach ($request->data as $value) {
                $id = $this->getDecrypted($value);

                $validator = NutritionalRequirement::find($id);

                if (!$validator) {
                    return $this->genResponse(0, 404, null, 'No existe el requisito alimenticio enviado');
                }
                array_push($ids, $id);
            }
        }

        $user = auth()->user();

        if ($ids) {
            $user->client->nutritional_requirements()->sync($ids);
        }

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'                => $user->client->id],
                    ['nutritional_requirement'  => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar alergias del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveAllergies(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Allergy::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe la alergia enviada');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->allergies()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'    => $user->client->id],
                    ['allergy'      => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar preferencias de mesa del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveTables(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Table::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe la preferencia enviada');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->tables()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'    => $user->client->id],
                    ['table'        => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar bebidas del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveDrinks(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Drink::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe la bebida enviada');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->drinks()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'    => $user->client->id],
                    ['drink'        => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar alimentos del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam data Ids encriptados
     * @bodyParam especification Texto especifico en caso de no existir opción en catálogo
     *
     * @param array $data
     * @param string $especification
     */
    public function saveFoods(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $ids = [];

        foreach ($request->data as $value) {
            $id = $this->getDecrypted($value);

            $validator = Food::find($id);

            if (!$validator) {
                return $this->genResponse(0, 404, null, 'No existe el alimento enviado');
            }
            array_push($ids, $id);
        }

        $user = auth()->user();

        $user->client->foods()->sync($ids);

        if ($request->especification) {
            DB::table('t_survey_specifications')
                ->updateOrInsert(
                    ['client_id'    => $user->client->id],
                    ['food'        => $request->especification]
                );
        }

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar bebida favorita adicionales del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam trademark marca de bebida
     * @bodyParam favorite_drink bebida favorita
     *
     * @param string $trademark
     * @param string $favorite_drink
     */
    public function saveFavoriteDrink(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('favorite_drink'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $user = auth()->user();

        DB::table('t_survey_specifications')
            ->updateOrInsert(
                ['client_id'    => $user->client->id],
                ['trademark'   => $request->trademark, 'favorite_drink' => $request->favorite_drink]
            );

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Guardar comentarios adicionales del cliente
     *
     * [Guarda encuesta del cliente]
     *
     * @bodyParam additional comentarios adicionales
     *
     * @param string $additional
     */
    public function saveAdditionalComments(Request $request)
    {
        $validator = Validator::make($request->all(), SurveySpecifications::getValidationRules('additional'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $user = auth()->user();

        DB::table('t_survey_specifications')
            ->updateOrInsert(
                ['client_id'    => $user->client->id],
                ['additional'   => $request->additional]
            );

        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * @group Client profile
     *
     * Consultar si el cliente ya terminó la encuesta inicial
     *
     */
    public function surveyCheck()
    {
        $data = [];
        $client = Auth::user()->client;
        $professions = $client->professions;
        $industries = $client->industries;
        $nutritional_requirements = $client->nutritional_requirements;
        $allergies = $client->allergies;
        $tables = $client->tables;
        $drinks = $client->drinks;
        $foods = $client->foods;
        $specifications = $client->specifications;
        $profession_validator = true;

        if (!$professions->count()) {
            $profession_validator = false;
            array_push($data, 'professions');
        }
        if (!$industries->count()) {
            if ($profession_validator) {
                $validator = $professions->map(function ($profession) {
                    if ($profession->id == 3) { // TODO : option EMPRESARIO/A
                        return true;
                    }
                });
                if (!is_null($validator[0])) {
                    array_push($data, 'industries');
                }
            }
        }
        // if(!$nutritional_requirements->count()){
        //     array_push($data, 'nutritional_requirements');
        // }
        if (!$allergies->count()) {
            array_push($data, 'allergies');
        }
        if (!$tables->count()) {
            array_push($data, 'tables');
        }
        if (!$drinks->count()) {
            array_push($data, 'drinks');
        }
        if (!$foods->count()) {
            array_push($data, 'foods');
        }

        if ($specifications) {
            if (!$specifications->favorite_drink) {
                array_push($data, 'favorite_drink');
            }
            if (!$specifications->additional) {
                array_push($data, 'additional_comments');
            }
        } else {
            array_push($data, 'favorite_drink');
            array_push($data, 'additional_comments');
        }

        $data = (object)[
            "status" => $data ? false : true,
            "data"  => $data
        ];

        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');
    }

    /**
     * @group Client profile
     *
     * Actualizar description del cliente
     *
     * [Guarda descripción del cliente]
     *
     * @bodyParam description
     *
     * @param string $description
     */
    public function updateDescription(Request $request)
    {
        $validator = Validator::make($request->all(), Client::getValidationRules('update_description'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $user   = auth()->user();
        $client = $user->client;
        $client->description = $request->description;
        $client->save();

        return $this->genResponse(1, 200, null, 'Descripción actualizada correctamente');
    }

    /**
     * @group Client profile
     *
     * Actualizar genero del cliente
     *
     * [Guarda género del cliente]
     *
     * @bodyParam gender_eid
     *
     * @param mixed $gender_eid
     */
    public function updateGender(Request $request)
    {
        $validator = Validator::make($request->all(), Client::getValidationRules('update_gender'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $gender_id = $this->getDecrypted($request->gender_eid);

        $validator = Gender::find($gender_id);

        if (!$validator) {
            return $this->genResponse(0, 404, null, 'No existe el género enviado');
        }

        $user   = auth()->user();
        $client = $user->client;
        $client->gender_id = $gender_id;
        $client->save();

        return $this->genResponse(1, 200, null, 'Género actualizado correctamente');
    }

    /**
     * @group Client profile
     *
     * Actualizar ubicación del cliente
     *
     * [Guarda ubicación del cliente]
     *
     * @bodyParam country_eid
     *
     * @param mixed $country_eid
     */
    public function updateCountry(Request $request)
    {
        $validator = Validator::make($request->all(), Client::getValidationRules('update_country'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $country_id = $this->getDecrypted($request->country_eid);

        $validator = Country::find($country_id);

        if (!$validator) {
            return $this->genResponse(0, 404, null, 'No existe el país enviado');
        }

        $user   = auth()->user();
        $client = $user->client;
        $client->country_id = $country_id;
        $client->save();

        return $this->genResponse(1, 200, null, 'País actualizado correctamente');
    }


    /**
     * @group Client profile
     *
     * Actualizar privacidad del cliente
     *
     * [Guarda privacidad del cliente]
     *
     * @bodyParam followed_followers
     * @bodyParam i_like_it
     * @bodyParam message_viewed
     * @bodyParam name_by_pseudonym
     *
     * @param boolean $followed_followers
     * @param boolean $i_like_it
     * @param boolean $message_viewed
     * @param boolean $name_by_pseudonym
     */
    public function savePrivacy(Request $request)
    {
        $validator = Validator::make($request->all(), Privacy::getValidationRules('privacity'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $user = auth()->user();

        DB::table('t_privacies')
            ->updateOrInsert(
                ['client_id'    => $user->client->id],
                [
                    'followed_followers'   => $request->followed_followers,
                    'i_like_it'             => $request->i_like_it,
                    'message_viewed'        => $request->message_viewed,
                    'name_by_pseudonym'     => $request->name_by_pseudonym,
                    'pseudonym'             => $request->pseudonym
                ]
            );

        return $this->genResponse(1, 200, null, 'Privacidad actualizada correctamente');
    }

    /**
     * @group Client profile
     *
     * Obtener privacidad del cliente
     *
     * [obtener privacidad del cliente]
     *
     */
    public function getPrivacy()
    {
        $user = auth()->user();

        $data = $user->client->privacy;

        return $this->genResponse(1, 200, $data, 'Privacidad actualizada correctamente');
    }

    /**
     * @group Client profile
     *
     * Consultar de información del cliente
     *
     */
    public function getProfile()
    {
        $client = Auth::user()->client;

        $gender = [];
        $country = [];

        if ($client->country) {
            $country = [
                'encrypt_id'    => $client->country->encrypt_id,
                'name'  => $client->country->name,
            ];
        }

        if ($client->gender) {
            $gender = [
                'encrypt_id'    => $client->gender->encrypt_id,
                'name'  => $client->gender->name,
            ];
        }

        $professions = $client->professions->map(function ($profession) {
            return [
                'encrypt_id'    => $profession->encrypt_id,
                'name'          => $profession->name,
            ];
        });

        $industries = $client->industries->map(function ($industry) {
            return [
                'encrypt_id'    => $industry->encrypt_id,
                'name'          => $industry->name,
            ];
        });

        $nutritional_requirements = $client->nutritional_requirements->map(function ($requirement) {
            return [
                'encrypt_id'    => $requirement->encrypt_id,
                'name'          => $requirement->name,
            ];
        });

        $allergies = $client->allergies->map(function ($allergy) {
            return [
                'encrypt_id'    => $allergy->encrypt_id,
                'name'          => $allergy->name,
            ];
        });

        $tables = $client->tables->map(function ($table) {
            return [
                'encrypt_id'    => $table->encrypt_id,
                'name'          => $table->name,
            ];
        });

        $drinks = $client->drinks->map(function ($drink) {
            return [
                'encrypt_id'    => $drink->encrypt_id,
                'name'          => $drink->name,
            ];
        });

        $foods = $client->foods->map(function ($food) {
            return [
                'encrypt_id'    => $food->encrypt_id,
                'name'          => $food->name,
            ];
        });

        $data = (object)[
            'name'                      => $this->clientRepository->getName($client),
            'description'               => $client->description,
            'gender'                    => $gender,
            'country'                   => $country,
            'professions'               => $professions,
            'industries'                => $industries,
            'nutritional_requirements'  => $nutritional_requirements,
            'allergies'                 => $allergies,
            'tables'                    => $tables,
            'drinks'                    => $drinks,
            'foods'                     => $foods,
            'specifications'            => $client->specifications,
        ];

        return $this->genResponse(1, 200, $data, 'Perfil consultado correctamente');
    }
    /**
     * @group Client profile
     *
     * Consultar de información publica del cliente
     *
     */
    public function getProfilePublic()
    {
        $user = auth()->user();

        $client = $user->client;

        $data = $this->clientRepository->getProfilePublic($client, true);

        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }
    /**
     * @group Client profile
     *
     * Consultar de información publica del cliente
     *
     */
    public function getProfilePublicPublications(Request $request)
    {
        $user = auth()->user();

        $client = $user->client;

        $publications = $this->clientRepository->getProfilePublicPublications($request, $client);

        foreach ($publications as $key => $publication) {
            $data = (object)[
                "encrypt_id"    => $publication->encrypt_id,
                "photo"         => $this->getImageUrl($publication->photo),
            ];
            $publications[$key] = $data;
        }

        return $this->genResponse(1, 200, $publications, "Información consultada correctamente");
    }

    /**
     * @group Client profile
     *
     * Consultar seguidos del cliente
     *
     */
    public function getProfilePublicFollowings(Request $request)
    {
        $user = auth()->user();

        $client = $user->client;

        $data = $this->clientRepository->getProfilePublicFollowings($request, $client);

        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }

    /**
     * @group Client profile
     *
     * Consultar seguidores del cliente
     *
     */
    public function getProfilePublicFollowers(Request $request)
    {
        $user = auth()->user();

        $client = $user->client;

        $data = $this->clientRepository->getProfilePublicFollowers($request, $client);

        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }
}
