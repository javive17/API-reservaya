<?php

namespace App\Http\Controllers\API\App;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Models\{User, Client};
use App\Traits\{AuxiliarFunctions, GeneralResponse, Notification};
use App\Repositories\{UserRepositoryInterface, ClientRepositoryInterface};
use Auth;

/**
 * @group Client notifications
 */
class ClientNotificationController extends Controller
{
    use AuxiliarFunctions, GeneralResponse, Notification;

    /** @var UserRepositoryInterface */
    private $userRepository;

    /** @var ClientRepositoryInterface */
    private $clientRepository;

    public function __construct(
        UserRepositoryInterface $userRepository,
        ClientRepositoryInterface $clientRepository
    ) {
        $this->userRepository = $userRepository;
        $this->clientRepository = $clientRepository;
    }

    /**
     * update firebase token for user
     *
     * [actualizar el token de firebase en el usuario]
     */
    public function updateFirebaseToken(Request $request)
    {
        $validator = Validator::make($request->all(), User::getValidationRules('update_firebase_token'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }
        $user = Auth::user();

        $user->firebase_token = $request->firebase_token;
        $user->save();

        return $this->genResponse(1, 200, null, 'Información guardada correctamente');
    }

    /**
     * sender notification chat
     *
     * [enviar notificación de chat]
     */
    public function sendNotificationChat(Request $request)
    {
        $validator = Validator::make($request->all(), User::getValidationRules('sender_notification_chat'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$client_id = $this->getDecrypted($request->client_eid)) {
            return $this->genResponse(0, 400, null, 'client_eid incorrecto');
        }

        if(!$client = Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El cliente no existe");
        }

        $user = Auth::user();

        $receiver = $client->user;

        $title          = "Notificación de chat";
        $description    =  $this->clientRepository->getName($user->client)." le envío un mensaje.";

        if($receiver->firebase_token && $receiver->active) {
            $this->sendNotification($receiver->firebase_token, $title, $description, $request->data);
        }

        return $this->genResponse(1, 200, null, 'Información guardada correctamente');
    }
}
