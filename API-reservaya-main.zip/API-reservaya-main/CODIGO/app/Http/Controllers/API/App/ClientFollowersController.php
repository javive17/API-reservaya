<?php

namespace App\Http\Controllers\API\App;

use App\Http\Controllers\Controller;
use App\Repositories\ClientRepositoryInterface;
use Illuminate\Support\Facades\Validator;
use App\Models\{Client, ClientBlocked, Publication, ReportPublication};
use App\Traits\{AuxiliarFunctions, GeneralResponse, Notification};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\StorePublication;
use App\Models\Catalogs\PublicationType;
// use Facade\FlareClient\Report;

/**
 * @group Client followers
 */
class ClientFollowersController extends Controller
{
    use AuxiliarFunctions, GeneralResponse, Notification;

    /** @var ClientRepositoryInterface */
    private $clientRepository;

    public function __construct(
        ClientRepositoryInterface $clientRepository
    ) {
        $this->clientRepository = $clientRepository;
    }

    /**
     * List clients
     *
     * [Lista los clientes para seguir]
     */
    public function listClients(Request $request,$type)
    {
        $types = ['all', 'search'];

        if (!in_array($type, $types)) {
            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');
        }

        if($type == 'search') {
            $validator = Validator::make($request->all(), Client::getValidationRules('search'));

            if ($validator->fails()) {
                return $this->genResponse(1, 400, $validator->errors());
            }
        }

        $user = auth()->user();

        $client = $user->client;

        $clients = $this->clientRepository->getClientList($request, $type, $client);

        foreach ($clients as $key => $client) {
            $client = Client::find($client->client_id);

            $data = (object)[
                "encrypt_id" => $client->encrypt_id,
                "name"  => $this->clientRepository->getName($client),
                "photo" => $this->getImageUrl($client->user->photo),
            ];

            $clients[$key] = $data;
        }

        return $this->genResponse(1, 200, $clients, "Información consultada correctamente");
    }

    /**
     * Show clients
     *
     * [Detalle de clientes]
     */
    public function showClient($client_eid)
    {
        $client_id = $this->getDecrypted($client_eid);
        if(!$client=Client::find($client_id)){
            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
        }

        $data = $this->clientRepository->getProfilePublic($client, false);
        
        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }

    /**
     * Show publications clients
     *
     * [Publicaciones del cliente]
     */
    public function showClientPublications(Request $request, $client_eid)
    {
        $client_id = $this->getDecrypted($client_eid);

        if(!$client=Client::find($client_id)){
            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
        }

        $publications = $this->clientRepository->getProfilePublicPublications($request, $client);


        foreach ($publications as $key => $publication) {
            $data = (object)[
                "encrypt_id"    => $publication->encrypt_id,
                "photo"         => $this->getImageUrl($publication->photo),
            ];
            $publications[$key] = $data;
        }
        
        return $this->genResponse(1, 200, $publications, "Información consultada correctamente");
    }

    /**
     * Add/Remove Follows
     * [Actualiza el estado de un follows].
     */
    public function followClient(Request $request)
    {
        $validator = Validator::make($request->all(), Client::getValidationRules('follows'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$client_id = $this->getDecrypted($request->client_eid)) {
            return $this->genResponse(0, 400, null, 'client_eid incorrecto');
        }

        if(!$client=Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El cliente no existe");
        }

        $user = auth()->user();

        if($client_id == $user->client->id) {
            return $this->genResponse(0, 400, null, " Un cliente no se puede seguir así mismo");
        }

        DB::table('t_follows')
            ->updateOrInsert(
                ['follower_id' => $user->client->id, 'following_id' => $client_id],
                ['status' => $request->status, 'follow' => date('Y-m-d')]
            );
        
        if($request->status) {
            if($client->user->firebase_token) {
                $title          = "Nuevo Seguidor";
                $description    = $this->clientRepository->getName($user->client)." ha comenzado a seguirle.";
                $information    = ['client_eid' => $request->client_eid];
                $this->sendNotification($client->user->firebase_token, $title, $description, $information);
            }
        }
        return $this->genResponse(1, 201, null, 'Información guardada correctamente');
    }

    /**
     * Create Publications
     * [Crea una nueva publicación/historia].
     */
    public function createPublication(StorePublication $request)
    {
        $request->validated();

        $publication_type_id = $this->getDecrypted($request->publication_type_eid);
        if(!PublicationType::find($publication_type_id)){
            return $this->genResponse(0, 404, null,'No existe el tipo de publicación enviado');
        }

        $user = auth()->user();

        $newPhoto = $this->clientRepository->storePublication($request, $user, $publication_type_id);

        return $this->genResponse(1, 200, $newPhoto);
    }

    /**
     * Get Publications
     * [Obtener publicación/historia].
     */
    public function getPublication($publication_eid)
    {   
        $publication_id = $this->getDecrypted($publication_eid);
        if(!$publication = Publication::find($publication_id)){
            return $this->genResponse(0, 404, null,'No existe la publicación');
        }

        $like_count = $publication->likes()->where('t_liked_publications.status', 1)->get()->count();
        $last_like  = null;
        if($like_count) {
            $client = $publication->likes->last();
            $last_like = $this->clientRepository->getName($client);
        }

        $user = auth()->user();
        $client = $publication->client;

        $validator = true;

        if($client->privacy){
            $validator = $client->privacy->i_like_it;
        }

        $like = DB::table('t_liked_publications')->where('publication_id', $publication_id)->where('client_id', $user->client->id)->where('status', 1)->first();

        $data = (object)[
            "encrypt_id"    => $publication->encrypt_id,
            "photo"         => $this->getImageUrl($publication->photo),
            "like_count"    => $validator ? $like_count : null,
            "last_like"     => $validator ? $last_like : null,
            "my_like"       => $like ? 1 : 0
        ];

        return $this->genResponse(1, 200, $data);
    }
    /**
     * Get liked
     * [Obtener lista de usuarios que dieron like a publicación].
     */
    public function listClientsWhoLikedThePublication(Request $request, $publication_eid)
    {
        $publication_id = $this->getDecrypted($publication_eid);
        if(!Publication::find($publication_id)){
            return $this->genResponse(0, 404, null,'No existe la publicación');
        }

        $clients = DB::table('t_liked_publications')
                        ->leftJoin('t_clients', 't_liked_publications.client_id', '=', 't_clients.id')
                        ->where('publication_id', $publication_id)
                        ->where('status', 1)
                        ->select('t_liked_publications.client_id', 't_clients.encrypt_id', 't_clients.description')
                        ->paginate(12);

        foreach ($clients as $key => $client) {
            $client = Client::find($client->client_id);
            $data = (object)[
                'encrypt_id'    => $client->encrypt_id,
                'name'          => $this->clientRepository->getName($client),
                'description'   => $client->description,
            ];
            $clients[$key] = $data;
        }

        return $this->genResponse(1, 200, $clients);
    }

    /**
     * Add like/dislike
     * [Agregar/quitar me gusta].
     */
    public function addLikesDislikesOnPublication(Request $request)
    {
        $validator = Validator::make($request->all(), Publication::getValidationRules('likes_dislikes'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$publication_id = $this->getDecrypted($request->publication_eid)) {
            return $this->genResponse(0, 400, null, 'publication_eid incorrecto');
        }

        if(!Publication::find($publication_id)) {
            return $this->genResponse(0, 400, null, "La publicación no existe");
        }

        $user = auth()->user();

        DB::table('t_liked_publications')
            ->updateOrInsert(
                ['publication_id' => $publication_id, 'client_id' => $user->client->id],
                ['status' => $request->status]
            );

        return $this->genResponse(1, 200, null, 'Información guardada correctamente');
    }

     /**
     * Get profile public followings
     * [Consultar seguidos del cliente].
     */
    public function getProfilePublicFollowings(Request $request, $client_eid)
    {
        $client_id = $this->getDecrypted($client_eid);

        if(!$client=Client::find($client_id)){
            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
        }

        $data = $this->clientRepository->getProfilePublicFollowings($request, $client);
        
        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }

    /**
     * Get profile public followings
     * [Consultar seguidores del cliente].
     */
    public function getProfilePublicFollowers(Request $request, $client_eid)
    {
        $client_id = $this->getDecrypted($client_eid);

        if(!$client=Client::find($client_id)){
            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
        }

        $data = $this->clientRepository->getProfilePublicFollowers($request, $client);
        
        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }

    /**
     * Sender Message 
     * [Inicializar conversación entre clientes].
     */
    public function senderMessage(Request $request)
    {
        $validator = Validator::make($request->all(), Client::getValidationRules('message'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$client_id = $this->getDecrypted($request->client_eid)) {
            return $this->genResponse(0, 400, null, 'client_eid incorrecto');
        }

        if(!Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El cliente no existe");
        }

        $user = auth()->user();

        $validator = DB::table('t_messages')->where(['sender_id' => $user->client->id, 'receiver_id' => $client_id])
                                            ->orWhere(function ($query) use ($client_id, $user) {
                                                $query->where(['sender_id' => $client_id, 'receiver_id' => $user->client->id]);
                                            })->first();

        if($validator) {
            DB::table('t_messages')->where('id', $validator->id)->update(['updated_at' => date('Y-m-d H:i:s')]);
            $encrypt_id =  $validator->encrypt_id;
        }
        else {

            DB::table('t_messages')->updateOrInsert( ['sender_id' => $user->client->id, 'receiver_id' => $client_id, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')] );
    
            $message = DB::table('t_messages')->where([ 'sender_id' => $user->client->id, 'receiver_id' => $client_id ])->first();
    
            $encrypt_id = encrypt($message->id);

            DB::table('t_messages')->where('id', $message->id)->update(['encrypt_id' => $encrypt_id]);
            
        }
        
        $data = (object)[
            "chat_eid" => $encrypt_id
        ];

        return $this->genResponse(1, 201, $data, 'Información guardada correctamente');
    }

    /**
     * List Messaging Clients 
     * [Lista de clientes a los que se enviaron mensaje].
     */
    public function getListMessagingClient(Request $request, $type)
    {
        $types = ['all', 'search'];

        if (!in_array($type, $types)) {
            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');
        }

        if($type == 'search') {
            $validator = Validator::make($request->all(), Client::getValidationRules('search'));

            if ($validator->fails()) {
                return $this->genResponse(1, 400, $validator->errors());
            }
        }

        $user = auth()->user();

        $client = $user->client;

        $clients = $this->clientRepository->getListMessagingClient($request, $type, $client);

        foreach ($clients as $key => $client) {
            $c = Client::find($client->client_id);

            $data = (object)[
                "chat_eid"  => $client->chat_eid,
                "encrypt_id" => $c->encrypt_id,
                "name"  => $this->clientRepository->getName($c),
                "photo" => $this->getImageUrl($c->user->photo),
            ];

            $clients[$key] = $data;
        }
        
        return $this->genResponse(1, 200, $clients, "Información consultada correctamente");
    }

    /**
     * Show list stories clients
     *
     * [Lista de clientes que tienen historias]
     */
    public function getClientsStories()
    {
        $user = auth()->user();

        $client = $user->client;

        $clients = $this->clientRepository->getClientStories($client->id);

        foreach ($clients as $key => $client) {
            $client = Client::find($client->client_id);

            $data = (object)[
                "encrypt_id" => $client->encrypt_id,
                "name"  => $this->clientRepository->getName($client),
                "photo" => $this->getImageUrl($client->user->photo),
            ];

            $clients[$key] = $data;
        }

        return $this->genResponse(1, 200, $clients, "Información consultada correctamente");
    }

    /**
     * Show detail stories clients
     *
     * [Historias de los cliente]
     */
    public function getStories($client_eid)
    {
        $client_id = $this->getDecrypted($client_eid);
        if(!$client=Client::find($client_id)){
            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
        }
        $user = auth()->user();

        $client = $user->client;
        $stories = $this->clientRepository->getStories($client_id, $client);


        foreach ($stories as $key => $story) {
            $data = (object)[
                "encrypt_id"    => $story->encrypt_id,
                "photo"         => $this->getImageUrl($story->photo),
                "publication_date" => $story->publication_date,
            ];
            $stories[$key] = $data;
        }
        
        return $this->genResponse(1, 200, $stories, "Información consultada correctamente");
    }
    /**
     * Show detail stories clients
     *
     * [Historias del cliente]
     */
    public function getMyStories()
    {
        $user = auth()->user();

        $client = $user->client;

        $stories = $this->clientRepository->getStories($client->id, $client);

        foreach ($stories as $key => $story) {
            $data = (object)[
                "encrypt_id"    => $story->encrypt_id,
                "photo"         => $this->getImageUrl($story->photo),
                "publication_date" => $story->publication_date,
            ];
            $stories[$key] = $data;
        }
        
        return $this->genResponse(1, 200, $stories, "Información consultada correctamente");
    }

    /**
     * block or unblock client
     *
     * [Bloquear/desbloquear un cliente]
     */
    public function blockOrUnblockClient(Request $request)
    {
        $validator = Validator::make($request->all(), ClientBlocked::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        if (!$client_id = $this->getDecrypted($request->client_blocked_eid)) {
            return $this->genResponse(0, 400, null, 'client_blocked_eid incorrecto');
        }

        if(!Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El cliente no existe");
        }

        $user = auth()->user();
        $client = $user->client;
        $client_blocked = ClientBlocked::where('client_id', $client->id)->where('client_blocked_id', $client_id)->first();

        if($client_blocked){
            $client_blocked->status = $request->status;
            $client_blocked->save();
        }
        else {
            $client_blocked = ClientBlocked::create([
                'client_id'         => $client->id,
                'client_blocked_id' => $client_id,
                'status'            => $request->status,
            ]);
        }
        return $this->genResponse(1, 200, null, "Información guardada correctamente");
    }

    /**
     * check if the client is blocked
     *
     * [Revisar si un cliente esta bloqueado o si me bloqueo]
     */
    public function checkIfTheClientIsBlocked($client_eid)
    {
        if (!$client_id = $this->getDecrypted($client_eid)) {
            return $this->genResponse(0, 400, null, 'client_blocked_eid incorrecto');
        }

        if(!Client::find($client_id)) {
            return $this->genResponse(0, 400, null, "El cliente no existe");
        }

        $user   = auth()->user();
        $client = $user->client;

        $i_blocked_him = ClientBlocked::where(['client_id' => $client->id, 'client_blocked_id' => $client_id, 'status' => 1])->first();
        $he_blocked_me = ClientBlocked::where(['client_id' => $client_id, 'client_blocked_id' => $client->id, 'status' => 1])->first();

        $i_validator    = $i_blocked_him ? true : false;
        $he_validator   = $he_blocked_me ? true : false;

        $data = (object)[
            'i_blocked_him' => $i_validator,
            'he_blocked_me' => $he_validator
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correctamente");
    }

    /**
     * report publication
     *
     * [Reportar publicación / historia]
     */
    public function reportPublication(Request $request)
    {
        $validator = Validator::make($request->all(), ReportPublication::getValidationRules('create'));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }
        if (!$publication_id = $this->getDecrypted($request->publication_eid)) {
            return $this->genResponse(0, 400, null, 'publication_eid incorrecto');
        }

        if(!Publication::find($publication_id)) {
            return $this->genResponse(0, 400, null, "La publicación no existe");
        }

        $user = auth()->user();
        $client = $user->client;

        $report_publication  = ReportPublication::where(['client_id' => $client->id, 'publication_id' => $publication_id])->first();

        if($report_publication){
            // TODO
        }
        else {
            $report_publication = ReportPublication::create([
                'client_id'         => $client->id,
                'publication_id'    => $publication_id,
                'reason'            => $request->reason,
                'report_status'     => true,
            ]);

            $report_publication->encrypt_id = encrypt($report_publication->id);
            $report_publication->save();
        }

        return $this->genResponse(1, 200, null, "Información guardada correctamente");
    }
}
