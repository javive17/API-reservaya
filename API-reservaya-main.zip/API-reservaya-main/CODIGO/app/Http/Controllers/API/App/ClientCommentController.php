<?php

namespace App\Http\Controllers\API\App;

use App\Http\Controllers\Controller;
use App\Services\Restaurant\CommentServiceInterface;
use App\Traits\AuxiliarFunctions;
use App\Traits\GeneralResponse;
use App\Http\Requests\StoreComment;
/**
 * @group Client comments
 */
class ClientCommentController extends Controller
{
    use AuxiliarFunctions;
    use GeneralResponse;

    /** @var CommentServiceInterface */
    private $commentService;

    public function __construct(
        CommentServiceInterface $commentService
    ) {
        $this->commentService = $commentService;
    }

    /**
     * Save comment
     *
     * [Contesta el comentario de el cliente hacia la reservacion]
     */
    public function store(StoreComment $request){

        $data = $request->validated();

        $user = auth()->user();

        return $this->commentService->storeComments($data, $user);
    }
}
