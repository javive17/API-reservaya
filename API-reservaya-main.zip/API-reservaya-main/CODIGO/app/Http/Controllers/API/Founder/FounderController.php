<?php



namespace App\Http\Controllers\API\Founder;



use Auth;

use Illuminate\Http\Request;

use App\Mail\{InvitationAdminEmail, AcceptedEmail, WelcomRestaurantEmail, ReportEmail, ReportedEmail};

use App\Traits\{GeneralResponse, AuxiliarFunctions, Notification};

use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Mail;

use Illuminate\Support\Facades\Validator;

use App\Repositories\{UserRepositoryInterface, ClientRepositoryInterface, ReservationRepositoryInterface, RestaurantRepositoryInterface};

use App\Models\{ User, Client, Restaurant, PaymentRestaurant, Reservation, Publication, ReportPublication};

use App\Models\Catalogs\{Kitchen, ExtraService, Zone, Cost, TableType, Day, PaymentStatus};

use App\Exports\{ClientsAcceptedExport, PaymentsRestaurantsExport, ClientsApplicationRejectedExport, ChargesExport, AdminPaymentsRestaurantsExport};

//use models offer
use App\Models\Offer;

class FounderController extends Controller

{

    use GeneralResponse, Notification, AuxiliarFunctions;



    /** @var RestaurantRepositoryInterface */

    private $restaurantRepository;



    /** @var UserRepositoryInterface */

    private $userRepository;



    /** @var ClientRepositoryInterface */

    private $clientRepository;



    /** @var ReservationRepositoryInterface */

    private $reservationRepository;



    public function __construct(

        UserRepositoryInterface $userRepository,

        ClientRepositoryInterface $clientRepository,

        ReservationRepositoryInterface $reservationRepository,

        RestaurantRepositoryInterface $restaurantRepository

    ) {

        $this->userRepository           = $userRepository;

        $this->clientRepository         = $clientRepository;

        $this->reservationRepository    = $reservationRepository;

        $this->restaurantRepository     = $restaurantRepository;

    }



    /**

     * @group Client profile

     *

     * Enviar invitación a un amigos

     *

     * [Enviar email de invitación a un amigo del cliente]

     *

     * @bodyParam email email del amigo

     * @bodyParam name nombre

     * @bodyParam first_lastname apellido parterno

     * @bodyParam second_lastname apellido materno

     *

     * @param string $email

     * @param string $name

     * @param string $first_lastname

     * @param string $second_lastname

     */

    public function sendInvitation(Request $request)

    {

        $validator = Validator::make($request->all(), User::getValidationRules('founder_invitation'));



        if ($validator->fails()) {

            return $this->genResponse(0, 400, $validator->errors());

        }



        $invited   = User::where('email', $request->email)->first();



        $data = [

            'email'     => $request->email,

            'name'      => $request->name

        ];



        $password = $this->generateRandomString();

        if(!$invited){

            $invited = $this->userRepository->createWithEncryptId($data, $password);

            $this->userRepository->verifyUserEmail($invited->id);

        }

        $client = $this->clientRepository->findByUserId($invited->id);

        if(!$client){

            $client = $this->clientRepository->createWithEncryptId($data, $invited->id, 2);

        }

         

        $columns = [

            'first_name'    => $request->name,

            'middle_name'   => $request->first_lastname,

            'last_name'     => isset($request->second_lastname) ? $request->second_lastname : null,

            'cell_phone'    => isset($request->cell_phone) ? $request->cell_phone : null,

            'collaborator'  => isset($request->collaborator) ? $request->collaborator : null,

            'friend'        => isset($request->friend) ? $request->friend : 0,

        ];



        $this->clientRepository->update($columns, $client->id);



        $user = auth()->user();



        $name = $user->name;

        

        Mail::to($request->email)->send(new InvitationAdminEmail($name, $password));



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }

    Public function offers(){
            
            $offers = Offer::all();
            //loop offers and add restaurant name
            foreach($offers as $offer){
                $restaurant = Restaurant::find($offer->restaurant_id);
                $offer->restaurant_name = $restaurant->name;
            }
            $length = count($offers);
            $offers['length'] = $length;
            $total = $length;
            $offers['total'] = $total;
            //response
            $response = [
                'data' => $offers,
                'total' => $total,
                'length' => $length,
            ];

    
            return $this->genResponse(1, 200, $response, 'Información consultada correctamente');
    }
    // Route::get('/offers/Details/{id}',                                  'API\Founder\FounderController@DetailsOffer');
    public function DetailsOffer($id){
        $offerid = $id;
        $manager = auth()->user();
        $offer = Offer::where('id',$offerid)->first();
        if($offer){
            $restaurant = Restaurant::find($offer->restaurant_id);
            $offer->restaurant_name = $restaurant->name;
            return $this->genResponse(1,200,$offer);
        }else{
            return $this->genResponse(0,404,null);
        }
    }
    //offers/edit/15
     //   Route::put('/offers/edit/{id}',                                  'API\Founder\FounderController@editOffe

    public function editOffer(Request $request, $id)
    {

    
        $offer = Offer::where('id',$id)->first();
        if($offer){
            $offer->status = $request->hasOffers;
            $offer->title = $request->title;
            $offer->description = $request->description;
           //parse dates to date format
            $offer->start_date = date('Y-m-d',strtotime($request->startDate));
            $offer->end_date = date('Y-m-d',strtotime($request->endDate));
            //type
            $offer->type = $request->type;
            //week days as 0 or 1
            $offer->monday = $request->monday;
            $offer->tuesday = $request->tuesday;
            $offer->wednesday = $request->wednesday;
            $offer->thursday = $request->thursday;
            $offer->friday = $request->friday;
            $offer->saturday = $request->saturday;
            $offer->sunday = $request->sunday;
            //dates
            $offer->dates = $request->dates;
            //repeat
            $offer->repeats = $request->repeat;
    
    
            $offer->save();
            //return response success
            return $this->genResponse(1,200,null);
        }else{
            return $this->genResponse(0,404,null);
        }
        

        //return $this->offersService->update($manager->id, $id, $data);
    }


    public function deleteOffer($id){
        $offer = Offer::find($id);
        if($offer){
            $offer->delete();
            return $this->genResponse(1, 200, null, 'Información eliminada correctamente');
        }else{
            return $this->genResponse(0, 404, null,'No existe la oferta solicitada');
        }
    }
    public function createOffer(Request $request){
        $restaurants = $request->restaurants;
        foreach($restaurants as $restaurant){
            $restaurant_id = $this->getDecrypted($restaurant['value']);
            $restaurant = Restaurant::find($restaurant_id);
            if(!$restaurant){
                return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');
            }else{
                $offrt = new Offer();
                $offrt->status = $request->hasOffers;
                $restaurantId = $restaurant->id;
                $offrt->restaurant_id = $restaurantId;
                $offrt->title = $request->title;
                $offrt->description = $request->description;
                //stard date
                $offrt->start_date = $request->startDate;
                //end date
                $offrt->end_date = $request->endDate;
                //type
                $offrt->type = $request->type;
                //week days as 0 or 1
                $offrt->monday = $request->monday;
                $offrt->tuesday = $request->tuesday;
                $offrt->wednesday = $request->wednesday;
                $offrt->thursday = $request->thursday;
                $offrt->friday = $request->friday;
                $offrt->saturday = $request->saturday;
                $offrt->sunday = $request->sunday;
                //dates
                $offrt->dates = $request->dates;
                //repeat
                $offrt->repeats = $request->repeat;
        
        
                $offrt->save();
           

            }
            
        }
        return $this->genResponse(1, 200, null, 'Información guardada correctamente');
    }

    /**

     * List clients

     *

     * [Lista los clientes - se filtran por tipo]

     */

    public function clientsList(Request $request, $client_type, $type)

    {

        $types = ['all', 'search'];

        $client_types = ['application', 'rejected', 'accepted'];



        if (!in_array($type, $types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }

        if (!in_array($client_type, $client_types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }



        if($type == 'search') {

            $validator = Validator::make($request->all(), Client::getValidationRules('search'));



            if ($validator->fails()) {

                return $this->genResponse(1, 400, $validator->errors());

            }

        }



        $user = auth()->user();



        $client = $user->client;



        switch ($client_type) {

            case 'application':

                $client_status = [3];

            break;

            case 'rejected':

                $client_status = [4];

            break;

            default:

                $client_status = [1,2];

            break;

        }

        $order_type = ['name' => 'first_name', 'collaborator' => 'collaborator'];

        $order = ['asc' => 'asc', 'desc' => 'desc'];

        $order_by = [];

        if($request->filter && $request->order){

            if(isset($order_type[$request->filter]) && isset($order[$request->order])) {

                $order_by = [$order_type[$request->filter], $order[$request->order]];

            }

        }



        $page_size = $request->pagesize ? $request->pagesize : 12;



        $clients = $this->clientRepository->listClientsFounders($request, $type, $client_status, $page_size, $order_by);



        foreach ($clients as $key => $client) {

            $client = Client::find($client->client_id);



            $invitations = $client->invitations->map(function ($invitation) {

                return [

                    "first_name"    => $invitation->first_name,

                    "middle_name"   => $invitation->middle_name,

                    "last_name"     => $invitation->last_name,

                    "date"          => $invitation->pivot->created_at,

                ];

            });





            if($client_type == "accepted") {

                $restaurants = [];



                $reservations = $client->reservations;



                foreach ($reservations as $k => $reservation) {

                    $name = $reservation->table->restaurant->name;

                    if (!in_array($name, $restaurants)) {

                        array_push($restaurants, $name);

                    }

                }

                $data = (object)[

                    "encrypt_id"    => $client->encrypt_id,

                    "first_name"    => $client->first_name,

                    "middle_name"   => $client->middle_name,

                    "last_name"     => $client->last_name,

                    "active"        => $client->user->active,

                    "photo"         => $this->getImageUrl($client->user->photo),

                    "collaborator"  => $client->collaborator,

                    "invitations"   => $invitations,

                    "friend"        => $client->friend,

                    "reservations"  => $client->reservations->count(),

                    "restaurants"   => $restaurants

                ];

            }

            else {

                $social_medias = $client->social_medias->map(function ($social_media) {

                    return [

                        'name'      => $social_media->name,

                        'url'       => $social_media->pivot->url,

                        'nickname'  => $social_media->pivot->nickname,

                    ];

                });

                

                $data = (object)[

                    "encrypt_id"    => $client->encrypt_id,

                    "first_name"    => $client->first_name,

                    "middle_name"   => $client->middle_name,

                    "last_name"     => $client->last_name,

                    "photo"         => $this->getImageUrl($client->user->photo),

                    "collaborator"  => $client->collaborator,

                    "invitations"   => $invitations,

                    "social_medias" => $social_medias,

                    "date"          => $client->created_at,

                ];

            }





            $clients[$key] = $data;

        }



        return $this->genResponse(1, 200, $clients, "Información consultada correcatmente");

    }



    /**

     * Client Reservation List

     *

     * [lista de reservaciones de los clientes]

     */

    public function clientsReservationList(Request $request, $client_eid, $type)

    {

        $types = ['all', 'search'];



        if (!in_array($type, $types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }



        if($type == 'search') {

            $validator = Validator::make($request->all(), Client::getValidationRules('search'));



            if ($validator->fails()) {

                return $this->genResponse(1, 400, $validator->errors());

            }

        }



        $client_id = $this->getDecrypted($client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');

        }



        $page_size = $request->pagesize ? $request->pagesize : 12;



        $reservations = $this->reservationRepository->clientReservationListFounders($request, $type, $client->id, $page_size);



        return $this->genResponse(1, 200, $reservations, "Información consultada correcatmente");

    }



    /**

     * List clients

     *

     * [Reporte de clientes - se filtran por tipo]

     */

    public function clientsListReport(Request $request, $client_type, $type)

    {

        $types = ['all', 'search'];

        $client_types = ['application', 'rejected', 'accepted'];



        if (!in_array($type, $types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }

        if (!in_array($client_type, $client_types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }



        if($type == 'search') {

            $validator = Validator::make($request->all(), Client::getValidationRules('search'));



            if ($validator->fails()) {

                return $this->genResponse(1, 400, $validator->errors());

            }

        }



        $user = auth()->user();



        $client = $user->client;



        switch ($client_type) {

            case 'application':

                $client_status = [3];

            break;

            case 'rejected':

                $client_status = [4];

            break;

            default:

                $client_status = [1,2];

            break;

        }



        $clients = $this->clientRepository->clientsListReport($request, $type, $client_status);



        foreach ($clients as $key => $client) {

            $client = Client::find($client->client_id);



            $invitations_array = [];

            $date = $client->created_at;

            foreach ($client->invitations as $invitation) {

                $invitations_array[] = $invitation->first_name .' '. $invitation->middle_name.' '.$invitation->last_name;

                if($date == "") {

                    $date = date('Y-m-d',strtotime($invitation->pivot->created_at));

                }

            }



            if($client_type == "accepted") {

                $restaurants = [];



                $reservations = $client->reservations;



                foreach ($reservations as $k => $reservation) {

                    $name = $reservation->table->restaurant->name;

                    if (!in_array($name, $restaurants)) {

                        array_push($restaurants, $name);

                    }

                }

                $data = (object)[

                    "first_name"    => $client->first_name,

                    "middle_name"   => $client->middle_name,

                    "last_name"     => $client->last_name,

                    "collaborator"  => $client->collaborator,

                    "invitations"   => implode(', ',$invitations_array),

                    "friend"        => $client->friend,

                    "reservations"  => $client->reservations->count(),

                    "client_status" => $client->client_status->name,

                    "restaurants"   => implode(', ',$restaurants)

                ];

            }

            else {

                $facebook = "";

                $instagram = "";

                $linkedin = "";

                foreach ($client->social_medias as $social_media) {

                    switch ($social_media->name) {

                        case 'Facebook':

                            $facebook = $social_media->pivot->url;

                        break;

                        case 'Instagram':

                            $instagram = $social_media->pivot->url;

                        break;

                        case 'LinkedIn':

                            $linkedin = $social_media->pivot->url;

                        break;

                    }

                }

                

                $data = (object)[

                    "first_name"    => $client->first_name,

                    "middle_name"   => $client->middle_name,

                    "last_name"     => $client->last_name,

                    "collaborator"  => $client->collaborator,

                    "invitations"   => implode(', ',$invitations_array),

                    "date"          => $date,

                    "facebook"      => $facebook,

                    "instagram"     => $instagram,

                    "linkedin"      => $linkedin,

                ];

            }



            $clients[$key] = $data;

        }

        

        switch ($client_type) {

            case 'accepted':

                return ( new ClientsAcceptedExport($clients) );

            break;

            default:

                return ( new ClientsApplicationRejectedExport($clients) );

            break;

        }



        return $this->genResponse(1, 200, $clients, "Información consultada correcatmente");

    }



    /**

     * Reject clients

     *

     * [Rechazar cliente]

     */

    public function rejectClient(Request $request)

    {

        $validator = Validator::make($request->all(), Client::getValidationRules('accept_reject'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $client_id = $this->getDecrypted($request->client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');

        }



        if($client->user->password && $client->user->active){

            return $this->genResponse(0, 400, null,'No puedes rechazar a un cliente que se encuentra activo');

        }



        $columns = [ 'client_status_id' => 4 ];



        $this->clientRepository->update($columns, $client->id);



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }



    /**

     * Accept clients

     *

     * [Aceptar cliente]

     */

    public function acceptClient(Request $request)

    {

        $validator = Validator::make($request->all(), Client::getValidationRules('accept_reject'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $client_id = $this->getDecrypted($request->client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');

        }



        if($client->user->password && $client->user->active){

            return $this->genResponse(0, 400, null,'No puedes aceptar a un cliente que se encuentra activo');

        }



        $this->userRepository->verifyUserEmail($client->user->id);



        $password = $this->generateRandomString();



        $columns = [ 'password' => bcrypt($password) ];



        $this->userRepository->update($columns, $client->user->id);



        $columns = [ 'client_status_id' => 1 ];



        $this->clientRepository->update($columns, $client->id);



        Mail::to($client->user->email)->send(new AcceptedEmail($password));



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }



    /**

     * Active/inactive client

     *

     * [Activar/desactivar cliente]

     */

    public function activeClient(Request $request)

    {

        $validator = Validator::make($request->all(), Client::getValidationRules('active_client'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $client_id = $this->getDecrypted($request->client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente solicitado');

        }



        $columns = $request->status ? [ 'active' => $request->status ] : [ 'active' => $request->status, 'firebase_token' => null ];



        $this->userRepository->update($columns, $client->user->id);



        $user = $client->user;

        $user->tokens()->delete();



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }



    /**

     * Delete clients

     *

     * [Eliminar cliente]

     */

    public function deleteClient($client_eid)

    {

        $client_id = $this->getDecrypted($client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente');

        }



        if($client->user->password && $client->user->active){

            return $this->genResponse(0, 400, null,'No puedes rechazar a un cliente que se encuentra activo');

        }

        

        $user = $client->user;

        // return $client->id;



        DB::table('t_client_invitations')->where('invited_id', $client->id)->delete();

        DB::table('t_social_medias')->where('client_id', $client->id)->delete();

        $client->forceDelete();

        $user->forceDelete();



        return $this->genResponse(1, 200, null, 'Información eliminada correctamente');

    }

    /**

     * Delete clients

     *

     * [Eliminar cliente]

     */

    public function addRemoveClientFriend(Request $request)

    {

        $validator = Validator::make($request->all(), Client::getValidationRules('friend'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $client_id = $this->getDecrypted($request->client_eid);

        if(!$client=Client::find($client_id)){

            return $this->genResponse(0, 404, null,'No existe el cliente');

        }



        $columns = [ 'friend' => $request->status ];



        $this->clientRepository->update($columns, $client->id);



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }

    /**

     * Create restaurants

     *

     * [Crear resturantes]

     */

    public function createRestaurant(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('store'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $kitchens_ids = [];



        foreach ($request->kitchens as $value) {

            $id = $this->getDecrypted($value);



            $validator = Kitchen::find($id);



            if(!$validator){

                return $this->genResponse(0, 404, null,'No existe el tipo de comida enviado');

            }

            array_push($kitchens_ids, $id);

        }



        $extra_services_ids = [];



        foreach ($request->extra_services as $value) {

            $id = $this->getDecrypted($value);



            $validator = ExtraService::find($id);



            if(!$validator){

                return $this->genResponse(0, 404, null,'No existe el servicio extra enviado');

            }

            array_push($extra_services_ids, $id);

        }



        $cost_id = $this->getDecrypted($request->cost_eid);



        if(!Cost::find($cost_id)){

            return $this->genResponse(0, 404, null,'No existe el costo enviado');

        }



        $zone_id = $this->getDecrypted($request->zone_eid);



        if(!Zone::find($zone_id)){

            return $this->genResponse(0, 404, null,'No existe la zona enviada');

        }



        $address = $this->restaurantRepository->createAddress($request->address, $request->latitude, $request->longitude);



        $restaurant = $this->restaurantRepository->createRestaurant($request->name, $request->owner_name, $zone_id, $cost_id, $address->id, $request->email);



        $this->restaurantRepository->createUpdateKitchens($restaurant->id, $kitchens_ids, true);



        $this->restaurantRepository->createUpdateExtraServices($restaurant->id, $extra_services_ids, true);



        $data = [

            'email'     => $request->email,

            'name'      => "Restaurante"

        ];



        $password = $this->generateRandomString();



        $user = $this->userRepository->createWithEncryptId($data, $password, 3, true);



        $this->userRepository->verifyUserEmail($user->id);



        $user->restaurant_id = $restaurant->id;

        $user->save();



        $this->restaurantRepository->validateRestaurant($restaurant->id);



        $url = $this->getRestaurantEnvironmentUrl();

        

        Mail::to($request->email)->send(new WelcomRestaurantEmail($request->email, $password, $url));

        

        return $this->genResponse(1, 200, null, 'El restaurante fue creado correctamente');

    }

    /**

     * List restaurants

     *

     * [Lista resturantes - se filtran por tipo]

     */

    public function listRestaurant(Request $request, $type)

    {

        $types = ['all', 'search'];

        $order_type = ['name' => 't_restaurants.name', 'cheff' => 't_restaurants.cheff_name', 'owner' => 't_restaurants.owner_name', 'zone' => 'c_zones.name'];

        $order = ['asc' => 'asc', 'desc' => 'desc'];

        $order_by = [];

        if($request->filter && $request->order){

            if(isset($order_type[$request->filter]) && isset($order[$request->order])) {

                $order_by = [$order_type[$request->filter], $order[$request->order]];

            }

        }



        $page_size = $request->pagesize ? $request->pagesize : 12;



        if (!in_array($type, $types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }



        if($type == 'search') {

            $validator = Validator::make($request->all(), Client::getValidationRules('search'));



            if ($validator->fails()) {

                return $this->genResponse(1, 400, $validator->errors());

            }

        }



        $restaurants = $this->restaurantRepository->getListRestaurantsFounders($request, $type, $order_by, $page_size);



        foreach ($restaurants as $key => $restaurant) {



            $restaurant = Restaurant::find($restaurant->restaurant_id);



            // $kitchens = $restaurant->kitchens->map(function ($kitchen) {

            //     return [

            //         'encrypt_id'    => $kitchen->encrypt_id,

            //         'name'          => $kitchen->name,

            //         'status'        => $kitchen->pivot->status,

            //     ];

            // });

            $kitchens = [];

            foreach($restaurant->kitchens as $kitchen){

                if($kitchen->pivot->status){

                    $k = (object)[

                        'encrypt_id'    => $kitchen->encrypt_id,

                        'name'          => $kitchen->name,

                        'status'        => $kitchen->pivot->status,

                    ];

                    array_push($kitchens, $k);

                }

            }

        

            $data = (object)[

                'encrypt_id'    => $restaurant->encrypt_id,

                'name'          => $restaurant->name,

                'owner_name'    => $restaurant->owner_name,

                'zone'          => $restaurant->zone->name,

                'kitchens'      => $kitchens,

                'cheff_name'    => $restaurant->cheff_name,

                'cost'          => $restaurant->cost->name,

                'phone'         => $restaurant->phone,

                'email'         => $restaurant->email,

                'active'        => $restaurant->active,

                'status_information' => $restaurant->status,

            ];



            $restaurants[$key] = $data;

        }

        return $this->genResponse(1, 200, $restaurants, 'Información consultada correctamente');

    }



    /**

     * Show restaurant

     *

     * [Mostar resturante]

     */

    public function showRestaurant($restaurant_eid)

    {

        $restaurant_id = $this->getDecrypted($restaurant_eid);



        if(!$restaurant = Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $data = $this->restaurantRepository->showRestaurant($restaurant);



        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');

    }



    /**

     * Store restaurant

     *

     * [Guardar fotografía]

     */

    public function storePhotos(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('store_photo'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $newPhoto = $this->restaurantRepository->storePhoto($restaurant_id, $request);



        return $this->genResponse(1, 200, $newPhoto);

    }



    /**

     * Delete Photos.

     *

     * [Eliminar la photo del restaurante]

     * 

     * @bodyParam photo_eid El id encryptado de la foto

     *

     * @param mixed $photo_eid

     * 

     */

    public function deletePhotos(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('delete_photo'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $photoId = $this->getDecrypted($request->photo_eid);



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $response = $this->restaurantRepository->deletePhoto($restaurant_id, $photoId);



        return $this->genResponse((int)($response['status']===200), $response['status'], null, $response['message']);

    }



    /**

     * Menu.

     *

     * [Actualiza la url del menu del restaurante]

     * 

     * @bodyParam menu_url La url del menu

     *

     * @param mixed $menu_url

     */

    public function updateMenu(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_menu'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $success = $this->restaurantRepository->update(['menu_url' => $request->menu_url], $restaurant_id);



        return $this->genResponse($success, 200, null);

    }



    /**

     * Capacity.

     *

     * [Actualiza la capacidad del restaurante, es decir el número de personas

     * que pueden entrar en determinada zona del restaurante]

     */

    public function updateCapacity(Request $request)

    {



        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_capacity'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $table_type_ids = $request->capacity;

        $ids = [];

        foreach ($table_type_ids as $key => $value) {

            $table_type_id = $this->getDecrypted($value['table_type_eid']);



            if(!TableType::find($table_type_id)){

                return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

            }

            array_push($ids, $table_type_id);

            $table_type_ids[$key]['table_type_id'] = $table_type_id;

        }

        

        $this->restaurantRepository->createUpdateCapacity($restaurant_id, $table_type_ids, $ids);



        $this->restaurantRepository->validateRestaurant($restaurant_id);



        return $this->genResponse(1, 200);

    }



    /**

     * Días de servicios.

     *

     * [Actualiza los dias de servicio del restaurante]

     * 

     * @bodyParam service_days.*.service_eid id required

     * @bodyParam service_days.*.opening time required

     * @bodyParam service_days.*.closing time required

     * @bodyParam service_days.*.status booelan required

     *

     * @param mixed $service_eid

     * @param mixed $opening

     * @param mixed $closing

     * @param boolean $status

     */

    public function updateServiceDays(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_service_days'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $data = $request->all();



        foreach ($data['service_days'] as $key => $value) {

            $validator = Validator::make($value, Restaurant::getValidationRules('update_service_days_body'));

            if ($validator->fails()) {

                return $this->genResponse(1, 401, $validator->errors());

            }

            $dayId = $this->getDecrypted($value['day_eid']);



            $day = Day::find($dayId);



            if(!$day){

                return $this->genResponse(0, 404, null,'No existe el day enviado');

            }

            $data['service_days'][$key]['day_id'] = $dayId;

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $this->restaurantRepository->createUpdateServiceDay($restaurant_id, $data);



        $this->restaurantRepository->validateRestaurant($restaurant_id);

        

        return $this->genResponse(1, 200, null);

    }



    /**

     * Servicios extras.

     *

     * [Actualiza los servicios extras del restaurante]

     * 

     * @bodyParam extra_service_eid El id encryptado del servicio extra

     * @bodyParam status El del servicio extra

     *

     * @param mixed $extra_service_eid

     * @param boolean $status

     */

    public function updateExtraService(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_extra_service'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $extra_services_id = $this->getDecrypted($request->extra_service_eid);



        $extra_service = ExtraService::find($extra_services_id);



        if(!$extra_service){

            return $this->genResponse(0, 404, null,'No existe el setvicio extra');

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $extra_services_ids[] = $extra_services_id;



        $this->restaurantRepository->createUpdateExtraServices($restaurant_id, $extra_services_ids, $request->status);



        return $this->genResponse(1, 200, null);

    }



    /**

     * Costo.

     *

     * [Actualiza la rango de precio del restaurante]

     * 

     * @bodyParam cost_eid El id encryptado del costo

     *

     * @param mixed $cost_eid

     */

    public function updateCost(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_cost'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $cos_id = $this->getDecrypted($request->cost_eid);



        $cost = Cost::find($cos_id);



        if(!$cost){

            return $this->genResponse(0, 404, null,'No existe el costo');

        }

        

        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $success = $this->restaurantRepository->update(['cost_id' => $cos_id], $restaurant_id);



        return $this->genResponse($success, 200);

    }



    /**

     * Kitchens.

     *

     * [Actualiza las cocinas del restaurante]

     * 

     * @bodyParam kitchen_eid El id encryptado de la cocina

     * @bodyParam status El del servicio extra

     *

     * @param mixed $kitchen_eid

     * @param boolean $status

     */

    public function updateKitchen(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_kitchen'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $kitchen_id = $this->getDecrypted($request->kitchen_eid);



        $kitchen = Kitchen::find($kitchen_id);



        if(!$kitchen){

            return $this->genResponse(0, 404, null,'No existe la cocina');

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $kitchen_ids[] = $kitchen_id;



        $this->restaurantRepository->createUpdateKitchens($restaurant_id, $kitchen_ids, $request->status);



        return $this->genResponse(1, 200, null);

    }



    /**

     * Update Address.

     *

     * [Actualiza la dirección del restaurante]

     */

    public function updateAddress(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_address'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }

      

        $this->restaurantRepository->updateAddress($restaurant_id, $request);



        $this->restaurantRepository->validateRestaurant($restaurant_id);



        return $this->genResponse(1, 200);

    }



    /**

     * Information.

     *

     * [Actualiza la información general del restaurante]

     */

    public function updateInformation(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('update_information'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }

        $data = [];

        if($request->description) {

            $data = ['description' => $request->description];

        }

        if($request->phone) {

            $data = ['phone' => $request->phone];

        }

        if($request->cheff_name) {

            $data = ['cheff_name' => $request->cheff_name];

        }



        $this->restaurantRepository->update($data, $restaurant_id);



        $this->restaurantRepository->validateRestaurant($restaurant_id);

        

        return $this->genResponse(1, 200);

    }



    /**

     * Active/inactive restaurant

     *

     * [Activar/desactivar restaurante]

     */

    public function activeRestaurant(Request $request)

    {

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('active_restaurant'));



        if ($validator->fails()) {

            return $this->genResponse(1, 400, $validator->errors());

        }



        $restaurant_id = $this->getDecrypted($request->restaurant_eid);

        if(!$restaurant=Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $columns = [ 'active' => $request->status ];



        $this->restaurantRepository->update($columns, $restaurant_id);

        

        $this->restaurantRepository->inactiveRestaurant($restaurant, $request->status);        



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }



    /**

     * List payments

     *

     * [Lista de pagos de restaurantes por mes]

     */

    public function listPayments(Request $request, $date, $type)

    {

        $pageSize  = $request->query('pagesize', 15);



        if($type == "all") {

            $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules($type));

        }

        else {

            $validator = Validator::make(["date" => $date, "name" => $request->name], PaymentRestaurant::getValidationRules($type));

        }



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $query = PaymentRestaurant::join('t_restaurants', 't_payments_restaurants.restaurant_id', '=', 't_restaurants.id')

                                ->join('c_payments_status', 't_payments_restaurants.payment_status_id', '=', 'c_payments_status.id')

                                ->select('t_payments_restaurants.encrypt_id as payment_eid','t_restaurants.encrypt_id as restaurant_eid','t_restaurants.name', 't_restaurants.active', 't_payments_restaurants.amount', 'c_payments_status.name as status', 'c_payments_status.encrypt_id as status_eid')

                                ->whereMonth('t_payments_restaurants.payment_date', $month)

                                ->whereYear('t_payments_restaurants.payment_date', $year);

        if($type == 'search'){

            $search = '%'.$request->name.'%';

            $query->where('t_restaurants.name', 'like', $search );

        }



        $payment_restaurant = $query->paginate($pageSize);



        return $this->genResponse(1, 200, $payment_restaurant, 'Información consultada correctamente');

    }



    /**

     * Payments per month

     *

     * [Total de pagos de restaurantes por mes]

     */

    public function paymentsPerMonth($date)

    {

        $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules('all'));



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $payments = PaymentRestaurant::whereMonth('t_payments_restaurants.payment_date', $month)

                                ->whereYear('t_payments_restaurants.payment_date', $year)

                                ->get();

        

        $reservations = Reservation::whereMonth('t_reservations.reservation_date', $month)

                                    ->whereYear('t_reservations.reservation_date', $year)

                                    ->get();

        $data = (object)[

            'total' => $reservations->sum('bill'),

            'total_commissions' => $payments->sum('amount'),

        ];

        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');

    }



    /**

     * Report payments

     *

     * [Reporte de pagos]

     */

    public function reportPayments($date)

    {

        $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules('all'));



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $payments = PaymentRestaurant::join('t_restaurants', 't_payments_restaurants.restaurant_id', '=', 't_restaurants.id')

                                ->join('c_payments_status', 't_payments_restaurants.payment_status_id', '=', 'c_payments_status.id')

                                ->select('t_restaurants.encrypt_id as restaurant_eid','t_restaurants.name', 't_payments_restaurants.amount', 'c_payments_status.name as status', 'c_payments_status.encrypt_id as status_eid')

                                ->whereMonth('t_payments_restaurants.payment_date', $month)

                                ->whereYear('t_payments_restaurants.payment_date', $year)

                                ->get();

        

        return ( new AdminPaymentsRestaurantsExport($payments) );

    }



    /**

     * Update payment status

     *

     * [Acutalizar estatus de pago]

     */

    public function updatePaymentStatus(Request $request)

    {

        $validator = Validator::make($request->all(), PaymentRestaurant::getValidationRules('update_status'));



        if ($validator->fails()) {

            return $this->genResponse(1, 401, $validator->errors());

        }



        $status_id = $this->getDecrypted($request->payment_status_eid);



        $status = PaymentStatus::find($status_id);



        if(!$status){

            return $this->genResponse(0, 404, null,'No existe el estatus');

        }

        

        $payment_id = $this->getDecrypted($request->payment_eid);



        if(!$payment = PaymentRestaurant::find($payment_id)){

            return $this->genResponse(0, 404, null,'No existe el pago del restaurante enviado');

        }



        $payment->payment_status_id = $status_id;

        $payment->save();



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }



    /**

     * Detail payments

     *

     * [Detalle de pago]

     */

    public function detailPayments(Request $request, $restaurant_eid, $date, $type)

    {

        $page_size  = $request->query('pagesize', 15);



        if($type == "all") {

            $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules($type));

        }

        else {

            $validator = Validator::make(["date" => $date, "name" => $request->name], PaymentRestaurant::getValidationRules($type));

        }



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $restaurant_id = $this->getDecrypted($restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $reservations = $this->reservationRepository->queryfindByRestaurantIdWithClientByMonthForFounders($restaurant_id, $month, $year, $page_size, [], $request->name);



        foreach ($reservations as $key => $reservation) {

            $client = Client::find($reservation->client_id);

            $data = (object)[

                "bill"              => $reservation->bill,

                "people"            => $reservation->people,

                "reservation_date"  => $reservation->reservation_date,

                "client_name"       => $reservation->first_name." ".$reservation->middle_name ." ". $reservation->last_name,

                "photo"             => $this->getImageUrl($client->user->photo),

                'operation'         => "$".$this->dollar.".00 USD x ".$reservation->people,

                'total_commissions' => $this->dollar * $reservation->people,

            ];



            $reservations[$key] = $data;

        }



        return $this->genResponse(1, 200, $reservations, 'Información consultada correctamente');

    }



    /**

     * Restaurant payments per month

     *

     * [Detalle de pago de resturante por mes]

     */

    public function restaurantPaymentsPerMonth($restaurant_eid, $date)

    {

        $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules('all'));



        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $restaurant_id = $this->getDecrypted($restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        

        $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')

                                    ->where(['t_tables.restaurant_id' => $restaurant_id])

                                    ->whereMonth('t_reservations.reservation_date', $month)

                                    ->whereYear('t_reservations.reservation_date', $year)

                                    ->get();

        $payments = PaymentRestaurant::whereMonth('t_payments_restaurants.payment_date', $month)

                                    ->whereYear('t_payments_restaurants.payment_date', $year)

                                    ->where('restaurant_id',$restaurant_id)

                                    ->first();

        $data = (object)[

            'total' => $reservations->sum('bill'),

            'total_commissions' => $payments->amount,

        ];

        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');

    }



    /**

     * Restaurant report payments

     *

     * [reporte]

     */

    public function restaurantReportPayments($restaurant_eid, $date)

    { 

        $validator = Validator::make(["date" => $date], PaymentRestaurant::getValidationRules('all'));

        

        if ($validator->fails()) {

            return $this->genResponse(0, 400, ['errors' => $validator->errors()]);

        }



        $restaurant_id = $this->getDecrypted($restaurant_eid);



        if(!Restaurant::find($restaurant_id)){

            return $this->genResponse(0, 404, null,'No existe el restaurante solicitado');

        }



        $year   = date('Y', strtotime($date));

        $month  = date('m', strtotime($date));



        $reservations = $this->reservationRepository->queryfindByRestaurantIdWithClientByMonthForFoundersReport($restaurant_id, $month, $year);



        foreach($reservations as $reservation) {

            $reservation->commission_to_pay = $reservation->people * $this->dollar;

            $reservation->client_name = $reservation->first_name." ".$reservation->middle_name ." ". $reservation->last_name;

        }



        // return $reservations;



        return (new ChargesExport($reservations));

    }



    /**

     * List reported publications

     *

     * [lista de publicaciones reportadas]

     */

    public function listReportedPublications(Request $request, $type)

    {

        $types = ['all', 'search'];



        $page_size = $request->pagesize ? $request->pagesize : 12;



        if (!in_array($type, $types)) {

            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');

        }



        if($type == 'search') {

            $validator = Validator::make($request->all(), Client::getValidationRules('search'));



            if ($validator->fails()) {

                return $this->genResponse(1, 400, $validator->errors());

            }

        }



        $reports = $this->clientRepository->getListReportedPublications($request, $type, $page_size);



        foreach ($reports as $key => $report) {



            $publication = Publication::find($report->publication_id);

            $client = $publication->client;

        

            $data = (object)[

                'encrypt_id'        => $publication->encrypt_id,

                "first_name"        => $client->first_name,

                "middle_name"       => $client->middle_name,

                "last_name"         => $client->last_name,

                "photo_client"      => $this->getImageUrl($client->user->photo),

                "photo"             => $this->getImageUrl($publication->photo),

                'publication_type'  => $publication->publication_type->name,

                'number_reports'    => $publication->report_publication->count(),

                'last_date'         => $publication->report_publication->last()->created_at,

                'report_status'     => $publication->report_publication->last()->report_status,

            ];



            $reports[$key] = $data;

        }

        return $this->genResponse(1, 200, $reports, 'Información consultada correctamente');

    }



    /**

     * Show reported publication

     *

     * [Detalle de las personas que reportaron]

     */

    public function showReportedPublication(Request $request, $publication_eid)

    {

        $publication_id = $this->getDecrypted($publication_eid);

        if(!$publication = Publication::find($publication_id)){

            return $this->genResponse(0, 404, null,'No existe la publicación');

        }

        

        $page_size = $request->pagesize ? $request->pagesize : 5;

        $reports = ReportPublication::where(['publication_id' => $publication_id, 'report_status' => 1])->paginate($page_size);



        foreach ($reports as $key => $report) {



            $client = $report->client;

        

            $data = (object)[

                "photo"         => $this->getImageUrl($client->user->photo),

                "first_name"    => $client->first_name,

                "middle_name"   => $client->middle_name,

                "last_name"     => $client->last_name,

                "reason"        => $report->reason,

                'date'          => $report->created_at,

            ];



            $reports[$key] = $data;

        }

        return $this->genResponse(1, 200, $reports, 'Información consultada correctamente');

    }



    /**

     * Show reported publication imagen

     *

     * [Imagen de la publicación reportada]

     */

    public function showReportedPublicationImage($publication_eid)

    {

        $publication_id = $this->getDecrypted($publication_eid);

        if(!$publication = Publication::find($publication_id)){

            return $this->genResponse(0, 404, null,'No existe la publicación');

        }



        $data = (object)[

            "photo" => $this->getImageUrl($publication->photo),

            'publication_type'  => $publication->publication_type->name,

        ];

         

        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');

    }



    /**

     * Show reported publication client

     *

     * [Información del dueño de la publicación reportada]

     */

    public function showReportedPublicationClient($publication_eid)

    {

        $publication_id = $this->getDecrypted($publication_eid);

        if(!$publication = Publication::find($publication_id)){

            return $this->genResponse(0, 404, null,'No existe la publicación');

        }

        $client = $publication->client;

        $data = (object)[

            "photo" => $this->getImageUrl($client->user->photo),

            "first_name"    => $client->first_name,

            "middle_name"   => $client->middle_name,

            "last_name"     => $client->last_name,

        ];

         

        return $this->genResponse(1, 200, $data, 'Información consultada correctamente');

    }



    /**

     * Delete publication

     *

     * [Eliminar publicación]

     */

    public function deletePublication($publication_eid)

    {

        $publication_id = $this->getDecrypted($publication_eid);

        if(!$publication = Publication::find($publication_id)){

            return $this->genResponse(0, 404, null,'No existe la publicación');

        }

        $client = $publication->client;

        $publication->report_publication->each(function ($item, $key) {

            $item->report_status = false;

            $item->save();

        });

        $publication->status = false;

        $publication->save();

        $publication->delete();



        //Send the owner

        Mail::to($client->user->email)->send(new ReportedEmail());



        foreach ($publication->report_publication as $report) {

            $client_report = Client::find($report->client_id);

            if($client_report) {

                Mail::to($client_report->user->email)->send(new ReportEmail());

            }

        }



        return $this->genResponse(1, 200, null, 'Información eliminada correctamente');

    }



    public function temporalityChiefManager() {

        $dates = DB::table('users')

                        ->select(DB::raw('MIN(created_at) as date'))

                        ->whereNotNull('restaurant_id')

                        ->groupBy('restaurant_id')

                        ->distinct()

                        ->pluck('date');



        $chief_manager = User::whereNotNull('restaurant_id')

                                ->whereIn('created_at', $dates)

                                ->get();



        $chief_manager->each(function ($item) {

            $item->chief_manager = true;

            $item->save();

        });



        return $this->genResponse(1, 200, null, 'Información guardada correctamente');

    }

}

