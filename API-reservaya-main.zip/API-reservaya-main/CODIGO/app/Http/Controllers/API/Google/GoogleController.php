<?php

namespace App\Http\Controllers\API\Google;

use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
//socialite
use Illuminate\Support\Str;
use App\Traits\GeneralResponse;



class GoogleController extends Controller
{

    use GeneralResponse;
    //parameters: email, google token, 
    public function loginOrRegister(Request $request)
    {
        //validate token, email
        $request->validate([
            'email' => 'required|email',
            'google_id' => 'required',

        ]);
        $user_email = User::where('email', $request->email)->first();

        if(!$user_email){
            return $this->genResponse(0, 401, null, 'Usuario no encontrado');
        }

        if(!$user_email->google_id){
            $user_email->google_id = $request->google_id;
            $user_email->google_token = $request->google_token;
            $user_email->save();
        }
        

        $user_login = User::where('email', $request->email)
        ->first();


        if(!$user_login){
            //create user   
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->email_hash = md5(strtolower($request->email));
            $user->google_id = $request->google_id;
//random password
            $user->password = bcrypt(Str::random(8));
            $user->save();
            //login auth
            $user = User::where('email', $request->email)->first();
            $auth = auth();
            auth()->login($user);
            $user = $auth->user();
            $data = [

                'token_type'    => 'Bearer',
    
                'token'         => $user->createToken('Puerta21API')->accessToken,
    
                'role'          => $user->role->key,
    
                'encrypt_id'    => $user->encrypt_id,
    
                'client_eid'    => $user->client ? $user->client->encrypt_id : null,
    
                'client_id'     => $user->client ? $user->client->id : null,
    
                'photo'         => $user->photo,
    
                'restaurant_eid'    => $user->restaurant ? $user->restaurant->encrypt_id : null,
                'restaurant_name'    => $user->restaurant ? $user->restaurant->name : null,
                'extras' =>  [],
                'name' => $user->name,
                'last_name' => $user->client ? $user->client->middle_name : null,
            ];
            return $this->genResponse(1, 200, $data, 'Login');  




        }else {
            #login auth
            $auth = auth();
            
            auth()->login($user_login);
            $user = $auth->user();
            $data = [

                'token_type'    => 'Bearer',
    
                'token'         => $user->createToken('Puerta21API')->accessToken,
    
                'role'          => $user->role->key,
    
                'encrypt_id'    => $user->encrypt_id,
    
                'client_eid'    => $user->client ? $user->client->encrypt_id : null,
    
                'client_id'     => $user->client ? $user->client->id : null,
    
                'photo'         => $user->photo,
    
                'restaurant_eid'    => $user->restaurant ? $user->restaurant->encrypt_id : null,
                'restaurant_name'    => $user->restaurant ? $user->restaurant->name : null,
                'extras' => [],
                'name' => $user->name,
                'last_name' => $user->client ? $user->client->middle_name : null,
            ];

            return $this->genResponse(1, 200, $data, 'Login');  }
    }

}
