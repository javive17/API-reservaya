<?php

namespace App\Http\Controllers\API\pardepan;

use App\Models\User;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Traits\{GeneralResponse, AuxiliarFunctions};

class ClientController extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    /**
     * @group App pardepan
     * Registra un usuario desde la web pardepan
    */
    public function register(Request $request)
    {
        #Validate type login
        $type_login = $request->type_login ?? null;

        #validate data 
        $validator = Validator::make($request->all(), [
            'first_name'            => 'required|string',
            'middle_name'           => $type_login != 'google' ? 'required|string' : 'nullable',
            'email'                 => 'required|email|unique:users',
            'password'              => $type_login != 'google' ? 'required|string|min:6' : 'nullable',
            'password_confirmation' => $type_login != 'google' ? 'required|string|min:6|same:password' : 'nullable',
            'phone'                 => 'nullable|max:45|min:3',
            'avatar'                => $type_login != 'google' ? 'required|image|mimes:jpeg,png,jpg,gif,svg|max:8000' : 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:8000',
            'birthday_date'         => $type_login != 'google' ? 'required|date' : 'nullable|date',
            'platform'              => 'nullable|string',
            'gender_id'             => 'nullable|integer|min:1|max:3',
            'google_id'             => $type_login == 'google' ? 'required|string' : 'nullable',
            'google_token'          => $type_login == 'google' ? 'required|string' : 'nullable',
            'google_refresh_token'  => 'nullable|string',
        ], [
            'first_name.required' => 'El nombre es requerido',
            'middle_name.required' => 'El apellido es requerido',
            'email.required' => 'El correo es requerido',
            'email.email' => 'El correo no es valido',
            'email.unique' => 'El correo ya esta registrado',
            'password.required' => 'La contraseña es requerida',
            'password.min' => 'La contraseña debe tener al menos 6 caracteres',
            'password_confirmation.required' => 'La confirmación de la contraseña es requerida',
            'password_confirmation.min' => 'La confirmación de la contraseña debe tener al menos 6 caracteres',
            'password_confirmation.same' => 'Las contraseñas no coinciden',
            'phone.required' => 'El teléfono es requerido',
            'phone.max' => 'El teléfono no es valido',
            'phone.min' => 'El teléfono no es valido',
            'avatar.required' => 'La foto es requerida',
            'avatar.image' => 'La foto no es valida',
            'avatar.mimes' => 'La foto no es valida',
            'avatar.max' => 'La foto no debe pesar mas de 8MB',
            'birthday_date.required' => 'La fecha de nacimiento es requerida',
            'birthday_date.date' => 'La fecha de nacimiento no es valida',
            'platform.required' => 'La plataforma es requerida',
            'gender_id.min'       => 'La identificación de género debe ser al menos 1.',
            'gender_id.max'       => 'La identificación de género debe ser máximo 3.',
            'google_id.required' => 'El id de google es requerido',
            'google_token.required' => 'El token de google es requerido',
        ], [
            'first_name' => 'Nombre',
            'middle_name' => 'Apellido',
            'email' => 'Correo', 
            'password' => 'Contraseña',
            'password_confirmation' => 'Confirmación de contraseña',
            'phone' => 'Teléfono',
            'avatar' => 'Foto',
            'birthday_date' => 'Fecha de nacimiento',
            'platform' => 'Plataforma',
            'gender_id' => 'Género',
            'google_id' => 'Id de google',
            'google_token' => 'Token de google',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        #saved image in storage folder users
        $avatar = $_FILES['avatar'];
        $avatar_name = time() . '_' . $avatar['name'];
        $tmp_name = $avatar['tmp_name'];
        $avatar_path = storage_path('app/prod/users/' . $avatar_name);
        move_uploaded_file($tmp_name, $avatar_path);

        #create user
        $user = User::create([
            'name' => $request->first_name . ' ' . $request->last_name,
            'email' => strtolower($request->email),
            'email_hash' => md5(strtolower($request->email)),
            'email_verified_at'  => \date('Y-m-d H:i:s'),
            'password' => bcrypt($request->password),
            'phone' => $request->phone,
            'active' => 1,
            'role_id' => 2,
            'photo' => $avatar_name,
            'google_id' => $request->google_id,
            'google_token' => $request->google_token,
            'google_refresh_token' => $request->google_refresh_token,
        ]);
        $user->encrypt_id = encrypt($user->id);
        $user->save();

        #create client
        $client = Client::create([
            'first_name' => $request->first_name,
            'middle_name' => $request->middle_name,
            'cell_phone' => $request->phone,
            'user_id' => $user->id,
            'client_status_id' => 5,
            'gender_id' => $request->gender_id ?? 3,
            'platform' => $request->platform ?? 'pardepan',
            'birthday_date' => $request->birthday_date,
        ]);
        $client->encrypt_id = encrypt($client->id);
        $client->save();

        $client->gender;

        return response()->json([
            'success' => 1, 
            'message' => 'Usuario registrado correctamente',
            'user' => $user, 
            'client' => $client
        ], 200);
    }

    /**
     * @group App pardepan
     * get data un usuario desde la web pardepan
    */
    public function edit($id)
    {
        $client = Client::find(decrypt($id));
        if (!$client) {
            return response()->json([
                'success' => 0, 
                'message' => 'No se encontró el cliente'
            ], 404);
        }

        return response()->json([
            'success' => 1, 
            'data' => [
                'first_name'            => $client->first_name,
                'middle_name'           => $client->middle_name,
                'email'                 => $client->user->email,
                'phone'                 => $client->cell_phone, 
                'birthday_date'         => $client->birthday_date,
                'photo'                 => $client->user->photo,
                'gender_id'             => $client->gender_id ?? 3,
                'platform'              => $client->platform ?? 'pardepan',
            ]
        ], 200);

    }

    /**
     * @group App pardepan
     * Actualiza un usuario desde la web pardepan
    */
    public function update(Request $request)
    {

        $client = Client::find(decrypt($request->client_id));
        
        if (!$client) {
            return response()->json([
                'success' => 0, 
                'message' => 'No se encontró el cliente'
            ], 404);
        }
        #validate data 
        $validator = Validator::make($request->all(), [
            'first_name'            => 'required|string',
            'middle_name'           => 'required|string',
            'email'                 => ['required', 'email', Rule::unique('users')->whereNull('deleted_at')->ignore($client->user_id)],
            'phone'                 => 'nullable|max:45|min:3',
            'avatar'                => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:8000',
            'birthday_date'         => 'required|date',
            'gender_id'             => 'nullable|integer|min:1|max:3',
        ],
        [
            'gender_id.min'       => 'La identificación de género debe ser al menos 1.',
            'gender_id.max'       => 'La identificación de género debe ser máximo 3.',
        ], [
            'first_name' => 'Nombre',
            'middle_name' => 'Apellido',
            'email' => 'Correo', 
            'phone' => 'Teléfono',
            'avatar' => 'Foto',
            'birthday_date' => 'Fecha de nacimiento',
            'gender_id' => 'Género',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $avatar = $_FILES['avatar'] ?? null;
        
        if($avatar) {

            #delete old image
            $old_avatar = $client->user->photo_name;
            if($old_avatar) {
                $old_avatar_path = storage_path('app/prod/users/' . $old_avatar);
                if(file_exists($old_avatar_path)){
                    unlink($old_avatar_path);
                }
            }

            #saved image in storage folder users
            $avatar_name = time() . '_' . $avatar['name'];
            $tmp_name = $avatar['tmp_name'];
            $avatar_path = storage_path('app/prod/users/' . $avatar_name);
            move_uploaded_file($tmp_name, $avatar_path);
            $client->user->photo = $avatar_name;
        }

        #update user
        $client->user->name = $request->first_name . ' ' . $request->last_name;
        $client->user->email = strtolower($request->email);
        $client->user->email_hash = md5(strtolower($request->email));
        $client->user->phone = $request->phone;
        $client->user->save();

        #update client
        $client->first_name = $request->first_name;
        $client->middle_name = $request->middle_name;
        $client->cell_phone = $request->phone;
        $client->birthday_date = $request->birthday_date;
        $client->gender_id = $request->gender_id ?? 3;
        $client->save();
        $client->refresh();

        $client->gender;

        return response()->json([
            'success' => 1, 
            'message' => 'Usuario actualizado correctamente',
            'user' => $client->user, 
            'client' => $client
        ], 200);

    }

    public function resetPassword(Request $request) { 

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'token' => 'required',
            'password' => 'required|min:6',
        ]);
        
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        if (!Hash::check('secret_123_5423TY', $request->token)) {
            return response()->json([
                'success' => 0, 
                'message' => 'Token invalido'
            ], 404);
        }

        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return response()->json([
                'success' => 0, 
                'message' => 'No se encontró el usuario'
            ], 404);
        }
        $user->password = bcrypt($request->password);
        $user->save();
        return response()->json([
            'success' => 1, 
            'message' => 'Contraseña actualizada correctamente',
            'user' => $user
        ], 200);
    }

    public function getUserEmail(Request $request) { 

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ]);
        
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        if (!Hash::check('secret_123_5423TY', $request->token)) {
            return response()->json([
                'success' => 0, 
                'message' => 'Token invalido'
            ], 404);
        }

        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return response()->json([
                'success' => 0, 
                'message' => 'No se encontró el usuario'
            ], 404);
        }
        return response()->json([
            'success' => 1, 
            'message' => 'Usuario encontrado',
            'user' => $user->client
        ], 200);
    }

}
