<?php

namespace App\Http\Controllers\API\pardepan;

use App\Models\{Restaurant, Client, Reservation, Table, FavoriteRestaurant};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

use App\Repositories\{ReservationRepositoryInterface, RatingRepositoryInterface};
use App\Services\Restaurant\ReservationServiceInterface;
use App\Traits\{GeneralResponse, AuxiliarFunctions};
use App\Http\Requests\ReservationAvailabilityRequest;
use App\Http\Requests\StoreRestaurantReservation;
use App\Models\Catalogs\TableType;
use App\Models\Offer;


class RestaurantController extends Controller
{

    use GeneralResponse, AuxiliarFunctions;

     /** @var RatingRepositoryInterface */
     private $ratingRepository;

    /** @var ReservationServiceInterface */
    private $reservationService;

    /** @var ReservationRepositoryInterface */
    private $reservationRepository;


    public function __construct(
        ReservationServiceInterface $reservationService,
        RatingRepositoryInterface $ratingRepository,
        ReservationRepositoryInterface $reservationRepository
    ) {

        $this->reservationService = $reservationService;
        $this->ratingRepository = $ratingRepository;
        $this->reservationRepository = $reservationRepository; 
    }

    /**
     * List
     * [Regresa lista de restaurantes].
     * type = (all, distance, filters)
     */
    public function index(Request $request)
    {
        $restaurants = Restaurant::where(['status' => true, 'active' => true])->orderBy('created_at', 'DESC');

        if(isset($request->limit)){
            $restaurants = $restaurants->paginate($request->limit);
        }else {
            $restaurants = $restaurants->paginate(10000);
        }

        foreach ($restaurants as $key => $restaurant) {
            $restaurant->RankingPercentage = $restaurant->ranking_percentage;
            $testid = $restaurant->id;
            $offers_all = $this->restaurantOffers($restaurant->id);
            $photos = $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
                    'photo' => $this->getImageUrl($photo->url),
                    'thumbnail' => $photo->thumbnail,
                    'order' => $photo->order_photos,
                ];
            });


            $kitchens = [];
            foreach($restaurant->kitchens as $kitchen){
                if($kitchen->pivot->status){
                    $k = (object)[
                        'encrypt_id'    => $kitchen->encrypt_id,
                        'name'          => $kitchen->name,
                        'status'        => $kitchen->pivot->status,
                    ];
                    array_push($kitchens, $k);
                }
            }

            $restaurant->kitchens->map(function ($kitchen) {
                $kitchen->status = $kitchen->pivot->status;
            });

            if(count($photos) > 0){
                $image = $photos[0];
            } else {
                $image = null;
            }

            // $salida = (object)[
            //     'id'        => $restaurant->encrypt_id,
            // ];
            
            $zone = $restaurant->zone->name;
            $country = $restaurant->country->name;
            $sector = $restaurant->sector->name ?? '';
            // destroy zone object
            unset($restaurant->zone);
            unset($restaurant->country);
            unset($restaurant->sector);

            $restaurant->id = $restaurant->encrypt_id;
            $restaurant->zone = $zone;
            $restaurant->country = $country;
            $restaurant->sector = $sector;
            $restaurant->image = $image; 
            // $restaurant->kitchens = $kitchens;
            $restaurant->webp_image = $restaurant->webp_image;
           

            $favorites = FavoriteRestaurant::where(['restaurant_id' => $restaurant->id, 'status' => 1])->get();
            if(count($favorites) == 0){
                $restaurant->favorites = [];
            } else {
                $restaurant->favorites = $favorites;
            }
            $hasOffer = $restaurant->offers;
            $restaurantId = $restaurant->id;
            $offers = Offer::where('restaurant_id', $testid)->get();
            $restaurant->hasOffer = $hasOffer;
            $restaurant->offers = $offers;
            $restaurant->testid = $testid;
            $restaurant->offer_all = $offers_all;
             
        }

        return $this->genResponse(1, 200, $restaurants, 'Restaurants list');
    }

    /**
     * List
     * [Regresa lista de restaurantes].
     * type = (all, distance, filters)
     */
    public function index_old(Request $request, $type)
    {
        #date
        $date_format = null;
        if ($request->date) {
            $date_format = Carbon::parse($request->date)->format('Y-m-d');
        }

        #hour
        $hour_format = null;
        if ($request->hour) {
            $hour_format = Carbon::parse($request->hour)->format('H:i');
        }

        #people
        $people = null;
        if ($request->people) {
            $people = $request->people;
        }

        $user = auth()->user() ?? null;
        $types = ['all', 'distance', 'filters', 'name'];
        if (!in_array($type, $types)) {
            return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');
        }

        $validator = Validator::make($request->all(), Restaurant::getValidationRules('list_'.$type));

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $restaurants = Restaurant::where(['status' => true, 'active' => true]);

        //Filter by zone
        if($request->zone_id){
            $restaurants = $restaurants->where('zone_id', $request->zone_id);
        }


        $filters = [];
        switch ($type) { 
            case 'distance':
                $filters = [
                    'distance'  => $request->distance,
                    'latitude'  => $request->latitude,
                    'longitude' => $request->longitude,
                ];
            break;
            case 'name':
                $restaurants = Restaurant::where('name', 'like', '%' . $request->name . '%')->where(['status' => true, 'active' => true])->get();
            break;
            case 'filters':
                $restaurants = $this->restaurantFilter($request);
            break;
            default:
                # code...
            break;
        }

        $data = $this->restaurantFormat($restaurants->get(), $date_format, $hour_format, $people);

        return $this->genResponse(1, 200, $data);

        // Cantidad de personas que ha reservado el día de hoy
    }
    
    public function show($id)
    {
        $restaurant = Restaurant::where(['status' => true, 'active' => true ,])->where('slug', $id)->first();
        // $restaurant_d = Restaurant::find(decrypt($id));
        if (!$restaurant) {
            return $this->genResponse(0, 404, null, 'Restaurante no encontrado');
        }
        
        $photos = $restaurant->photos->map(function ($photo) {
            return [
                'id' => $photo->encrypt_id,
                'photo' => $this->getImageUrl($photo->url),
                'order' => $photo->order_photos,
            ];
        });


        $kitchens = [];
        foreach($restaurant->kitchens as $kitchen){
            if($kitchen->pivot->status){
                $k = (object)[
                    'encrypt_id'    => $kitchen->encrypt_id,
                    'name'          => $kitchen->name,
                    'status'        => $kitchen->pivot->status,
                ];
                array_push($kitchens, $k);
            }
        }

        #if kitchen is empty return array empty
        if(count($kitchens) == 0){
            $kitchens = array(
                (object)[
                    'encrypt_id'    => null,
                    'name'          => null,
                    'status'        => null,
                ]
            );
        }

        if(count($photos) > 0){
            $image = $photos[0];
        } else {
            $image = null;
        }

        //valet parking
        $extrasServices = 'No'; 
        $extrasSillaRueda = 'No';
        foreach ($restaurant->extraServices as $key => $service) {
            if($service->pivot->status == 1 && $service->name == 'Valet parking'){
                $extrasServices = 'Si';
            }

            if($service->pivot->status == 1 && $service->name == 'Acceso para silla de ruedas'){
                $extrasSillaRueda = 'Si';
            }
        }

        
        $service_days = $restaurant->serviceDays->map(function ($value) {
            return [
                'opening' => $value->opening,
                'closing' => $value->closing,
                'status'  => $value->status
            ];
        });
        $day = Carbon::now()->dayOfWeek;
        $day_h = null;
        foreach ($service_days as $key => $value) {
            if($value['status'] && ($key) === $day) {
                $day_h = [
                    'opening' => Carbon::create($value['opening'])->format('g:i a'),
                    'closing' => Carbon::create($value['closing'])->format('g:i a'),
                ];
            }
        }

        #favorites
        $favorites = FavoriteRestaurant::where(['restaurant_id' => $restaurant->id, 'status' => 1])->get();
        if(count($favorites) == 0){ 
            $favorites = [];
        }

        #offer
        $hasOffer = $restaurant->offers;
        $restaurantId = $restaurant->id;
        $offers = Offer::where('restaurant_id', $restaurantId)->get();

        $data = (object)[
            'id'                => $restaurant->encrypt_id,
            'id_decrypt'        => decrypt($restaurant->encrypt_id),
            'name'              => $restaurant->name,
            'slug'              => $restaurant->slug, 
            'cheff_name'        => $restaurant->cheff_name,
            'cost'              => $restaurant->cost->name,
            'payment_method'    => $restaurant->payment_method,
            'zone'              => $restaurant->zone->name,
            'country'           => $restaurant->country->name,
            'sector'            => $restaurant->sector->name ?? '',
            'address'           => $restaurant->address,
            'description'       => $restaurant->description,
            'thumbnail'         => $restaurant->thumbnail_image, 
            'image'             => $image,
            'cover'             => $restaurant->cover,
            'photos'            => $photos,
            'kitchens'          => $kitchens,
            'menu_url'          => $restaurant->menu_url,
            'valet_t'           => $extrasServices,
            'wheelchair_t'      => $extrasSillaRueda,
            'day_h'             => $day_h,
            'favorites'         => $favorites,
            'phone'             => $restaurant->phone,
            'link_url'          => $restaurant->link_url,
            'testid'            => $restaurant->id,
            'hasOffer'          => $hasOffer,
            'offer_all'         => $this->restaurantOffers($restaurant->id),
            'offers'            => $offers,
            'menu_special'      => $restaurant->menu_especial_url,
            'RankingPercentage' => $restaurant->ranking_percentage,
        ];

        return $this->genResponse(1, 200, $data);
    }

    public function search(Request $request)
    {
        $hour_actual = Carbon::now()->format('H:i:s');
        $date = $request->date ? Carbon::parse($request->date)->format('Y-m-d') : null;
        $form = [
            'chicken'   => $request->chicken,
            'price'     => $request->price,
            'zone_id' => $request->zone_id  ? decrypt($request->zone_id) : null,
            'submenu' => $request->submenu,
            'date'    => $request->date     ? Carbon::parse($request->date)->format('Y-m-d') : null,
            // 'hour'    => $request->hour     ? Carbon::parse($request->hour)->format('H:i:s') : Carbon::parse($hour_actual)->format('H:i:s'),
            'people'  => $request->people   ? $request->people : 1,
            'day_id'  =>  $date  ? (Carbon::createFromFormat('Y-m-d', $date)->dayOfWeek + 1) : null,
            'offers'  => $request->offers,
            'rating'  => $request->rating,
        ];
        
        $response = [];

        $query = Restaurant::query();

        #zone
        if (!empty($form['zone_id'])) {
            $query->where('zone_id', $form['zone_id']);
        }

        #sector
        if (!empty($form['submenu'])) {
            $query->whereIn('sector_id', $form['submenu']);
        }

        // #kitchen
        if (!empty($form['chicken'])) {
            $query->whereHas('kitchens', function($q1) use ($form) {
                $decryptedValues = array_map('decrypt', $form['chicken']);
                $q1->whereIn('kitchen_id', $decryptedValues);
                $q1->where('status', true);
            });
        }

        #cost
        if (!empty($form['price'])) {
            $query->whereIn('cost_id', $form['price']);
        } 

        $query->with('serviceDays', 'tables', 'tables.reservations')
            ->where('status', 1)
            ->where('active', 1)
            ->whereHas('serviceDays', function($q1) use ($form) {
                $q1->where('status', 1);
                $q1->where('day_id', $form['day_id']);
                // $q1->where('closing', '>=', $form['hour']);
                // $q1->where('opening', '<=', $form['hour']);
            })
            ->whereHas('tables', function($q1) use($form) {
                $q1->where('capacity', '>=', $form['people']);
            });
        $restaurants = $query->orderBy('created_at', 'DESC')->get();

        // $restaurants = Restaurant::with('serviceDays', 'tables', 'tables.reservations')
        //     ->where('status', true)
        //     ->where('active', true)
        //     ->where('zone_id', $form['zone_id'])
        //     ->whereHas('serviceDays', function($q1) use ($form) {
        //         $q1->where('day_id', $form['day_id']);
        //         $q1->where('closing', '>=', $form['hour']);
        //         $q1->where('opening', '<=', $form['hour']);
        //         $q1->where('status', 1);
        //     })
        //     ->whereHas('tables', function($q1) use($form) {
        //         $q1->where('capacity', '>=', $form['people']);
        //     })
        //     ->orderBy('created_at', 'DESC')
        //     ->get();
            
        foreach ($restaurants as $key => $restaurant) {
            $id = $restaurant->id;
            $RankingPercentage = $restaurant->ranking_percentage;
            $restaurant->RankingPercentage  = $RankingPercentage;
            #offers filter
            if ($form['offers']) {
                $offer_arr = collect($this->restaurantOffers($id, $date))->filter(function ($offer) {
                    return $offer['show'] ?? $offer;
                });

                if(!count($offer_arr)){
                    continue;
                }
            }

            #rating filter
            if ($form['rating']) {
                if($RankingPercentage < 4){
                    continue;
                }
            }

            $offers_all = $offer_arr ?? [];
            $available = false;
            foreach ($restaurant->tables as $table) {
                if (!$table->reservations->count()) {
                    $available = true;
                } else {
                    $sum_people = Reservation::whereDate('reservation_date', '=', $form['date'])
                    ->where('table_id', $table->id)
                    ->where(function($query){
                        $query->OrWhere('reservations_status_id', 1);
                        $query->OrWhere('reservations_status_id', 6);
                        $query->OrWhere('reservations_status_id', 9);
                    })
                    ->sum('people'); 
                    $available_count = $table->capacity - $sum_people; 
                    if ($available_count >= $form['people']) {
                        $available = true;
                    }
                }
            }

            if ($available) {
                $temp    = $restaurant;
                
                $zone    = $restaurant->zone->name;
                $country = $restaurant->country->name;
                $sector  = $restaurant->sector->name ?? '';

                $photos = $restaurant->photos->map(function ($photo) {
                    return [
                        'id'    => $photo->encrypt_id,
                        'photo' => $this->getImageUrl($photo->url),
                        'order' => $photo->order_photos,
                    ];
                });

                // $kitchens = [];
                // foreach($restaurant->kitchens as $kitchen) {
                //     if ($kitchen->pivot->status) {
                //         $k = (object) [
                //             'encrypt_id' => $kitchen->encrypt_id,
                //             'name'       => $kitchen->name,
                //             'status'     => $kitchen->pivot->status,
                //         ];
                //         array_push($kitchens, $k);
                //     }
                // }
                $restaurant->kitchens->map(function ($kitchen) {
                    $kitchen->status = $kitchen->pivot->status;
                });
                
                #
                unset($temp->serviceDays);
                unset($temp->tables);
                unset($temp->zone);
                unset($temp->country);
                unset($temp->sector);
                unset($temp->offers_all);

                #
                $temp->id       = $restaurant->encrypt_id;
                $temp->zone     = $zone;
                $temp->country  = $country;
                $temp->sector   = $sector;
                $temp->image   = ($temp->photos->count() ? $photos[0] : null);

                // $temp->kitchens = $kitchens;
                $temp->photos   = $photos;
                $temp->webp_image = $restaurant->webp_image;

                $favorites = FavoriteRestaurant::where(['restaurant_id' => $restaurant->id, 'status' => 1])->get();
                if(count($favorites) == 0){ 
                    $temp->favorites = [];
                } else {
                    $temp->favorites = $favorites;
                }

                $hasOffer = $restaurant->offers;
                $offers = Offer::where('restaurant_id', $id)->get();
                $temp->hasOffer = $hasOffer;
                $temp->offers = $offers;
                $temp->testid = $id; 
                $temp->offer_all = $offers_all;
                //verificar que la fecha consultada tiene ofertas 
                
                
                $response['data'][] = $temp;

            }
        }

        #return rating
        $response['rating'] = $form['rating'];
        
        return $this->genResponse(1, 200, $response, 'Restaurants list');
    }

    public function searchText(Request $request)
    { 
        $query = Restaurant::query();
        
        $query->where('status', true)
            ->where('active', true)
            ->where('name', 'LIKE', '%' . $request->text . '%');
            
        $restaurants = $query->orderBy('created_at', 'DESC')->get();

        return $this->genResponse(1, 200, $restaurants, 'Restaurants list');
    }


    public function restaurantsByAvailability(Request $request)
    {
        #Parametros de entrada
        #Active jquery 
        #zone_id
        #time
        #people

        #date
        $date_format = null;
        if ($request->date) {
            $date_format = Carbon::parse($request->date)->format('Y-m-d');
        }

        #hour
        $hour_format = null;
        if ($request->hour) {
            $hour_format = Carbon::parse($request->hour)->format('H:i');
        }

        #people
        $people = null;
        if ($request->people) {
            $people = $request->people;
        }

        $restaurants = Restaurant::where([
            ['zone_id', $request->zone_id],
            ['status', 'active'],
        ])->get();

        $response = [];

        foreach ($restaurants as $restaurant) {
            $restaunt_availability = $this->reservationService->restauranCapacityBySchedule($restaurant->id, $date_format, $hour_format, $people);
            foreach($restaunt_availability->schedule as $schedule) {

                if($schedule->avalable ) {
                    $response[] = $restaurant;
                }
                $response[] = [
                    'restaurant' => $restaurant,
                    'schedule' => $schedule,
                ];
            }
            $response[] = [
                'title' => $restaurant,
                'availability' => $restaunt_availability,
            ];
        }

        return response()->json($response);
        #Filtro por zona decrypt($request->zone_id)
        if ($request->zone_id) {
            $query->with(function($request) {
                $query->where('zone_id', $request->zone_id);
            });
        }

        // #Filtro por fecha
        // if ($request->date) {
        //     $query->where('date', $request->date);
        // }

        return $this->genResponse(1, 200, $query->get());


        $data = $request;


        // Log::info('reques' . json_encode($request->all()));

        // $restaurantId = auth()->user()->restaurant_id;

        // $stringDateTime = explode(' ', $data['date']);

        // $people = $data['number_people'];

        $date = "2022-06-07";

        // $hour = $stringDateTime[1];

        $salida = $this->reservationService->restauranCapacityBySchedule(1, $date, '19:00', 3);

        return $this->genResponse(1, 200, $salida);

    }

    /**
     * restaurant format.
     *
     * [Funcion para darle estructura a la información del restaurante]
     *
     */
    private function restaurantFormat($restaurants, $date_format=null, $hour_format=null ,$people=null)
    {
        $data = [];

        foreach ($restaurants as $restaurant) {

            // verificar si hay disponibilidad
            if($date_format || $hour_format || $people) {
                $restaunt_availability = $this->reservationService->restauranCapacityBySchedule($restaurant->id, $date_format, $hour_format, $people);
            }

            $photos = $restaurant->photos->map(function ($photo) {
                return [
                    'id' => $photo->encrypt_id,
                    'photo' => $this->getImageUrl($photo->url),
                    'order' => $photo->order_photos,
                ];
            });


            $kitchens = [];
            foreach($restaurant->kitchens as $kitchen){
                if($kitchen->pivot->status){
                    $k = (object)[
                        'encrypt_id'    => $kitchen->encrypt_id,
                        'name'          => $kitchen->name,
                        'status'        => $kitchen->pivot->status,
                    ];
                    array_push($kitchens, $k);
                }
            }

            if(count($photos) > 0){
                $image = $photos[0];
            } else {
                $image = null;
            }

            #favorites
            $favorites = FavoriteRestaurant::where(['restaurant_id' => $restaurant->id, 'status' => 1])->get();
            if(count($favorites) == 0){ 
                $favorites = [];
            }
            $hasOffer = $restaurant->offers;
            $restaurantId = $restaurant->id;
            $offers = Offer::where('restaurant_id', $restaurantId)->get();

            $salida = (object)[
                'id_decrypt'    => $restaurant->id,
                'id'        => $restaurant->encrypt_id,
                'name'      => $restaurant->name,
                'slug'      => $restaurant->slug,
                'serviceDays' => $restaurant->serviceDays,
                'cost'      => $restaurant->cost->name,
                'zone'      => $restaurant->zone->name,
                'country'   => $restaurant->country->name,
                'sector'    => $restaurant->sector->name ?? '',
                'thumbnail_image'   => $restaurant->thumbnail_image,
                'image'         => $image,
                'webp_image'   => $restaurant->webp_image,
                'photos'    => $photos,
                'kitchens'  => $kitchens, 
                'favorites' => $favorites,
                'hasOffer' => $hasOffer,
                'offer_all'     => $restaurant->offers_all,
                'offers' => $offers,
                'RankingPercentage' => $restaurant->RankingPercentage,
            ];

            array_push($data, $salida);
        }
        return $data;
    }

    /**
     * restaurant favoritos.
     *
     * [Funcion para obtener los restaurantes favoritos]
     *
     */
    public function restaurantFavorites() 
    {
        // PUT THESE RESTAURANTS IN THIS ORDER
        // 1. turo ID 77
        // 2. samurai ID 21
        // 3. Perbacco ID 137
        // 4. La Casta ID 344
        // 4. Allegua ID 221
        // 5. Meson de la Cava ID 206
        // 6. Piano ID 8
        // 7. Morisoñando ID 162
        // 8. Pate palo ID 115
        // 9. Loretta ID 157
        // 10. Rincon de vicente ID 135
        // 11. Zuquero 110
        $restaurants = Restaurant::where(['status' => true, 'active' => true])
        ->latest()->get();

        $restaurants = $restaurants->sortBy(function($restaurant, $key) {
            if ($restaurant->id == 77) {
                //77
                return 1;  
            } else if ($restaurant->id == 21) {
                return 2; 
            } else if ($restaurant->id == 137) {
                return 3;
            } else if ($restaurant->id == 344) {
                return 4;
            } else if ($restaurant->id == 206) { 
                return 5;
            } else if ($restaurant->id == 8) {
                return 6;
            } else if ($restaurant->id == 162) {
                return 7;
            } else if ($restaurant->id == 115) {
                return 8;
            } else if ($restaurant->id == 221) {
                return 9;
            } else if ($restaurant->id == 135) {
                return 10;
            } else if ($restaurant->id == 110) {
                return 11;
            } else {
                return 12;
            }
        });

        //limit 30
        $restaurants = $restaurants->take(30);

        $data = $this->restaurantFormat($restaurants);

        return $this->genResponse(1, 200, $data);
    }

    /**
     * restaurant favoritos client.
     *
     * [Funcion para obtener los restaurantes favoritos del client]
     *
     */
    public function restaurantFavoritesClient($client_id) 
    {
        $restaurants = Restaurant::where(['status' => true, 'active' => true])->latest()->get();
        #restaurants only if client is favorite
        $restaurants = $restaurants->filter(function ($restaurant) use ($client_id) {
            $favorite = FavoriteRestaurant::where(['restaurant_id' => $restaurant->id, 'client_id' => $client_id, 'status' => 1])->get();
            if(count($favorite) > 0){
                return $restaurant;
            }
        }); 

        $data = $this->restaurantFormat($restaurants);

        return $this->genResponse(1, 200, $data);
    }

    
    /**
     * restaurant by id add favorites.
     *
     * [Funcion para obtener cambiar status restaurantes favoritos]
     *
     */
    public function changeFavoriteRestaurant(Request $request){
        #favorite
        $favorite = FavoriteRestaurant::where(['restaurant_id' => $request->restaurant_id, 'client_id' => $request->client_id])->get();
        if(count($favorite) == 0){
            $favorite = new FavoriteRestaurant();
            $favorite->restaurant_id = $request->restaurant_id;
            $favorite->client_id = $request->client_id;
            $favorite->status = 1;
            $favorite->save();
            $favorite->refresh();

            $favorite->encrypt_id = encrypt($favorite->id);
            $favorite->save();
        } else {
            $favorite = FavoriteRestaurant::find($favorite[0]->id);
            $favorite->status = !$favorite->status;
            $favorite->save();
        }

        return $this->genResponse(1, 200, $favorite);
    }

    /**
     * restaurant by id add offers.
     *
     * [Funcion para obtener las ofertas del restaurante]
     *
     */
    public function restaurantOffers($id, $datetime = '')
    {
        if($datetime == '') {
            $datetime = Date('Y-m-d');
        }

        //get all offers from restaurant
        $offers = Offer::where('restaurant_id', $id)
        ->where('status', 1)
        ->limit(4)
        ->get();
        $offer_data = [];

        if($offers->count() > 0 ){

            foreach($offers as $offer){

                #Variables
                $status = false;
                $show = false;
                #TESTING
                $p = [];

                if($offer->status == 1){
                    $seleted_days = $offer->dates;

                    if(!empty($seleted_days)) {
 
                        $seleted_days = json_decode($seleted_days);
 
                        #verificar si las fechas seleccionadas son mayores a la fecha actual
                        foreach($seleted_days as $day){

                            #convertir la fecha a formato Y-m-d (2023-12-24)
                            $date = $day;
                            $current_date = date('Y-m-d');
                            if($date >= $current_date){
                                $status = true;
                            }

                            if($date == $datetime){
                                $show = true;
                            }
                        }
                    } //end if seleted_days

                    if($offer->repeats == 1){
                        $date_start = date('Y-m-d', strtotime($offer->start_date));
                        $date_end = date('Y-m-d', strtotime($offer->end_date));

                        #arr fecha inicio hasta fecha fin
                        $monday = $offer->monday;
                        $tuesday = $offer->tuesday;
                        $wednesday = $offer->wednesday;
                        $thursday = $offer->thursday;
                        $friday = $offer->friday;
                        $saturday = $offer->saturday;
                        $sunday = $offer->sunday;

                        // Convertir las fechas a objetos DateTime para poder compararlas
                        $start = new \DateTime($date_start);
                        $end = new \DateTime($date_end);

                        if(Date('Y-m-d') <= $date_end){
                            $status = true;
                        }

                        if ($status) {
                            // Agregar un día al final para incluir la fecha final en el rango
                            $end = $end->modify('+1 day');

                            // Crear un intervalo de un día
                            $interval = new \DateInterval('P1D');

                            // Crear un período de fechas desde la fecha de inicio hasta la fecha final
                            $period = new \DatePeriod($start, $interval, $end);

                            $current_day_now = new \DateTime($datetime);
                            $current_n = $current_day_now->format('N'); 
                            $current_day_now = $current_day_now->format('Y-m-d');
                            #TESTING
                            $p[] = [
                                'monday' => $monday,
                                'tuesday' => $tuesday,
                                'wednesday' => $wednesday,
                                'thursday' => $thursday,
                                'friday' => $friday,
                                'saturday' => $saturday,
                                'sunday' => $sunday,
                                'show' => $show,
                                'current_day_now' => $current_day_now,
                            ];
                            

                            foreach ($period as $date) {
                                #verificar si el dia actual esta dentro de los dias seleccionados
                                $current_day = $date->format('Y-m-d');

                                if(($current_day == $current_day_now) && ($monday == 1 && $current_n == 1)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($tuesday == 1 && $current_n == 2)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($wednesday == 1 && $current_n == 3)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($thursday == 1 && $current_n == 4)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($friday == 1 && $current_n == 5)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($saturday == 1 && $current_n == 6)){
                                    $show = true;
                                }

                                if(($current_day == $current_day_now) && ($sunday == 1 && $current_n == 7)){
                                    $show = true;
                                }

                            }
                        }

                    }

                } //end if status

                #saved status
                $offer->status = $status;
                $offer->save();
                $offer->refresh();

                $offer_data [] = [
                    'id' => $offer->id,
                    'title' => $offer->title,
                    'description' => $offer->description,
                    'status' => $offer->status,
                    'show' => $show, 
                    // 'status_new' => $status,
                    // 'repeats' => $offer->repeats,
                    #TESTING
                    'p' => $p,
                ];

            } //end foreach

        } //end if offers

        return $offer_data;

    } //end function
  

}