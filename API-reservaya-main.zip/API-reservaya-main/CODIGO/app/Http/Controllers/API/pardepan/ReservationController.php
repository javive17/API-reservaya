<?php

namespace App\Http\Controllers\API\pardepan;

use App\Models\{Restaurant, Client, Reservation, PardepanBlocked, Review};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Image;


use App\Repositories\{ReservationRepositoryInterface, RatingRepositoryInterface};
use App\Services\Restaurant\ReservationServiceInterface;
use App\Traits\{GeneralResponse, AuxiliarFunctions};
use App\Http\Requests\ReservationAvailabilityRequest;
use App\Http\Requests\StoreRestaurantReservation;
use App\Models\Catalogs\TableType;
use App\Jobs\SendNotifications;
use Illuminate\Support\Facades\Mail;
use App\Mail\GroupFilesForm;

class ReservationController extends Controller
{
    use GeneralResponse, AuxiliarFunctions;

    /** @var RatingRepositoryInterface */
    private $ratingRepository;

   /** @var ReservationServiceInterface */
   private $reservationService;

   /** @var ReservationRepositoryInterface */
   private $reservationRepository;


   public function __construct(
       ReservationServiceInterface $reservationService,
       RatingRepositoryInterface $ratingRepository,
       ReservationRepositoryInterface $reservationRepository
   ) {

       $this->reservationService = $reservationService;
       $this->ratingRepository = $ratingRepository;
       $this->reservationRepository = $reservationRepository; 
   }

   public function reservationAvailability(Request $request)
   {
       $validator = Validator::make($request->all(), ['restaurant_id' => 'required']);

       if ($validator->fails()) {
           return $this->genResponse(1, 401, $validator->errors());
       }
       
       #hour 
       $hour_format = null;
       if ($request->hour) {
           $hour_format = Carbon::parse($request->hour)->format('H:i');
       }

       #people
       $people = null; 
       if ($request->people) {
           $people = $request->people;
       }

       $restaurantId = decrypt($request->restaurant_id);

       #Verificar si el restaurante esta bloqueado para esa fecha
     /*  $pardepanblocked = PardepanBlocked::whereRaw('DATE(reservation_date) = ?', [$request->date])->where('restaurant_id', $restaurantId)->get();
         if (count($pardepanblocked) > 0) {
            return $this->genResponse(0, 200, null,'El restaurante esta bloqueado para esa fecha');
         }
      */
    //    dd($pardepanblocked);
       // Log::info('reques' . json_encode($request->all()));
       

       $salida = $this->reservationService->restauranCapacityBySchedule($restaurantId, $request->date , '', $people);

       return $this->genResponse(1, 200, $salida);

   }

   public function createReservation(StoreRestaurantReservation $request)

   {
       
       $data = $request->validated();
        
       $restaurantId = decrypt($request->restaurant_id);

       if (!isset($data['client_id']) && !isset($data['client'])) {

           return $this->genResponse(1, 400, ['errors' => ['client' => 'El cliente o la informacion de un cliente son requeridos']]);

       }
       $categories = $this->getDecryptedArray($data['categories']);

       if (is_null($categories)) {

           return $this->genResponse(1, 400, ['errors' => ['categories' => 'deben ser ids validos']]);

       }

       $clientId = $data['client_id'];

       $tableId = $data['table_type_id']; 

       $validator_table = TableType::find($tableId);

       if(!$validator_table){
           return $this->genResponse(0, 400, null,'No existe la table_type enviada');
       }

       $comments = isset($data['comments']) ? $data['comments'] : '';

       $tableNumber = isset($data['table_number']) ? $data['table_number'] : '';

       $result = $this->reservationService->create($restaurantId, $clientId, $tableId, $data['number_people'], $data['date'], $comments, $tableNumber, 'pardepan');
       //TEMPORARY SOLUTION TO SEND NOTIFICATION TO RESTAURANT
       //call     SendPushNotificationToRestaurant($restaurantID); from reservationRepository
         $this->reservationRepository->SendPushNotificationToRestaurant($restaurantId, $result['data']['id']);
     
       /*
           $obj_send_notification = (object) [
            'to' => $restaurantId,
            'reservation_id' => $result['data']['id'],
            'title' => '¡Nueva reserva!',
            'body' => '¡BUENAS NOTICIAS! tiene una nueva reserva.!',
        ];
       */
  

        //Insertar value array $result['data'] 
        $restaurant = Restaurant::find($restaurantId);
        $result['data']['accept_automatic_reservation'] = $restaurant->accept_automatic_reservation;

       return $this->genResponse((int)($result['status']==200), $result['status'],  $result['data'], $result['message']);

   }

       /**
    * Client Reservation List
    *
    * [lista de reservaciones de los clientes]
    */
   public function clientsReservationList(Request $request, $client_eid, $type)
   {
       $types = ['all', 'search'];

       if (!in_array($type, $types)) {
           return $this->genResponse(0, 400, null, 'Datos inválidos para realizar búsqueda');
       }

       if($type == 'search') {
           $validator = Validator::make($request->all(), Client::getValidationRules('search'));

           if ($validator->fails()) {
               return $this->genResponse(1, 400, $validator->errors());
           }
       }

       $client_id = $this->getDecrypted($client_eid);
       if(!$client=Client::find($client_id)){
           return $this->genResponse(0, 404, null,'No existe el cliente solicitado');
       }

       $reservations = Reservation::join('t_tables', 't_reservations.table_id', '=', 't_tables.id')
                               ->join('c_tables_type', 't_tables.table_type_id', '=', 'c_tables_type.id')
                               ->join('c_reservations_status', 't_reservations.reservations_status_id', '=', 'c_reservations_status.id')
                               ->join('t_restaurants', 't_tables.restaurant_id', '=', 't_restaurants.id')
                               ->leftJoin('t_restaurants_photos', function($join){
                                    // limit first order_id by created_at
                                    $join->on('t_restaurants_photos.restaurant_id', '=', 't_restaurants.id')
                                        ->whereRaw('t_restaurants_photos.id = (select id from t_restaurants_photos where restaurant_id = t_restaurants.id order by created_at asc limit 1)');
                               })
                               ->join('c_countries', 't_restaurants.country_id', '=', 'c_countries.id') 
                               ->join('c_zones', 't_restaurants.zone_id', '=', 'c_zones.id')
                               ->select('t_restaurants.name as restaurant_name', 't_restaurants.group_type as group_type','c_countries.name as country','c_zones.name as zone', 't_reservations.people as people', 't_reservations.form_send as form_send',
                               't_reservations.reservation_date as reservation_date', 'c_tables_type.name as title_type', 't_restaurants.encrypt_id as restaurant_id', 't_restaurants_photos.url as photo','t_restaurants.thumbnail as thumbnail', 't_reservations.encrypt_id as reservation_id', 't_reservations.comments as comments', 'c_reservations_status.name as status', 'c_reservations_status.id as status_id')

                               ->where('t_reservations.client_id',$client_id)

                               ->orderBy('t_reservations.created_at', 'desc')->paginate(10000);

       foreach ($reservations as $key => $reservation) {
           if($reservation->photo)
               $reservation->photo = $this->getImageUrl($reservation->photo); 
               $reservation->image = $reservation->photo;

            $full_date = explode(' ', $reservation->reservation_date);
            $reservation->RequestDate = $full_date[0];
            $reservation->hour = $full_date[1];

            $date = date('Y-m-d H:i');
            if($reservation->reservation_date > $date && $reservation->status_id != 5 && $reservation->status_id != 7) {
                $reservation->cancelForDate = false;
            }else{
                if(!($reservation->reservation_date > $date) && $reservation->status_id != 7) {
                    $reservation->status = 'RECHAZADO';
                    $reservation->status_id = 8;
                }
                $reservation->cancelForDate = true;
            }

            $restaurant = Restaurant::find(decrypt($reservation->restaurant_id));
            $reservation->slug = $restaurant->slug;
            $service_days = $restaurant->serviceDays->map(function ($value) {
                return [
                    'opening' => $value->opening,
                    'closing' => $value->closing,
                    'status'  => $value->status
                ];
            });
    
            $day = Carbon::now()->dayOfWeek;
            $day_h = null;
            foreach ($service_days as $key => $value) {
                if($value['status'] && ($key+1) === $day) {
                    $day_h = [
                        'opening' => Carbon::create($value['opening'])->format('g:i a'),
                        'closing' => Carbon::create($value['closing'])->format('g:i a'),
                    ];
                }
            }

            $reservation->day_h = $day_h;
       }

       return $this->genResponse(1, 200, $reservations, "Información consultada correcatmente");
   }
   
   public function cancelReservation($reservation_eid) {
         $reservation = Reservation::find(decrypt($reservation_eid));
         if(!$reservation){
              return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
         }
         $reservation->reservations_status_id = 7;
         $reservation->save();
         return $this->genResponse(1, 200, null, "Reservación cancelada correctamente");
   }

    public function getReservation($reservation_eid) {

            #validate reservation_eid valid
            try {
                $reservation = Reservation::find(decrypt($reservation_eid));
                if(!$reservation){
                    return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
                }

                $reservation->numId = decrypt($reservation_eid);
                $reservation->status;
                $reservation->review = $reservation->review;
                $reservation->restaurant_name = $reservation->table->restaurant->name;
                $reservation->title_type = $reservation->table->type->name;
                $token = $reservation->client->user->createToken('Puerta21API')->accessToken;
                $reservation->token = $token;
                
                return $this->genResponse(1, 200, $reservation, "Información consultada correcatmente");
            } catch (DecryptException $e) {
                // La desencriptación falló. Maneja el error aquí...
                return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
            }

    }

    //get reservation for form
    public function getReservationForm($id) {
        $reservation = Reservation::find($id);
        if(!$reservation){
              return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
        }

        $photos = $reservation->table->restaurant->photos->map(function ($photo) {
            return [
                'id' => $photo->encrypt_id,
                'photo' => $this->getImageUrl($photo->url),
                'order' => $photo->order_photos,
            ];
        });

        if(count($photos) > 0){
            $image = $photos[0];
        } else {
            $image = null;
        }

        $data = [
            'phone' => $reservation->client->cell_phone,
            'image' => $image,
            'restaurant_name' => $reservation->table->restaurant->name,
            'number_people' => $reservation->people,
            'date'  => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
            'hour'  => Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A')
        ];

        return $this->genResponse(1, 200, $data, "Información consultada correcatmente");
    }

    //send reservation for form
    public function sendReservationFormUpdate(Request $request) {
        $reservation = Reservation::find($request->eid);
        if(!$reservation){
              return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
        }

        $reservation->form_send = 1;
        $reservation->save();

        return $this->genResponse(1, 200, null, "Información consultada correcatmente");
    }

    // Function for formSend
    public function formSend(Request $request) 
    {
        //validate
        $request->validate([
            //type image pdf max 2mb
            'eid' => 'required|exists:t_reservations,encrypt_id',
            'people_files.*' => 'required|mimes:jpeg,bmp,png,gif,svg,pdf|max:3072',
        ],
        [
            'people_files.*.required' => 'El campo es requerido',
            'people_files.*.mimes' => 'El archivo debe ser un tipo de archivo: jpeg, bmp, png, gif, svg, pdf.',
            'people_files.*.max' => 'El archivo no debe ser mayor a 3 MB. tirar una foto o subir un captura de pantalla',
            'eid.required' => 'El campo es requerido',
            'eid.exists' => 'El campo no existe',
        ],
        [
            'people_files.*'    => 'documento',
            'eid'               => 'ID reservación',
        ]);

        $reservation_id = decrypt($request->eid);
        if(!$reservation = Reservation::find($reservation_id)){
            return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
        }

        #saved storage file
        $files = $request->file('people_files');
        $files_name = [];
        $attachments = [];
        $name_folder = 'reservation_form-'. $reservation->id;
        $path = public_path('storage/reservation_form/'. $name_folder);
        if(!\File::exists($path)) {
            \File::makeDirectory($path, 0777, true, true);
        }

        foreach ($files as $key => $file) {
            #verify type file
            $type_file = $file->getClientOriginalExtension();
            if($type_file == 'pdf') { 
                $name_file = 'file-'. $key . '.' . $type_file;
                $file->move($path, $name_file);
                $files_name[] = $name_file;
                $attachments[] = $path . '/' . $name_file;
            } else {
                // Laravel Convert Images to jpg Format
                $image = Image::make($file);
                $image->encode('jpg', 50);
                $image->save($path .'/'. $file->getClientOriginalName());

                $files_name[] = $file->getClientOriginalName();

                $attachments[] = $path . '/' . $file->getClientOriginalName();
            }
        }

        #data user
        $data_user = (Object) [
            'name' => ucwords($reservation->client->first_name),
            'lastName' => ucwords($reservation->client->middle_name.' '.$reservation->client->last_name),
            'email' => $reservation->client->user->email,
            'phone' => $reservation->client->cell_phone,
        ];

        #imagen restaurant
        $photos = $reservation->table->restaurant->photos->map(function ($photo) {
            return [
                'id' => $photo->encrypt_id,
                'photo' => $this->getImageUrl($photo->url),
                'order' => $photo->order_photos,
            ];
        });

        if(count($photos) > 0){
            $image = $photos[0];
        } else {
            $image = null;
        }

        $image = asset('/public/images/rounded/'. $this->formattedImage($image['photo'] ,$reservation->table->restaurant->name));

        #data reservation
        $data_reservation = (Object) [
            'restaurant' => $reservation->table->restaurant->name,
            'image' =>  $image,
            'date' =>   Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('d F Y'),
            'hour' =>   Carbon::parse($reservation->reservation_date)->locale('es')->translatedFormat('g:i A'),
            'people' => $reservation->people,
        ];

        Mail::to(env('MAIL_CAPCANA'))
        ->cc(env('MAIL_CAPCANA_CC'))
        ->send(new GroupFilesForm($data_reservation, $data_user, $attachments));

        #petition https
        $reservation->form_send = 1;
        $reservation->save();

        #return
        return $this->genResponse(1, 200, null, "Información enviada correcatmente");
    }

    // Function for formSend formattedImage
    public function formattedImage($url, $restaurant_name) {

        $convert_restaurant_name = str_replace(' ', '-', $restaurant_name);
        $name_image = $convert_restaurant_name;

        if(!$url) {
            $url = public_path('/images/one-picture.png');
            $name_image = 'one-picture';
        }

        #verify if exist folder
        if (file_exists(public_path('images/rounded/' . $name_image. '.png'))) {
            return $name_image . '.png';
        }

        // allow_url_fopen
        $image = Image::make($url);
        //$image->encode('png');

        /* if you want to have a perfect and complete circle using the whole width and height the image
         must be shaped as as square. If your images are not guaranteed to be a square maybe you could
         use Intervention's fit() function */
        //  $image->fit(160,160);
        $image->resize(160,160);

        // create empty canvas
        $width = $image->getWidth();
        $height = $image->getHeight();
        $mask = Image::canvas($width, $height);

        // draw a white circle
        $mask->circle($width, $width/2, $height/2, function ($draw) {
            $draw->background('#fff');
        });

        $image->mask($mask, false);
        $image->save(public_path('images/rounded/'.$name_image.'.png'));

        return $name_image . '.png';
    }

    // Function for pollStore
    public function pollStore(Request $request) {

        $validator = Validator::make($request->all(), [
            'reservation_id' => 'required|exists:t_reservations,encrypt_id',
            'rating' => 'required|numeric|min:1|max:5',
            'comment' => 'nullable|string|max:255',
        ],
        [
            'reservation_id.required' => 'El campo es requerido',
            'reservation_id.exists' => 'El campo no existe',
            'reservation_id.unique' => 'El campo ya ha sido registrado',
            'rating.required' => 'El campo es requerido',
            'rating.numeric' => 'El campo debe ser un número',
            'rating.min' => 'El campo debe ser mayor a 0',
            'rating.max' => 'El campo debe ser menor a 6',
            'comment.string' => 'El campo debe ser una cadena de texto',
            'comment.max' => 'El campo debe ser menor a 256 caracteres',
        ], 
        [
            'reservation_id' => 'ID reservación',
            'rating' => 'Calificación',
            'comment' => 'Comentario',
        ]);

        if ($validator->fails()) {
            return $this->genResponse(1, 400, $validator->errors());
        }

        $reservation_id = decrypt($request->reservation_id);
        $reservation = Reservation::find($reservation_id);
        if(!$reservation){
            return $this->genResponse(0, 404, null,'No existe la reservación solicitada');
        }

        #verify if exist review
        $review = Review::where('reservation_id', $reservation_id)->first();
        if($review){
            return $this->genResponse(0, 400, null,'Ya existe una calificación para esta reservación');
        }

        try {
            $rating = Review::create([
                'user_id' => $reservation->client->user->id,
                'reservation_id' => $reservation->id,
                'restaurant_id' => $reservation->table->restaurant_id,
                'comment' => $request->comment,
                'is_seen' => 1,
                'rating' => $request->rating,
            ]);
        } catch (\Exception $e) {
            // Aquí puedes manejar el error, por ejemplo, puedes registrar el error y devolver una respuesta de error.
            $error = $e->getMessage();
            \Log::error('Error al crear la calificación: ' . $error);
            return $this->genResponse(0, 500, $error, 'Error al crear la calificación');
        }

        #verificar cual ha sido el error en la creación


        return $this->genResponse(1, 200, $rating, "Información enviada correcatmente");
    }


}
