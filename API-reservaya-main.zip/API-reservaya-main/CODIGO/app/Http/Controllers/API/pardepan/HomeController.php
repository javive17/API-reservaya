<?php

namespace App\Http\Controllers\API\pardepan;

use App\Models\{Restaurant, Notification, Device};
use Illuminate\Http\Request;
use App\Models\Catalogs\Zone;
use App\Jobs\SendNotifications;

use App\Traits\GeneralResponse;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{

    use GeneralResponse;

    public function getZones()
    {
        //order by name alphabetically, get mutator sector
        $zones = Zone::orderBy('name', 'desc')->get();
        #get sectores
        // $zones->sector
        if(!$zones)
        {
            return $this->sendError('No se encontraron zonas.');
        }
        return $this->genResponse(1, 200, $zones, 'Lista de zonas.');
    }

    public function getHours($id)
    {
        $restaurant = Restaurant::where(['status' => true, 'active' => true ,])->where('encrypt_id', $id)->first();

        if(!$restaurant)
        {
            return $this->sendError('No se encontró el restaurante.');
        }
        
        $service_days = $restaurant->serviceDays->map(function ($value) {
            return [
                'opening' => $value->opening,
                'closing' => $value->closing,
                'status'  => $value->status
            ];
        });

        if(!$service_days)
        {
            return $this->sendError('No se encontraron horarios.');
        }

        return $this->genResponse(1, 200, $service_days, 'Lista de horarios.');
    }

    public function notification(){

        $obj_send_notification = (object) [
            'to' => 1,
            'reservation_id' => 1,
            'title' => 'Nueva reservation',
            'body' => 'Descripcion de la reservation',
        ];

        //SEND EMAIL Y NOTIFICATION PUS JOBS LARAVEL, for default is user!! for type
        SendNotifications::dispatch($obj_send_notification)->delay(now()->addSeconds(10));
    }
}
