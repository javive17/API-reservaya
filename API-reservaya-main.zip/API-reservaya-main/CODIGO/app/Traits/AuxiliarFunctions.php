<?php



namespace App\Traits;



use Illuminate\Contracts\Encryption\DecryptException;

use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\Storage;

use Illuminate\Http\File;

use Illuminate\Support\Str;



trait AuxiliarFunctions

{

    public $back_office = [3, 4];

    public $dollar = 2;

    private $disk = 'local'; // config('app.debug') ? 'local' : 's3'; TODO

    

    public function getDecrypted($encrypted):int

    {

        try {

            $data = decrypt($encrypted);

        } catch (DecryptException $e) {

            $data = -1;

            Log::error($e->getMessage());

        }



        return $data;

    }



    public function getDecryptedArray($encrypted){

        if(!is_array($encrypted)){

            return null;

        }

        $data = [];

        try {

            foreach($encrypted as $value){

                $data[] = decrypt($value);

            }

        } catch (DecryptException $e) {

            $data = null;

            Log::error($e->getMessage());

        } catch(\Exception $e){

            $data = null;

            Log::error($e->getMessage());

        }



        return $data;



    }



    public function getEnvironmentUrl()

    {

        // $environment    = null;

        // $env            = config('app.env');



        // switch($env){

        //     case 'dev':

        //         return config('accretio.front_dev');

        //     break;

        //     case 'qa':

        //         return config('accretio.front_qa');

        //     break;

        //     case 'prod':

        //         return config('accretio.front_prod');

        //     break;

        //     default:

        //         return config('accretio.front_dev');

        //     break;

        // }

        if (isset($_SERVER['HTTPS']) && 'on' == $_SERVER['HTTPS']) {

            $strOut = sprintf('https://%s', $_SERVER['SERVER_NAME']);

        } else {

            $strOut = sprintf('http://%s', $_SERVER['SERVER_NAME']);

        }



        return $strOut;

    }



    public function getRestaurantEnvironmentUrl()

    {

        $env  = config('app.env');



        switch($env){

            case 'dev':

                return config('puerta21.restaurant_dev');

            break;

            case 'qa':

                return config('puerta21.restaurant_qa');

            break;

            case 'prod':

                return config('puerta21.resturant_prod');

            break;

            default:

                return config('puerta21.restaurant_dev');

            break;

        }

    }



    public function getLandingPageEnvironmentUrl()

    {

        $env  = config('app.env');



        switch($env){

            case 'dev':

                return config('puerta21.landing_page_dev');

            break;

            case 'qa':

                return config('puerta21.landing_page_qa');

            break;

            case 'prod':

                return config('puerta21.landing_page_prod');

            break;

            default:

                return config('puerta21.landing_page_dev');

            break;

        }

    }



    public function generateToken()

    {

        return substr(str_shuffle(str_repeat($x = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(100 / strlen($x)))), 1, 100);

    }



    public function storeImage($imageFile, $fileUrl, $path)

    {

        if($fileUrl) {



            $validate_file = Storage::disk($this->disk)->exists($fileUrl);

        

            if($validate_file) {

                Storage::disk($this->disk)->delete($fileUrl);

            } 

        }



        $path = Storage::disk($this->disk)->put($path, new File($imageFile));



        return $path;

    }



    public function getImage($path)

    {

        if($path) {



            $validate_image = Storage::disk($this->disk)->exists($path);

        

            if($validate_image) {

                $image = Storage::disk($this->disk)->get($path);



                $image = $image ? base64_encode($image) : $image;



                return $image;

            } 

        }



        return $path;

    }



    public function getImageUrl($path)

    {


        return 'https://api.puerta21.club/storage/app/'. $path;

    }



    public function deleteImage($path)

    {

        $validate_file = Storage::disk($this->disk)->exists($path);

        

        if($validate_file) {

            Storage::disk($this->disk)->delete($path);

        } 



        return $path;

    }



    public function getUrlFormatName($name)

    {

        $name_words = explode(' ', $name);

        $url_name = strtolower($this->eliminar_acentos($name_words[0]));

        if (count($name_words) > 1) {

            for ($i = 1; $i < count($name_words); ++$i) {

                $url_name .= '-'.strtolower($name_words[$i]);

            }

        }
        return $this->eliminar_acentos($url_name);

    }

    public function getKeyName($name)

    {

        $name_words = explode(' ', $name);

        $url_name = strtolower($name_words[0]);

        if (count($name_words) > 1) {

            for ($i = 1; $i < count($name_words); ++$i) {

                $url_name .= '_'.strtolower($name_words[$i]);

            }

        }



        return $this->eliminar_acentos($url_name);

    }



    public function getDayPlusOne(string $date)

    {

        return date('Y-m-d H:i', strtotime(explode(' ', $date)[0].'+1 days'));

    }



    public function eliminar_acentos($cadena)

    {

        // $cadena = utf8_decode(trim($cadena));



        //Reemplazamos la A y a

        $cadena = str_replace(

            ['Á', 'À', 'Â', 'Ä', 'á', 'à', 'ä', 'â', 'ª'],

            ['A', 'A', 'A', 'A', 'a', 'a', 'a', 'a', 'a'],

            $cadena

        );



        //Reemplazamos la E y e

        $cadena = str_replace(

            ['É', 'È', 'Ê', 'Ë', 'é', 'è', 'ë', 'ê'],

            ['E', 'E', 'E', 'E', 'e', 'e', 'e', 'e'],

            $cadena

        );



        //Reemplazamos la I y i

        $cadena = str_replace(

            ['Í', 'Ì', 'Ï', 'Î', 'í', 'ì', 'ï', 'î'],

            ['I', 'I', 'I', 'I', 'i', 'i', 'i', 'i'],

            $cadena

        );



        //Reemplazamos la O y o

        $cadena = str_replace(

            ['Ó', 'Ò', 'Ö', 'Ô', 'ó', 'ò', 'ö', 'ô'],

            ['O', 'O', 'O', 'O', 'o', 'o', 'o', 'o'],

            $cadena

        );



        //Reemplazamos la U y u

        $cadena = str_replace(

            ['Ú', 'Ù', 'Û', 'Ü', 'ú', 'ù', 'ü', 'û'],

            ['U', 'U', 'U', 'U', 'u', 'u', 'u', 'u'],

            $cadena

        );



        //Reemplazamos la N, n, C y c

        return str_replace(

            ['Ñ', 'ñ', 'Ç', 'ç'],

            ['N', 'n', 'C', 'c'],

            $cadena

        );

    }



    public function parseOrderByQuery($orderBy, $columns)

    {

        $salida = [];

        if (empty($orderBy)) {

            return [];

        }

        $orderA = explode(",", $orderBy);

        foreach ($orderA as $value) {

            $column = explode(' ', $value);

            if (in_array($column[0], $columns)) {

                $sort = (count($column) > 1) ? ($column[1] === 'desc' ? 'DESC' : 'ASC') : 'ASC';

                $salida[] = [$column[0], $sort];

            }

        }

        return $salida;

    }



    public function roundRating($total , $total_rating)

    {

        $rating = 0;

        if($total){

            $rating = $total_rating / $total;

            if(!is_int($rating)) {

                $rating_integer = floor($rating);

                $difference = $rating - $rating_integer;

                if($difference <= .249){

                    $difference = 0;

                }

                elseif($difference >= .25 && $difference <= .749) {

                    $difference = .5;

                }

                else {

                    $difference = 1;

                }

                $rating = $rating_integer + $difference;  

            }

        }

        return $rating;

    }



    public function generateRandomString() {

        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

        $charactersLength = strlen($characters);

        $randomString = '';

        for ($i = 0; $i < 10; $i++) {

            $randomString .= $characters[rand(0, $charactersLength - 1)];

        }

        return $randomString;

    }

    #get mont abrebiated
    public function getMonthName($month)
    {
        $month_name = '';
        switch ($month) {
            case 1:
                $month_name = 'Ene';
                break;
            case 2:
                $month_name = 'Feb';
                break;
            case 3:
                $month_name = 'Mar';
                break;
            case 4:
                $month_name = 'Abr';
                break;
            case 5:
                $month_name = 'May';
                break;
            case 6:
                $month_name = 'Jun';
                break;
            case 7:
                $month_name = 'Jul';
                break;
            case 8:
                $month_name = 'Ago';
                break;
            case 9:
                $month_name = 'Sep';
                break;
            case 10:
                $month_name = 'Oct';
                break;
            case 11:
                $month_name = 'Nov';
                break;
            case 12:
                $month_name = 'Dic';
                break;
        }
        return $month_name;
    }

}

