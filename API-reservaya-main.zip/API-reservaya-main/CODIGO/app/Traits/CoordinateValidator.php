<?php

namespace App\Traits;

trait CoordinateValidator 
{
    function distance($latitude_user, $longitude_user, $latitude_restaurant, $longitude_restaurant, $distance_km) 
    { 
        $pi80 = M_PI / 180; 
        $latitude_user          *= $pi80; 
        $longitude_user         *= $pi80; 
        $latitude_restaurant    *= $pi80; 
        $longitude_restaurant   *= $pi80; 

        $radious_distance = 6371; // mean radius of Earth in km - old 6372.797
        $dlat = $latitude_restaurant - $latitude_user; 
        $dlon = $longitude_restaurant - $longitude_user; 
        $a = sin($dlat / 2) * sin($dlat / 2) + cos($latitude_user) * cos($latitude_restaurant) * sin($dlon / 2) * sin($dlon / 2); 
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a)); 
        $km = $radious_distance * $c; 
        //dd($km);
        if($km <= $distance_km) {
            return true;
        }
        return false;
    }
}