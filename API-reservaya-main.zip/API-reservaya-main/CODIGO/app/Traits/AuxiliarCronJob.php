<?php

namespace App\Traits;

use App\Traits\{GeneralResponse, Notification};
use App\Models\{Publication, Reservation};
trait AuxiliarCronJob {

    use GeneralResponse, Notification;

    private function finishStories()
    {
        $date = date('Y-m-d H:i:s');
        $date_final = date('Y-m-d H:i:s', strtotime($date. '-1 days'));
        $stories = Publication::where('publication_type_id', 2)->where('status', true)->where('publication_date','<', $date_final)->get();

        foreach($stories as $story){
            $story->status = false;
            $story->save();
            $story->delete();
        }
    }

    private function reservationReminderNotification()
    {
        $date_start = date('Y-m-d H:i:s');
        $date_final = date('Y-m-d H:i:s', strtotime($date_start. '+1 days'));
        $reservations = Reservation::where(['reservations_status_id' => 1, 'notification' => false])
                                    ->where('reservation_date','>', $date_start)
                                    ->where('reservation_date','<', $date_final)
                                    ->get();
        foreach ($reservations as $reservation) {
            $restaurant = $reservation->table->restaurant;
            $user       = $reservation->client->user;

            if($restaurant->status && $restaurant->active){
                if($user->firebase_token && $user->active){
                    $title          = "Recordatorio de reservación";
                    $description    = "Tiene una reservación para el día de mañana en ".$restaurant->name.". Esperamos disfrute su experiencia";
                    $data           = ['reservation_eid' => $reservation->encrypt_id];
                    $this->sendNotification($user->firebase_token, $title, $description, $data);

                    $reservation->notification = true;
                    $reservation->save();
                }
            }
        }
    }
}