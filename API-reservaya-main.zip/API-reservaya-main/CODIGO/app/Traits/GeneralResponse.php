<?php

namespace App\Traits;

trait GeneralResponse
{
    public function genResponse($success = 1, $status_code = 200, $data = null, $custom_message = null, $action = null)
    {
        $default_messages = [
            200 => 'OK',
            201 => 'Elemento creado con éxito',
            204 => 'Sin contenido',
            208 => 'Ese elemento ya existe',
            400 => 'Datos invalidos',
            401 => 'No autorizado',
            403 => 'Prohibido',
            404 => 'Elemento no encontrado',
            405 => 'The specified method for the request is invalid',
            406 => 'Invalid id payload',
            412 => 'Precondicion fallida',
            500 => 'Error interno',
            503 => 'Service Unavailable',
        ];
        if ($custom_message) {
            $message = $custom_message;
        } else {
            $message = $default_messages[$status_code];
        }
        $res = [
            'success' => $success,
            'message' => $message,
            'data' => $data,
        ];
        if (null !== $action) {
            $res['action'] = $action;
        }

        return response()->json($res, $status_code);
    }
}
