<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class ServiceServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        $this->app->bind(
            'App\Services\Restaurant\ReservationServiceInterface',
            'App\Services\Restaurant\ReservationService'
        );
        //ClientServiceInterface
        $this->app->bind(
            'App\Services\Restaurant\ClientServiceInterface',
            'App\Services\Restaurant\ClientService'
        );
        //CommentServiceInterface
        $this->app->bind(
            'App\Services\Restaurant\CommentServiceInterface',
            'App\Services\Restaurant\CommentService'
        );
        //AuthServiceInterface
        $this->app->bind(
            'App\Services\Auth\AuthServiceInterface',
            'App\Services\Auth\AuthService'
        );
        //ChargeServiceInterface
        $this->app->bind(
            'App\Services\Restaurant\ChargeServiceInterface',
            'App\Services\Restaurant\ChargeService'
        );
        //CommissionServiceInterface
        $this->app->bind(
            'App\Services\CommissionServiceInterface',
            'App\Services\CommissionService'
        );
        //StaffServiceInterface
        $this->app->bind(
            'App\Services\Restaurant\StaffServiceInterface',
            'App\Services\Restaurant\StaffService'
        );
    }

    /**
     * Bootstrap services.
     */
    public function boot()
    {
    }
}
