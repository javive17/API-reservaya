<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        $this->app->bind(
            'App\Repositories\RepositoryInterface',
            'App\Repositories\Eloquent\BaseRepository'
        );
        $this->app->bind(
            'App\Repositories\UserRepositoryInterface',
            'App\Repositories\Eloquent\UserRepository'
        );
        $this->app->bind(
            'App\Repositories\ClientRepositoryInterface',
            'App\Repositories\Eloquent\ClientRepository'
        );

        $this->app->bind(
            'App\Repositories\CatalogRepositoryInterface',
            'App\Repositories\Eloquent\CatalogRepository'
        );

        $this->app->bind(
            'App\Repositories\PasswordResetRepositoryInterface',
            'App\Repositories\Eloquent\PasswordResetRepository'
        );

        $this->app->bind(
            'App\Repositories\RestaurantRepositoryInterface',
            'App\Repositories\Eloquent\RestaurantRepository'
        );

        $this->app->bind(
            'App\Repositories\RestaurantPhotoRepositoryInterface',
            'App\Repositories\Eloquent\RestaurantPhotoRepository'
        );

        $this->app->bind(
            'App\Repositories\ReservationRepositoryInterface',
            'App\Repositories\Eloquent\ReservationRepository'
        );

        $this->app->bind(
            'App\Repositories\CategoryClientRestaurantRepositoryInterface',
            'App\Repositories\Eloquent\CategoryClientRestaurantRepository'
        );

        $this->app->bind(
            'App\Repositories\ClientRestaurantPreferenceRepositoryInterface',
            'App\Repositories\Eloquent\ClientRestaurantPreferenceRepository'
        );

        $this->app->bind(
            'App\Repositories\RatingRepositoryInterface',
            'App\Repositories\Eloquent\RatingRepository'
        );

    }

    /**
     * Bootstrap services.
     */
    public function boot()
    {
    }
}
