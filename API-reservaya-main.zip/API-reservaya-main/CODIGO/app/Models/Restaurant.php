<?php



namespace App\Models;



use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

use Illuminate\Support\Str;



class Restaurant extends Model

{

    use SoftDeletes;



    protected $table = 't_restaurants';



    /**

    * get the model's input validation rules

    *

    * @param String $action

    * @return Array $rules

    */

    public static function getValidationRules($action)

    {

        $rules = [

            'list_all' => [],

            'list_distance' => [

                'distance'  => 'required|integer|max:100',

                'latitude'  => 'required',

                'longitude' => 'required',

            ],

            'list_filters' =>[

                'date'      => 'sometimes|date_format:Y-m-d',

                'hour'      => 'sometimes|date_format:H:i',

                'people'    => 'sometimes',

                'kitchens'  => 'sometimes|array',

                'zones'     => 'sometimes|array',

                'costs'     => 'sometimes|array',

            ],

            'list_name' => [

                'name'      => 'required',

            ],

            'store' => [

                'name'              => 'required',

                'owner_name'        => 'required',

                'email'             => 'required|email|unique:users',

                'address'           => 'required',

                'latitude'          => 'required',

                'longitude'         => 'required',

                'zone_eid'          => 'required',

                'kitchens'          => 'required|array',

                'cost_eid'          => 'required',

                'extra_services'    => 'sometimes|array',

            ],

            'store_photo' => [

                'restaurant_eid'    => 'required',

                'image'             => 'required|image|mimes:jpeg,png,jpg,gif,svg',

            ],

            'delete_photo' => [

                'restaurant_eid'    => 'required',

                'photo_eid'         => 'required',

            ],

            'update_menu' => [

                'restaurant_eid'    => 'required',

                'menu_url'          => 'required',

            ],

            'update_capacity' => [

                'restaurant_eid'    => 'required',

                'capacity'          => [

                                            'required',

                                            'array',

                                            function ($attribute, $value, $fail) {

                                                if (!is_array($value)) {

                                                    return;

                                                }

                            

                                                $errors = [];

                                                foreach ($value as $key => $val) {

                                                    if (!is_array($val)) {

                                                        $errors[] = $attribute.' '.$key.' must be a valid json';

                                                    }

                                                    if (!array_key_exists('table_type_eid', $val)) {

                                                        $errors[] = $attribute.' '.$key.' table_type_eid is required.';

                                                    }

                                                    if (!array_key_exists('capacity', $val)) {

                                                        $errors[] = $attribute.' '.$key.' capacity is required.';

                                                    }

                                                }

                                                if (!empty($errors)) {

                                                    $fail($errors);

                                                }

                                            },

                                        ],

            ],

            'update_service_days' => [

                'restaurant_eid'    => 'required',

                'service_days'      => 'required|array',

            ],

            'update_service_days_body' => [ 

                'day_eid'           => 'required', 

                'opening'           => 'required|date_format:H:i:s', 

                'closing'           => 'required|date_format:H:i:s', 

                'status'            => 'required|boolean' 

            ],

            'update_extra_service' => [

                'restaurant_eid'    => 'required',

                'extra_service_eid' => 'required', 

                'status'            => 'required|boolean'

            ],

            'update_cost' => [

                'restaurant_eid'    => 'required',

                'cost_eid'          => 'required',

            ],

            'update_kitchen' => [

                'restaurant_eid'    => 'required',

                'kitchen_eid'       => 'required', 

                'status'            => 'required|boolean'

            ],

            'update_address' => [

                'restaurant_eid'    => 'required',

                'address'           => 'required',

                'latitude'          => 'required', 

                'longitude'         => 'required'

            ],

            'update_information' => [

                'restaurant_eid'    => 'required',

                'phone'             => 'sometimes|max:13|min:7',

                'cheff_name'        => 'sometimes|min:3',

                'description'       => 'sometimes|max:250|min:5',

            ],

            'active_restaurant' => [

                'restaurant_eid'    => 'required',

                'status'            => 'required|boolean',

            ],

        ];

        return $rules[$action];

    }



    /**

     * The attributes that are mass assignable.

     *

     * @var array

     */

    protected $fillable = [

        'encrypt_id',

        'name',

        'slug', 

        'owner_name',

        'cheff_name',

        'email',

        'phone',

        'description',

        'menu_url',

        'status',

        'active',

        'notification',

        'cost_id',

        'country_id',

        'zone_id',

        'suburb_id',

        'address_id',
        
        'cover',
        
        'accept_automatic_reservation',

        'automatic_reservation',
        'sector_id',
        'offers'
    ];



    /**

     * The attributes that should be hidden for arrays.

     *

     * @var array

     */

    protected $hidden = [

        'id',

        'cost_id',

        'zone_id',

        'address_id',

    ];

    protected static function boot() {
        parent::boot();

        static::creating(function ($question) {
            $question->slug = Str::slug($question->name);
        });

        static::updating(function ($question) {
            $question->slug = Str::slug($question->name);
        });
    }


    /**

     * Get the addres for this restaurant.

     */

    public function address()

    {

        return $this->hasOne('App\Models\Address', 'id', 'address_id');

    }



    public function photos()

    {

        return $this->hasMany('App\Models\RestaurantPhoto');

    }



    public function tables()

    {

        return $this->hasMany('App\Models\Table')->where('capacity', '>', 0);

    }



    public function serviceDays()

    {

        return $this->hasMany('App\Models\RestaurantServiceDay');

    }



    public function cost()

    {

        return $this->hasOne('App\Models\Catalogs\Cost', 'id', 'cost_id');

    }



    public function country()

    {

        return $this->hasOne('App\Models\Catalogs\Country', 'id', 'country_id');

    }



    public function zone()

    {

        return $this->hasOne('App\Models\Catalogs\Zone', 'id', 'zone_id');

    }

    public function sector()

    {

        return $this->hasOne('App\Models\Catalogs\Sector', 'id', 'sector_id');

    }

    public function suburb()

    {

        return $this->hasOne('App\Models\Catalogs\Suburb', 'id', 'suburb_id');

    }



    /**

     * Get the kitchens for this restaurant.

     */

    public function kitchens()

    {

        return $this->belongsToMany('App\Models\Catalogs\Kitchen', 't_restaurants_kitchens', 'restaurant_id', 'kitchen_id')->withPivot('status');

    }

    /**

     * Get the extra services for this restaurant.

     */

    public function extraServices()

    {

        return $this->belongsToMany('App\Models\Catalogs\ExtraService', 't_restaurants_extra_services', 'restaurant_id', 'extra_service_id')->withPivot('status');

    }

    public function getCoverAttribute($value)
    {
        if ($value) {
            return asset('storage/app/' . $value);
        }
        return null;
    }

    public function getFavoritesAttribute()
    {
        $favorites = FavoriteRestaurant::where('restaurant_id', 139)->get();
        if($favorites->count() > 0 ){
            return $favorites;
        }else {
            return [];
        }
    }

    public function getThumbnailImageAttribute()
    {
        if ($this->attributes['thumbnail']) { 
            return asset('public/thumbnails/' . $this->attributes['thumbnail']); 
        } 
        return null; 
    } 

    public function getWebpImageAttribute()
    {
        if ($this->attributes['webp']) { 
            return asset('public/webp/' . $this->attributes['webp']); 
        } 
        return null; 
    } 

    #Verificar si la oferta esta activa, teniendo en cuenta el status y la fecha
    public function getOffersAllAttribute()
    {
        //get all offers from restaurant
        $offers = Offer::where('restaurant_id', $this->attributes['id'])
        ->where('status', 1)
        ->limit(3)
        ->get();
        $offer_data = [];
 
        if($offers->count() > 0 ){

            foreach($offers as $offer){

                #Variables
                $status = true;
                $show = false;
                #TESTING
                $p = [];

                if($offer->status == 1){
                    $seleted_days = $offer->dates_array;

                    if(!empty($seleted_days)) {
 
                        $seleted_days = json_decode($seleted_days);
 
                        #verificar si las fechas seleccionadas son mayores a la fecha actual
                        foreach($seleted_days as $day){

                            #convertir la fecha a formato Y-m-d (2023-12-24)
                            $date = $day;
                            $current_date = date('Y-m-d');
                            if($date >= $current_date){
                                $status = true;
                            }

                            if($date == $current_date){
                                $show = true;
                            }
                        }

                        if($offer->repeats == 1){
                            $date_start = date('Y-m-d', strtotime($offer->start_date));
                            $date_end = date('Y-m-d', strtotime($offer->end_date));

                            #arr fecha inicio hasta fecha fin
                            $monday = $offer->monday;
                            $tuesday = $offer->tuesday;
                            $wednesday = $offer->wednesday;
                            $thursday = $offer->thursday;
                            $friday = $offer->friday;
                            $saturday = $offer->saturday;
                            $sunday = $offer->sunday;

                            // Convertir las fechas a objetos DateTime para poder compararlas
                            $start = new \DateTime($date_start);
                            $end = new \DateTime($date_end);

                            if(Date('Y-m-d') <= $date_end){
                                $status = true;
                            }

                            if ($status && $date_start <= Date('Y-m-d')) {
                                // Agregar un día al final para incluir la fecha final en el rango
                                $end = $end->modify('+1 day');

                                // Crear un intervalo de un día
                                $interval = new \DateInterval('P1D');

                                // Crear un período de fechas desde la fecha de inicio hasta la fecha final
                                $period = new \DatePeriod($start, $interval, $end);

                                $current_day_now = date('N');

                                #TESTING
                                $p[] = [
                                    'monday' => $monday,
                                    'tuesday' => $tuesday,
                                    'wednesday' => $wednesday,
                                    'thursday' => $thursday,
                                    'friday' => $friday,
                                    'saturday' => $saturday,
                                    'sunday' => $sunday,
                                    'show' => $show,
                                    'current_day_now' => $current_day_now,
                                ];
                                

                                foreach ($period as $date) {
                                    #verificar si el dia actual esta dentro de los dias seleccionados
                                    $current_day = $date->format('N');

                                    if(($current_day == 1 && $current_day_now == 1) && $monday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 2 && $current_day_now == 2) && $tuesday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 3 && $current_day_now == 3) && $wednesday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 4 && $current_day_now == 4) && $thursday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 5 && $current_day_now == 5) && $friday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 6 && $current_day_now == 6) && $saturday == 1){
                                        $show = true;
                                    }

                                    if(($current_day == 7 && $current_day_now == 7) && $sunday == 1){
                                        $show = true;
                                    }

                                }
                            }

                        }


                    } //end if seleted_days

                } //end if status

                #saved status
                $offer->status = $status;
                $offer->save();
                $offer->refresh();

                $offer_data [] = [
                    'id' => $offer->id,
                    'title' => $offer->title,
                    'description' => $offer->description,
                    'status' => $offer->status,
                    'show' => $show, 
                    // 'status_new' => $status,
                    // 'repeats' => $offer->repeats,
                    #TESTING
                    // 'p' => $p,
                ];

            } //end foreach

        } //end if offers

        return $offer_data;

    } //end function

    /**
     * get poll ranking
     */
    public function getRankingPercentageAttribute()
    {
        $votes_count = 0;
        $reviews = Review::where('restaurant_id', $this->id)->get();

        if ($reviews->count() == 0) {
            return 5;
        }

        $reviews_count = $reviews->count();
        foreach ($reviews as $vote) {
            $votes_count += $vote->rating;
        }

        // return
        return round(($votes_count / $reviews_count));
    }
 

}