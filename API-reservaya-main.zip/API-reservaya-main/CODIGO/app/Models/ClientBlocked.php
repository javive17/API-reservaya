<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ClientBlocked extends Model
{
    use SoftDeletes;

    protected $table = 't_clients_blocked';

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'create' => [
                'client_blocked_eid'    => 'required',
                'status'                => 'required|boolean',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'client_id',
        'client_blocked_id',
        'status',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    /**
     * Get the client_blocked for this client.
     */
    public function client_blocked()
    {
        return $this->hasOne('App\Models\Client', 'id', 'client_blocked_id');
    }
}
