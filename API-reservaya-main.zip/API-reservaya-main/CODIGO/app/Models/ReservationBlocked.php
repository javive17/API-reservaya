<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class ReservationBlocked extends Model
{

    protected $table = 't_wholeday_reservations';

    protected $hidden = [
        'id',
        'updated_at',
        'deleted_at',
    ];
    public function client()
    {
        return $this->hasOne('App\Models\Client', 'id', 'client_id');
    }

}
