<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
    protected $fillable = [
        'user_id',
        'client_id',
        'restaurant_id',
        'platform',
        'token'
    ];
}
