<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Client extends Model
{
    use SoftDeletes;

    protected $table = 't_clients';

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'update_gender' => [
                'gender_eid' => 'required',
            ],
            'update_country' => [
                'country_eid' => 'required',
            ],
            'update_description' => [
                'description' => 'required|string|max:250',
            ],
            'search' => [
                'name' => 'required|string',
            ],
            'follows' => [
                'client_eid'    => 'required',
                'status'        => 'required|boolean',
            ],
            'accept_reject' => [
                'client_eid'    => 'required'
            ],
            'active_client' => [
                'client_eid'    => 'required',
                'status'        => 'required|boolean',
            ],
            'friend' => [
                'client_eid'    => 'required',
                'status'        => 'required|boolean',
            ],
            'message' => [
                'client_eid'    => 'required',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'first_name',
        'middle_name',
        'last_name',
        'cell_phone',
        'description',
        'gender_id',
        'country_id',
        'user_id',
        'client_status_id',
        'collaborator',
        'friend',
        'platform',
        'birthday_date'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'gender_id',
        'country_id',
        'user_id',
        'client_status_id',
        "created_at",
        "updated_at",
        "deleted_at",
    ];

    /**
     * Get the user for this client.
     */
    public function user()
    {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    /**
     * Get the gender for this client.
     */
    public function gender()
    {
        return $this->hasOne('App\Models\Catalogs\Gender', 'id', 'gender_id');
    }

    /**
     * Get the country for this client.
     */
    public function country()
    {
        return $this->hasOne('App\Models\Catalogs\Country', 'id', 'country_id');
    }

    /**
     * Get the professions for this client.
     */
    public function professions()
    {
        return $this->belongsToMany('App\Models\Catalogs\Profession', 't_client_professions', 'client_id', 'profession_id');
    }

    /**
     * Get the industries for this client.
     */
    public function industries()
    {
        return $this->belongsToMany('App\Models\Catalogs\Industry', 't_client_industries', 'client_id', 'industry_id');
    }

    /**
     * Get the nutritional requirements for this client.
     */
    public function nutritional_requirements()
    {
        return $this->belongsToMany('App\Models\Catalogs\NutritionalRequirement', 't_client_nutritional_requirements', 'client_id', 'nutritional_requirement_id');
    }

    /**
     * Get the allergies for this client.
     */
    public function allergies()
    {
        return $this->belongsToMany('App\Models\Catalogs\Allergy', 't_client_allergies', 'client_id', 'allergy_id');
    }

    /**
     * Get the tables for this client.
     */
    public function tables()
    {
        return $this->belongsToMany('App\Models\Catalogs\Table', 't_client_tables', 'client_id', 'table_id');
    }

    /**
     * Get the drinks for this client.
     */
    public function drinks()
    {
        return $this->belongsToMany('App\Models\Catalogs\Drink', 't_client_drinks', 'client_id', 'drink_id');
    }

    /**
     * Get the foods for this client.
     */
    public function foods()
    {
        return $this->belongsToMany('App\Models\Catalogs\Food', 't_client_foods', 'client_id', 'food_id');
    }

    /**
     * Get the specifications for this client.
     */
    public function specifications()
    {
        return $this->hasOne('App\Models\SurveySpecifications', 'client_id', 'id');
    }

    /**
     * Get the favorites for this client.
     */
    public function favorites()
    {
        return $this->belongsToMany('App\Models\Restaurant', 't_favorite_restaurants', 'client_id', 'restaurant_id');
    }

    /**
     * Get the publications for this client.
     */
    public function publications()
    {
        return $this->hasMany('App\Models\Publication');
    }

    /**
     * Get the follower for this client.
     */
    public function followers()
    {
        return $this->belongsToMany('App\Models\Client', 't_follows', 'following_id', 'follower_id');
    }

    /**
     * Get the followings for this client.
     */
    public function followings()
    {
        return $this->belongsToMany('App\Models\Client', 't_follows', 'follower_id', 'following_id');
    }

    /**
     * Get the privacy for this client.
     */
    public function privacy()
    {
        return $this->hasOne('App\Models\Privacy', 'client_id', 'id');
    }

    /**
     * Get the social_media for this restaurant.
     */
    public function social_medias()
    {
        return $this->belongsToMany('App\Models\Catalogs\SocialMedia', 't_social_medias', 'client_id', 'social_media_id')->withPivot('url', 'nickname');
    }

    /**
     * Get the social_media for this restaurant.
     */
    public function invitations()
    {
        return $this->belongsToMany('App\Models\Client', 't_client_invitations', 'invited_id', 'client_id')->withPivot('created_at');
    }

    /**
     * Get the reservations for this client.
     */
    public function reservations()
    {
        return $this->hasMany('App\Models\Reservation');
    }

    /**
     * Get the client status for this client.
     */
    public function client_status()
    {
        return $this->hasOne('App\Models\Catalogs\ClientStatus', 'id', 'client_status_id');
    }

    /**
     * Get the followings for this client.
     */
    public function clients_blocked()
    {
        return $this->belongsToMany('App\Models\Client', 't_clients_blocked', 'client_id', 'client_blocked_id');
    }

    public function getFullNameAttribute()
    {
        return $this->first_name . ' ' . $this->middle_name;
    }
}
