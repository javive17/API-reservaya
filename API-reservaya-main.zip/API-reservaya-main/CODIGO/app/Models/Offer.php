<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
//has factories
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Offer Extends Model{

    //table name is "t_offers"
    protected $table = 't_offers';


    //Mutator for the "dates" attribute
    function getDatesArrayAttribute($value){
        return $this->attributes['dates'];
    }
}