<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FavoriteRestaurant extends Model
{
    use SoftDeletes ;

    protected $table="t_favorite_restaurants";

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'create_or_update' => [
                'restaurant_eid'    => 'required',
                'status'            => 'required|boolean',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'status',
        'client_id',
        'restaurant_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        // 'restaurant_id',
        // 'client_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

}
