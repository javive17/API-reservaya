<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentRestaurant extends Model
{
    use SoftDeletes ;

    protected $table="t_payments_restaurants";

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'all' => [
                'date' => 'required|date_format:Y-m',
            ],
            'search' => [
                'date' => 'required|date_format:Y-m',
                'name' => 'required',
            ],
            'update_status' => [
                'payment_eid'       => 'required',
                'payment_status_eid' => 'required',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'payment_date',
        'amount',
        'restaurant_id',
        'payment_status_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'restaurant_id',
        'payment_status_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function restaurant(){
        return $this->hasOne('App\Models\Restaurant','id','restaurant_id');
    }

    public function payment_status(){
        return $this->hasOne('App\Models\Catalogs\PaymentStatus','id','payment_status_id');
    }
}
