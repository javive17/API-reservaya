<?php



namespace App\Models;



use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;



class Reservation extends Model

{

    use SoftDeletes;



    protected $table = 't_reservations';



    /**

     * The attributes that are mass assignable.

     *

     * @var array

     */

    protected $fillable = [

        'encrypt_id',

        'people',

        'reservation_date',

        'check_in',

        'check_out',

        'bill',

        'comments',

        'ticket_photo',

        'reservations_status_id',

        'client_id',

        'table_id',

        'notification',

        'table_number',

        'type',
        'start_date',
        'end_date',
        'created_by',
        'is_automatic',
        'commentSeen',


    ];



    /**

     * The attributes that should be hidden for arrays.

     *

     * @var array

     */

    protected $hidden = [

        'id',

        'updated_at',

        'deleted_at',

    ];



    /**

     * Get the addres for this restaurant.

     */

    public function status()

    {

        return $this->hasOne('App\Models\Catalogs\ReservationStatus', 'id', 'reservations_status_id');
    }



    public function client()

    {

        return $this->hasOne('App\Models\Client', 'id', 'client_id');
    }



    public function table()

    {

        return $this->belongsTo('App\Models\Table', 'table_id', 'id');
    }
    public function createdBy()
    {
        return $this->belongsTo('App\Models\User', 'created_by', 'id');
    }
    public function modifiedBy()
    {
        return $this->belongsTo('App\Models\User', 'modified_by', 'id');
    }
    public function statusModifiedBy()
    {
        return $this->belongsTo('App\Models\User', 'status_modified_by', 'id');
    }
    public function updatedBy()
    {
        return $this->belongsTo('App\Models\User', 'updated_by', 'id');
    }

    public function getReviewAttribute()
    {
        #return true or false
        $review = Review::where('reservation_id', $this->id)->first();
        if ($review) {
            return true;
        } else {
            return false;
        }

    }
}
