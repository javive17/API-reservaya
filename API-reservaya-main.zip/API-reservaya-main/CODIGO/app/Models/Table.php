<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Table extends Model
{
    use SoftDeletes ;

    protected $table="t_tables";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'internal_table',
        'capacity',
        'table_type_id',
        'restaurant_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'restaurant_id',
        'table_type_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function type(){
        return $this->hasOne('App\Models\Catalogs\TableType','id','table_type_id');
    }

    public function reservations()
    {
        return $this->hasMany('App\Models\Reservation');
    }

    public function restaurant(){
        return $this->hasOne('App\Models\Restaurant','id','restaurant_id');
    }
}
