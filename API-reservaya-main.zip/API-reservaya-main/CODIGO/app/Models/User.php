<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;
use PhpParser\Node\Expr\Cast\Object_;

class User extends Authenticatable
{
    use SoftDeletes, HasApiTokens, Notifiable;

    protected $table = "users";

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'create' => [
                // 'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
                'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
                'data'  => 'required',
            ],
            'validate_data' => [
                'email'             => 'required|email', 
                'name'              => 'required', 
                'first_lastname'    => 'required', 
                'second_lastname'   => 'sometimes',
                'gender_eid'        => 'sometimes', 
                'country_eid'       => 'required', 
                'social_media'      => 'required',
            ],
            'invitation' => [
                'email'             => 'required|email', 
                'name'              => 'required', 
                'first_lastname'    => 'required', 
                'second_lastname'   => 'sometimes',
            ],
            'founder_invitation' => [
                'email'             => 'required|email|unique:users', 
                'name'              => 'required', 
                'first_lastname'    => 'required', 
                'second_lastname'   => 'sometimes',
                'cell_phone'        => 'sometimes|max:13|min:7',
                'collaborator'      => 'sometimes',
                'friend'            => 'sometimes|boolean',
            ],
            'validate_social_media' => [
                'social_media_eid'  => 'required', 
                'url'               => 'required',
            ],
            'update_firebase_token' => [
                'firebase_token'  => 'required', 
            ],
            'sender_notification_chat' => [
                'client_eid'    => 'required',
                'data'          => 'required',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'name',
        'photo',
        'phone',
        'email',
        'email_hash',
        'password',
        'role_id',
        'restaurant_id',
        'email_verified_at',
        'active',
        'chief_manager',
        'firebase_token',
        'google_id',
        'google_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'password',
        'remember_token',
        'firebase_token'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Get the role for this user.
     */
    public function role()
    {
        return $this->hasOne('App\Models\Catalogs\Role','id','role_id');
    }

    /**
     * Get the client for this user.
     */
    public function client()
    {
        return $this->hasOne('App\Models\Client', 'user_id', 'id');
    }

    /**
     * Get the restaurant for this user.
     */
    public function restaurant()
    {
        return $this->hasOne('App\Models\Restaurant', 'id', 'restaurant_id');
    }

    public function getPhotoNameAttribute()
    {
        $photo = $this->photo;
        $photo = explode('/', $photo);
        $photo = end($photo); 
        return $photo;
    }

    public function getPhotoAttribute($value)
    {
        if ($value) {
            return asset('storage/app/prod/users/' . $value);
        }
        return null;
    }

}
