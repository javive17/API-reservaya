<?php

namespace App\Models\Catalogs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Zone extends Model
{
    use SoftDeletes;

    // En tu modelo Zone
    protected $appends = ['sector'];


    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = "c_zones";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'name',
        'country_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'country_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    /**
     * Get sector mutator.
     */
    public function getSectorAttribute() {
        //order by name alphabetically
        $data = Sector::where('zone_id', $this->id)->orderBy('name', 'asc')->get();
        if(!$data)
        {
            return [];
        }
        return $data;
    }
}
