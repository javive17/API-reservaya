<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class PreferenceClientRestaurant extends Model
{
    use SoftDeletes;

    protected $table = 't_preferences_restaurants_clients';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'rating',
        'friend',
        'drink',
        'food',
        'table',
        'client_id',
        'restaurant_id',
        'extra_comments'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
    ];
}
