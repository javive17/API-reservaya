<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Publication extends Model
{
    use SoftDeletes;

    protected $table = 't_publications';

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'likes_dislikes' => [
                'publication_eid'   => 'required',
                'status'            => 'required|boolean',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'photo',
        'description',
        'publication_date',
        'status',
        'publication_type_id',
        'restaurant_id',
        'client_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'publication_type_id',
        'restaurant_id',
        'client_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];


    /**
     * Get the likes for this client.
     */
    public function likes()
    {
        return $this->belongsToMany('App\Models\Client', 't_liked_publications', 'publication_id', 'client_id');
    }
    /**
     * Get the type for this publication.
     */
    public function publication_type()
    {
        return $this->hasOne('App\Models\Catalogs\PublicationType', 'id', 'publication_type_id');
    }

    public function client()
    {
        return $this->hasOne('App\Models\Client', 'id', 'client_id');
    }

    public function report_publication()
    {
        return $this->hasMany('App\Models\ReportPublication');
    }
}
