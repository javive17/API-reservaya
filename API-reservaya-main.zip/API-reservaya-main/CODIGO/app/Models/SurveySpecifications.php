<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SurveySpecifications extends Model
{
    use SoftDeletes;

    protected $table = 't_survey_specifications';

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'create' => [
                'especification' => 'sometimes|string|max:250',
                'data'          => 'required|array',
            ],
            'create_nutritional_requirement' => [
                'especification' => 'sometimes|string|max:250',
                'data'          => 'sometimes|array',
            ],
            'favorite_drink' => [
                'trademark'         => 'required|string|max:250',
                'favorite_drink'    => 'required|string|max:250',
            ],
            'additional' => [
                'additional'         => 'required|string|max:250',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'profession',
        'industry',
        'nutritional_requirement',
        'allergy',
        'table',
        'drink',
        'food',
        'trademark',
        'favorite_drink',
        'additional',
        'client_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'client_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];


}
