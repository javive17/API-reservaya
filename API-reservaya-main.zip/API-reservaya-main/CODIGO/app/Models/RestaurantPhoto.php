<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class RestaurantPhoto extends Model
{
    use SoftDeletes ;

    protected $table="t_restaurants_photos";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'encrypt_id',
        'url',
        'order_photos',
        'restaurant_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'restaurant_id',
        'deleted_at',
        'order_photos',
    ];
}
