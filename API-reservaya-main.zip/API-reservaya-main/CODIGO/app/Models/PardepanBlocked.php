<?php



namespace App\Models;



use Illuminate\Database\Eloquent\Model;

class PardepanBlocked extends Model

{



    protected $table = 't_pardepan_blocks';



    protected $hidden = [

        'id',

        'updated_at',

        'deleted_at',

    ];

}

