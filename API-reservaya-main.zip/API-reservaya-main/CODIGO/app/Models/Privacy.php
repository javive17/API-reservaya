<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Privacy extends Model
{
    use SoftDeletes;

    protected $table = 't_privacies';

    /**
    * get the model's input validation rules
    *
    * @param String $action
    * @return Array $rules
    */
    public static function getValidationRules($action)
    {
        $rules = [
            'privacity' => [
                'followed_followers'    => 'required|boolean',
                'i_like_it'             => 'required|boolean',
                'message_viewed'        => 'required|boolean',
                'name_by_pseudonym'     => 'required|boolean',
                'pseudonym'             => 'required_if:name_by_pseudonym,1|string|max:250',
            ],
        ];
        return $rules[$action];
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'followed_followers',
        'i_like_it',
        'message_viewed',
        'name_by_pseudonym',
        'pseudonym',
        'client_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'id',
        'client_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];
}
