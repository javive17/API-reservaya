<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class GroupFilesForm extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    protected $data_reservation;
    protected $user;
    protected $attachments_arr;


    public function __construct($data_reservation, $user, $attachments_arr = null)
    {
        $this->data_reservation = $data_reservation;
        $this->user = $user;
        $this->attachments_arr = $attachments_arr;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = sprintf('Nueva reservación en Reserva Ya!', config('app.name'), $this->user->name);
        $email = $this->from(env('MAIL_FROM_ADDRESS'))
                    ->subject($subject)
                    ->markdown('emails.reservations.GroupFilesForm', ['reservation' => $this->data_reservation , 'user' => $this->user]);

        //send attachments if any exist in the array
        if($this->attachments_arr){
            foreach($this->attachments_arr as $attachment){
                $email->attach($attachment);
            }
        }

        return $email;
    }
}
