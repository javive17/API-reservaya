<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CancelledReservation extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    protected $data_reservation;
    protected $user;
    public function __construct($data_reservation, $user)
    {
        $this->data_reservation = $data_reservation;
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = sprintf('¡Reservación cancelada!', 'Pardepan', $this->user->name);
        #formatted id code 6 digits
        // $id_code = sprintf('%06d', $this->data_reservation->id);

        return $this->from(env('MAIL_FROM_ADDRESS'))
                    ->subject($subject)
                    ->markdown('emails.reservations.cancelled', ['reservation' => $this->data_reservation , 'user' => $this->user]);
    }
}
