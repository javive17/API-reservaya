<?php

namespace Tests;

use App\Exceptions\Handler;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Support\Facades\Artisan;

abstract class TestCase extends BaseTestCase
{
    use CreatesApplication,RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();
        $this->artisan('migrate', ['--path' => '/database/migrations/catalogs']);
        Artisan::call('passport:install');
        $this->artisan('db:seed');
        $this->withoutExceptionHandling();
    }

}
