<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    /**
     * Function that tests the fields to register are required
     */
    public function testRequiredFieldsForRegistration()
    {
        $this->json('POST', 'api/v1/login/register', ['Accept' => 'application/json'])
            ->assertStatus(400)
            ->assertJson([
                "success" => 0,
                "message" => "Datos invalidos",
                "data" => [
                    "errors" => [
                        "email" => ["The email field is required."],
                        "password" => ["The password field is required."],
                        "password_confirmation" => ["The password confirmation field is required."]
                    ],
                ]
            ]);
    }

    public function testPasswordFormat()
    {
        $userData = [
            "email" => "doe@example.com",
            "password" => "demo12345",
            "password_confirmation" => "demo12345"
        ];
        $this->json('POST', 'api/v1/login/register', $userData, ['Accept' => 'application/json'])
            ->assertStatus(400)
            ->assertJson([
                "success" => 0,
                "message" => "Datos invalidos",
                "data" => [
                    "errors" => [
                        "password" => [
                            "The password format is invalid."
                        ],
                        "password_confirmation" => [
                            "The password confirmation format is invalid."
                        ]

                    ],
                ]
            ]);
    }

    /**
     *
     */
    public function testRepeatPassword()
    {
        $userData = [
            "email" => "doe@example.com",
            "password" => "Demo12345",
            "password_confirmation" => "Demo12346"
        ];

        $this->json('POST', 'api/v1/login/register', $userData, ['Accept' => 'application/json'])
            ->assertStatus(400)
            ->assertJson([
                "success" => 0,
                "message" => "Datos invalidos",
                "data" => [
                    "errors" => [
                        "password" => ["The password confirmation does not match."]
                    ],
                ]
            ]);
    }

    /**
     *
     */
    public function testSuccessfulRegistration()
    {
        $userData = [
            "email" => "doe@example.com",
            "password" => "Demo12345",
            "password_confirmation" => "Demo12345"
        ];

        $this->json('POST', 'api/v1/login/register', $userData, ['Accept' => 'application/json'])
            ->assertStatus(201)
            ->assertJsonStructure([
                "success",
                "data" => [
                    "user" => [
                        'encrypt_id',
                        'email',
                    ],
                    "access_token",
                ],
                "message",
            ]);
    }
}
