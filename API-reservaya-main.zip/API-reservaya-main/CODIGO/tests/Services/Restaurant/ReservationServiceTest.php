<?php

namespace Tests\Services\Restaurant;

use Tests\TestCase;
use App\Services\Restaurant\ReservationService;
use App\Repositories\Eloquent\ReservationRepository;
use App\Models\Reservation;
use Illuminate\Support\Facades\Log;

class ReservationServiceTest extends TestCase
{


    public function testRestauranCapacityBySchedule()
    {
        $reservationRepository = $this->getMockBuilder(ReservationRepository::class)
            ->disableOriginalConstructor()
            ->getMock();

        $reservationRepository->expects($this->any())
            ->method('findByRestaurantIdAndReservationDate')
            ->willReturn($this->reservationCollection());

        /** @var \App\Repositories\Eloquent\ReservationRepository $reservationRepository */
        $reservationServices = new ReservationService($reservationRepository);

        $list = $reservationServices->restauranCapacityBySchedule(1, "2021/06/04", "7:30");

        Log::info("Salida dada =>>>>>>>>".$list);
        $this->assertNotEmpty($list);

        $salidaEsperada = $this->reservationCollection()->map(function ($reservation){
            return [
                'date' =>$reservation->reservation_date
            ];
        });

        Log::info("Salida esperada =>>>>>>>>".$salidaEsperada);

        $this->assertEquals($list,$salidaEsperada);
    }

    private function reservationCollection()
    {
        return collect([
            new Reservation([
                'reservation_date' => date_create('2020-06-04 15:00'),
                'people' => 10,
                'check_in' => now(),
                'check_out' => now(),
                'bill' => 200.5,
                'comments' => "sfdsfdsfdsf",
                'ticket_photo' => "sdfsdfsdfds",
                'reservations_status_id' => 1,
                'client_id' => 3,
                'table_id' => 1,
            ]),
            new Reservation([
                'reservation_date' => date_create('2020-06-04 17:30'),
                'people' => 10,
                'check_in' => now(),
                'check_out' => now(),
                'bill' => 200.5,
                'comments' => "sfdsfdsfdsf",
                'ticket_photo' => "sdfsdfsdfds",
                'reservations_status_id' => 1,
                'client_id' => 3,
                'table_id' => 3,
            ]),
            new Reservation([
                'reservation_date' => date_create('2020-06-04 20:00'),
                'people' => 10,
                'check_in' => now(),
                'check_out' => now(),
                'bill' => 200.5,
                'comments' => "sfdsfdsfdsf",
                'ticket_photo' => "sdfsdfsdfds",
                'reservations_status_id' => 1,
                'client_id' => 3,
                'table_id' => 2,
            ]),
        ]);
    }
}
